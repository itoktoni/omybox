<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Slider extends Model {

    protected $table      = 'sliders'; //nama table
    protected $primaryKey = 'slider_id'; //nama primary key
    protected $fillable   = [//field yang mau di save ke database
      'slider_id',
      'slider_name',
      'slider_images',
      'slider_description',
    ];
    public $searching     = 'slider_name'; //default pencarian ketika di cari
    public $timestamps    = true; //kalau mau automatic update tanggal ketika save atau edit ubah jadi true
    public $incrementing  = false; //kalau id nya mau dibuatkan otomatis dari laravel 1,2,3
    public $rules         = [//validasi https://laravel.com/docs/5.5/validation
      'slider_name' => 'required|min:3',
    ];
    public $datatable     = [//field dan header buat di show ke list table 
      'slider_name'   => 'Name',
      'slider_description'   => 'Description',
    ];

    public function simpan($request, $file = null)
    {
        try
        {
            if(!empty($file)) //handle images
            {

                $name   = $request['unic'] . '.' . $file->extension();
                $simpen = $file->storeAs('slider', $name);

                $request['slider_images'] = $name;
            }

            $this->Create($request);
            session()->put('success', 'Data Has Been Added !');
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function hapus($data)
    {
        if(!empty($data))
        {
            $data = collect($data)->flatten()->all();
            try
            {
                $this->Destroy($data);
                session()->flash('alert-success', 'Data Has Been Deleted !');
            }
            catch(\Exception $e)
            {
                session()->flash('alert-danger', $e->getMessage());
            }
        }
    }

    public function ubah($id, $request, $file = null)
    {
        try
        {
            if(!empty($file)) //handle images
            {
                $name   = $request['unic'] . '.' . $file->extension();
                $simpen = $file->storeAs('slider', $name);

                $request['slider_images'] = $name;
            }

            $s = $this->find($id);
            $s->update($request);

            session()->put('success', 'Data Has Been Updated !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function baca($id = null)
    {
        if(!empty($id))
        {
            return $this->where($this->primaryKey, $id);
        }
        else
        {
            return $this->select();
        }
    }

    public function getUser(){
        $data = DB::table('users')->where('group_user', '=', 'slider');
        return $data->get();
    }

}
