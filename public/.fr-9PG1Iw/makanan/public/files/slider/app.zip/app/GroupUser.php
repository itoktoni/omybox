<?php
namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class GroupUser extends Model{

    protected $table = 'group_users';
    protected $primaryKey = 'group_user_code';
    protected $fillable = [
            'group_user_code',
            'group_user_name',
            'group_user_description',
    ];
    public $searching = 'group_user_name';
    public $timestamps = false;
    public $incrementing = false;
    public $rules = [
            'group_user_code' => 'required|min:3|unique:group_users',
            'group_user_name' => 'required|min:3',
    ];
    public $datatable = [
            'group_user_code' => 'Code',
            'group_user_name' => 'Name',
            'group_user_dashboard' => 'Dashboard',
            'group_user_description' => 'Description',
    ];

    public function simpan($data)
    {
        try
        {
            $this->Create($data);
            session()->put('success', 'Data Has Been Added !');
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function hapus($data)
    {
        if(!empty($data))
        {
            $data = collect($data)->flatten()->all();
            try
            {
                $this->Destroy($data);
                session()->flash('alert-success', 'Data Has Been Deleted !');
            }
            catch(\Exception $e)
            {
                session()->flash('alert-danger', $e->getMessage());
            }
        }
    }

    public function ubah($id, $data)
    {
        try
        {
            $s = $this->find($id);
            $s->update($data);

            session()->put('success', 'Data Has Been Updated !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function saveUser($code,$data)
    {
        try
        {
            if(!empty($data))
            {
                DB::table('users')->where('group_user', $code)->update(['group_user' => null]);
                foreach($data as $user)
                {
                    DB::table('users')->where('user_id', $user)->update(['group_user' => $code]);
                }
            }

            session()->put('success', 'Data Has Been Saved !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function saveKoneksiModule($code,$data)
    {
        try
        {
            DB::table('group_user_connection_group_module')->where('conn_gu_group_user', '=', $code)->delete();
            if(!empty($data))
            {
                foreach($data as $d)
                {
                    DB::table('group_user_connection_group_module')->insert([
                            'conn_gu_group_module' => $d,
                            'conn_gu_group_user' => $code
                    ]);
                }
            }

            session()->put('success', 'Data Has Been Saved !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function baca($id = null)
    {
        if(!empty($id))
        {
            return DB::table($this->table)->where($this->primaryKey, $id);
        }
        else
        {
            return $this->select();
        }
    }

}
