<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

class OutboundController extends Controller
{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $prefix;
    public $codelength;

    public function __construct()
    {
        $this->model      = new \App\Stock();
        $this->table      = $this->model->getTable();
        $this->key        = $this->model->getKeyName();
        $this->field      = $this->model->getFillable();
        $this->datatable  = $this->model->datatable;
        $this->rules      = $this->model->rules;
        $this->searching  = $this->model->searching;
        $this->template   = 'outbound';
        $this->prefix     = date("y") . date("m");
        $this->codelength = 8;
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function outbound_so()
    {
        if (request()->isMethod('POST')) {

            $rules = [
                'barcode'      => 'required|min:3',
                'product_code' => 'required|min:3',
                'reference'    => 'required|min:3',
                'qty'          => 'required',
            ];

            $this->validate(request(), $rules);
            $request = request()->all();

            $reference = request()->get('reference');
            $produk    = request()->get('product_code');
            $qty       = request()->get('qty');
            $barcode   = request()->get('barcode');

            $data_total = DB::table('stocks')->where('barcode', '=', $barcode);
            $total      = 0;

            if (!empty($data_total->first())) {

                $total = $data_total->first()->qty;
            }

            $pengurangan    = $total - $qty;
            $request['qty'] = $total - $qty;
            $this->model->out($request);

            if (strpos($reference, 'SO') !== false) {

                $total = DB::table('order_detail');
                $total->where(['detail' => $reference, 'product' => $produk]);
                $d_total = $total->get()->first();
                $total->update([
                    'qty_prepare'   => $d_total->qty_prepare + $qty,
                    'price_prepare' => $d_total->price,
                    'total_prepare' => $qty * $d_total->price,
                ]);
            }

            return redirect()->back();

        } else {
            return view('page.' . $this->template . '.outbound')->with([
                'template' => $this->template,
            ]);
        }
    }

    public function outbound_return()
    {
        if (request()->isMethod('POST')) {

            $rules = [
                'barcode'      => 'required|min:3',
                'product_code' => 'required|min:3',
                'reference'    => 'required|min:3',
                'qty'          => 'required',
            ];

            $this->validate(request(), $rules);
            $request = request()->all();
            // dd($request);

            $reference = request()->get('reference');
            $produk    = request()->get('product_code');
            $qty       = request()->get('qty');
            $barcode   = request()->get('barcode');

            $data_total = DB::table('stocks')->where('barcode', '=', $barcode);
            $total      = 0;

            if (!empty($data_total->first())) {

                $total = $data_total->first()->qty;
            }

            $pengurangan    = $total - $qty;
            $request['qty'] = $total - $qty;
            $this->model->out($request);

            if (strpos($reference, 'RO') !== false) {

                $total = DB::table('return_order_detail');
                $total->where(['detail' => $reference, 'product' => $produk]);
                $d_total = $total->get()->first();
                $total->update([
                    'qty_prepare'   => $d_total->qty_prepare + $qty,
                    'price_prepare' => $d_total->price,
                    'total_prepare' => $qty * $d_total->price,
                ]);
            }

            return redirect()->back();

        } else {
            return view('page.' . $this->template . '.return')->with([
                'template' => $this->template,
            ]);
        }
    }

    public function outbound_spk()
    {
        if (request()->isMethod('POST')) {

            $rules = [
                'barcode'      => 'required|min:3',
                'product_code' => 'required|min:3',
                'reference'    => 'required|min:3',
                'qty'          => 'required',
            ];

            $this->validate(request(), $rules);
            $request = request()->all();

            $reference = request()->get('reference');
            $ref       = str_replace('WO', '', $reference);
            $produk    = request()->get('product_code');
            $qty       = request()->get('qty');
            $barcode   = request()->get('barcode');

            $cek = DB::table('spk')
                ->where('spk_id', $ref)
                ->where('spk_status', 'PREPARED')
                ->count();

            if ($cek > 0) {
                $query_total = DB::table('stocks')->where('barcode', '=', $barcode);
                $total       = 0;
                $data_total  = $query_total->first();
                if (!empty($data_total) && $data_total->qty > 0) {

                    $total          = $data_total->qty;
                    $request['qty'] = $total - $qty;
                    
                    $mapping = DB::table('converters')->join('spk_detail', 'spk_detail.product', 'converters.product_to')->where('product_from', $produk)->where('detail', $ref)->first();
                    if (empty($mapping)) {
                        session()->flash('alert-danger', 'Product Blm di Mapping !');
                    } else {

                        $this->model->out($request);
                        $detail = DB::table('spk_detail');
                        $detail->where(['detail' => $ref, 'product' => $mapping->product_to]);
                        $getTotal   = $detail->first();
                        $qty_tambah = $detail->count();
                        if ($qty_tambah > 0) {

                            $qty_tambah = $getTotal->yard_prepare;

                        }

                        $detail->update([
                            'yard_prepare' => $qty + $qty_tambah,
                        ]);

                        //================== SPK OUTBOUND =======================//

                        $outbound = DB::table('spk_outbound');
                        $outbound->where(['detail_out' => $ref, 'product_out' => $produk]);
                        $getOutbound = $outbound->first();
                        $qty_tambah  = $outbound->count();
                        if ($qty_tambah > 0) {

                            $qty_tambah = $getOutbound->yard_prepare_out;

                        }

                        $outbound->update([
                            'yard_prepare_out' => $qty + $qty_tambah,
                        ]);
                    }

                } else {
                    session()->flash('alert-danger', 'Stock Tidak Mencukupi !');
                }

            } else {
                session()->flash('alert-danger', 'Barang di SPK ini telah dikirim !');
            }

            return redirect()->back();

        } else {
            return view('page.' . $this->template . '.outbound_spk')->with([
                'template' => $this->template,
            ]);
        }
    }
}
