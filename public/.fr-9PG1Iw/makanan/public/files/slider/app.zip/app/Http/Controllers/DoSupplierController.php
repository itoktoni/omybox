<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Yajra\Datatables\Facades\Datatables;

class PurchaseOrderController extends Controller {

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $prefix;
    public $codelength;

    public function __construct() {
        $this->model = new \App\PurcaseOrder();
        $this->table = $this->model->getTable();
        $this->key = $this->model->getKeyName();
        $this->field = $this->model->getFillable();
        $this->datatable = $this->model->datatable;
        $this->rules = $this->model->rules;
        $this->searching = $this->model->searching;
        $this->template = 'po';
        $this->prefix = "PO" . date("y") . date("m");
        $this->codelength = 10;
    }

    public function index() {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create() {
        if (request()->isMethod('POST')) {
            $this->validate(request(), $this->rules);
            $code = $this->Code($this->table, $this->key, $this->prefix, $this->codelength);
            $request = request()->all();
            $file = request()->file('files');
            $this->model->simpan($code, $request, $file);

            $produk = request()->get('produks');
            $qty = request()->get('quantity');
            $price = request()->get('price');
            $s_price = request()->get('s_price');

            for ($i = 0; $i < count(request()->get('produks')); $i++) {

                $detail = [
                    'detail' => $code,
                    'product' => $produk[$i],
                    'qty' => $qty[$i],
                    'suggestion' => $s_price[$i],
                    'price' => $price[$i],
                    'total' => $price[$i] * $qty[$i],
                ];

                $this->model->detail($detail);
            }

            return redirect()->route($this->getModule().'_approve', ['code' => $code]);

        } else {
            $warehouse = new \App\Warehouse();
            $supplier = new \App\Supplier();
            $product = new \App\Product();
            return view('page.' . $this->template . '.create')->with([
                'template' => $this->template,
                'warehouse' => $warehouse->baca()->get(),
                'supplier' => $supplier->baca()->get(),
                'product' => $product->baca()->where('product_category','=','Kain')->get(),
            ]);
        }
    }

    public function read() {
        if (request()->isMethod('POST')) {
            $getData = $this->model->baca();
            $datatable = Datatables::of($this->filter($getData))
            ->addColumn('checkbox', function ($select) {
                $id = $this->key;
                $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="' . $select->$id . '">';
                return $checkbox;
            })->addColumn('action', function ($select) {
                $id = $this->key;
                $gabung = '<div class="aksi text-center">';
                if (session()->get('akses.update')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_update', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-primary">edit</a> ';
                }
                if (session()->get('akses.admin')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_admin', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-warning">admin</a> ';
                }
                $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                    'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                return $gabung;
            });

            $awal = request()->get('awal');
            $akhir = request()->get('akhir');

            if (!empty($awal) && !empty($awal)) {
                $datatable->where('purchase_date', '>=', $awal);
                $datatable->where('purchase_date', '<=', $akhir);
            }

            if (session()->get('akses.update')) {

                $datatable->Where('purchase_status','=','APPROVED');
                $datatable->orWhere('purchase_status','=','PREPARED');
                $datatable->orWhere('purchase_status','=','DELIVERED');
            }

            if (request()->has('search')) {
                $code = request()->get('code');
                $search = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }


        if (request()->has('code')) {
            $id = request()->get('code');
            $getData = $this->model->baca($id);
            return view('page.' . $this->template . '.show')->with(['fields' => $this->datatable,
                'data' => $this->validasi($getData),
                'detail' => $this->model->getDetail($id),
                'key' => $this->key,
                'template' => $this->template]);
        }

        return view('page.' . $this->template . '.table')->with(['fields' => $this->datatable,
            'template' => $this->template]);
    }

    public function approve(){
        if (!empty(request()->get('code'))) {
           $id = request()->get('code');
           $getData = $this->model->baca($id);

           return view('page.' . $this->template . '.approve')->with([
            'template' => $this->template,
            'data' => $this->validasi($getData),
            'detail' => $this->model->getDetail($id),
            'key' => $this->key,
            'fields' => $this->datatable,
        ]);
       }

       return redirect()->route($this->getModule().'_read');
   }

   public function deliver(){
        if (!empty(request()->get('code'))) {
           $id = request()->get('code');
           $getData = $this->model->baca($id);

           return view('page.' . $this->template . '.deliver')->with([
            'template' => $this->template,
            'data' => $this->validasi($getData),
            'detail' => $this->model->getDetail($id),
            'key' => $this->key,
            'fields' => $this->datatable,
        ]);

           return redirect()->route($this->getModule().'_read');
       }
   }

   public function update() {
    if (!empty(request()->get('code'))) {
        $id = request()->get('code');
        $getData = $this->model->baca($id);

        return view('page.' . $this->template . '.edit')->with([
            'template' => $this->template,
            'data' => $this->validasi($getData),
            'detail' => $this->model->getDetail($id),
            'key' => $this->key,
            'fields' => $this->datatable,
        ]);
    } else {
        if (request()->isMethod('POST')) {
                //dd(request()->all());
            $id = collect(request()->query())->flip()->first();
            $request = request()->all();
            $request['form'] = 'update';
            $this->model->ubah($id, $request);

            if($request['purchase_status'] == 'DELIVERED'){

                 return redirect()->route($this->getModule().'_deliver', ['code' => $id]);
            }
        }
        return redirect()->back();
    }
}

public function admin() {
    if (!empty(request()->get('code'))) {
        $id = request()->get('code');
        $getData = $this->model->baca($id);

        return view('page.' . $this->template . '.admin')->with([
            'template' => $this->template,
            'data' => $this->validasi($getData),
            'detail' => $this->model->getDetail($id),
            'key' => $this->key,
            'fields' => $this->datatable,
        ]);
    } else {
        if (request()->isMethod('POST')) {
            $id = collect(request()->query())->flip()->first();
            $request = request()->all();
            $file = request()->file('files');
            $request['form'] = 'admin';
            $this->model->ubah($id, $request,$file);
        }
        return redirect()->back();
    }
}

public function delete() {
    $input = request()->all();
    $this->model->cancel(request()->get('id'));
    return redirect()->back();
}

}
