<?php
namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Action extends Model{

    protected $table = 'actions';
    protected $primaryKey = 'action_code';
    protected $fillable = [
            'action_code',
            'action_name',
            'action_description',
            'action_link',
            'action_controller',
            'action_function',
            'action_sort',
            'action_visible',
            'action_enable'
    ];
    
    public $searching = 'action_name';
    public $timestamps = false;
    public $incrementing = false;
    public $rules = [
            'action_name' => 'required|min:3',
    ];
    public $datatable = [
            'action_code' => 'Code',
            'action_name' => 'Name',
            'action_link' => 'Link',
            'action_controller' => 'Controller',
            'action_function' => 'Function',
            'action_visible' => 'Visible',
            'action_enable' => 'Enable',
    ];

    public function simpan($data)
    {
        try
        {
            $this->Create($data);
            session()->put('success', 'Data Has Been Added !');
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function hapus($data)
    {
        if(!empty($data))
        {
            $data = collect($data)->flatten()->all();
            try
            {
                $this->Destroy($data);
                session()->flash('alert-success', 'Data Has Been Deleted !');
            }
            catch(\Exception $e)
            {
                session()->flash('alert-danger', $e->getMessage());
            }
        }
    }

    public function ubah($id, $data)
    {
        try
        {
            $s = $this->find($id);
            $s->update($data);
            session()->put('success', 'Data Has Been Updated !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function baca($id = null)
    {
        if(!empty($id))
        {
            return DB::table($this->table)->where($this->primaryKey, $id);
        }
        else
        {
            return $this->select();
        }
    }

    public function active($key_id, $value)
    {
        try
        {
            $user = Action::find($key_id)->update(['action_visible' => $value]);
            session()->flash('alert-success', 'Data Has Been Deleted !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

}
