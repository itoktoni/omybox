<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use PDF;
use Yajra\Datatables\Facades\Datatables;
use Illuminate\Support\Facades\DB;

class BarcodeController extends Controller
{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $prefix;
    public $codelength;

    public function __construct()
    {
        $this->model      = new \App\Stock();
        $this->table      = $this->model->getTable();
        $this->key        = $this->model->getKeyName();
        $this->field      = $this->model->getFillable();
        $this->datatable  = $this->model->datatable;
        $this->rules      = $this->model->rules;
        $this->searching  = $this->model->searching;
        $this->template   = 'inbound';
        $this->prefix     = date("y") . date("m").date('d');
        $this->codelength = 12;
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create()
    {
        if (request()->isMethod('POST')) {

            $validasi = [
                'barcode' => 'required|unique:stocks|min:3',
                'product_code' => 'required|min:3',
                'qty' => 'required',
                'rack_code' => 'required',
            ];

            $this->validate(request(), $validasi);
            $request = request()->all();

            $produk  = request()->get('product_code');
            $qty     = request()->get('qty');
            $barcode = request()->get('barcode');
            $reference = request()->get('reference');
            $rack = request()->get('rack_code');

            $r = DB::table('racks')->where('rack_id','=',$rack)->get();
            if($r->count() > 0){

                if(empty($reference)){

                    $pro = DB::table('products');
                    $pro->where('product_id', $produk);

                    $dp = $pro->get()->first();
                    $pro->update(['product_stock' => $dp->product_stock + $qty]);
                }

                $this->model->simpan($request);
            }
            else{
                 session()->put('danger', 'No Rack Tidak Ada !');
            }
            
            return redirect()->back();

        } else {
            return view('page.' . $this->template . '.create')->with([
                'template' => $this->template,
            ]);
        }
    }


    public function opname()
    {
        if (request()->isMethod('POST')) {
            $this->validate(request(), ['barcode' => 'required']);
            $request = request()->all();

            $produk  = request()->get('product');
            $qty     = request()->get('qty');
            $barcode = request()->get('barcode');

            $this->model->opname($request);
            return redirect()->back();

        } else {
            return view('page.' . $this->template . '.opname')->with([
                'template' => $this->template,
            ]);
        }
    }

    public function outbound()
    {
        if (request()->isMethod('POST')) {

            $rules = [
                'barcode'      => 'required|min:3',
                'product_code' => 'required|min:3',
                'reference'    => 'required|min:3',
                'qty'          => 'required',
            ];

            $this->validate(request(), $rules);
            $request = request()->all();

            $reference  = request()->get('reference');
            $produk  = request()->get('product_code');
            $qty     = request()->get('qty');
            $barcode = request()->get('barcode');

            $data_total = DB::table('stocks')->where('barcode','=',$barcode);
            $total = 0;
            if(!empty($data_total->first())){

                $total = $data_total->first()->qty;
            }

            $pengurangan = $total-$qty;
            $request['qty'] = $total-$qty;
            $this->model->out($request);

            $total = DB::table('order_detail');
            $total->where(['detail' => $reference, 'product' => $produk]);
            $d_total = $total->get()->first();
            $total->update([
                'qty_prepare' => $qty,
                'price_prepare' => $d_total->price,
                'total_prepare' => $qty * $d_total->price,
            ]);

            return redirect()->back();

        } else {
            return view('page.' . $this->template . '.outbound')->with([
                'template' => $this->template,
            ]);
        }
    }

     public function outbound_spk()
    {
        if (request()->isMethod('POST')) {

            $rules = [
                'barcode'      => 'required|min:3',
                'product_code' => 'required|min:3',
                'reference'    => 'required|min:3',
                'qty'          => 'required',
            ];

            $this->validate(request(), $rules);
            $request = request()->all();

            $reference  = request()->get('reference');
            $produk  = request()->get('product_code');
            $qty     = request()->get('qty');
            $barcode = request()->get('barcode');

            $data_total = DB::table('stocks')->where('barcode','=',$barcode);
            $total = 0;
            if(!empty($data_total->first())){

                $total = $data_total->first()->qty;
            }

            $pengurangan = $total-$qty;
            $request['qty'] = $total-$qty;
            $this->model->out($request);

            $total = DB::table('spk_detail');
            $total->where(['detail' => $reference, 'product' => $produk]);
            $d_total = $total->get()->first();
            $total->update([
                'yard_prepare' => $qty,
            ]);

            return redirect()->back();

        } else {
            return view('page.' . $this->template . '.outbound')->with([
                'template' => $this->template,
            ]);
        }
    }

    public function barcode()
    {
        $product = $product = new \App\Product();
        if (request()->isMethod('POST')) {
            $request = request()->all();
            $code = $this->Code('barcode', 'unic', $this->prefix, $this->codelength);

            $detail = [
                'unic'       => $code,
                'product'    => $request['product'],
                'qty'        => $request['qty'],
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => Auth::user()->username,
            ];

            $this->model->barcode($detail);
            return redirect()->route($this->getModule() . '_barcode', ['code' => $code]);
        } else {

            if (!empty(request()->get('code'))) {
                $code    = request()->get('code');
                $getData = $this->model->getBarcode($code);
                return view('page.' . $this->template . '.barcode')->with([
                    'product'  => $product->baca()->get(),
                    'template' => $this->template,
                    'data'     => $getData->get()->first(),
                ]);
            } else if (!empty(request()->get('print'))) {
                $code    = request()->get('print');
                $getData = $this->model->getBarcode($code);
                view()->share([
                    'code'    => $code,
                    'data'    => $getData->get()->first(),
                    'product' => $product->baca()->get(),
                ]);

                $pdf = PDF::loadView('page.' . $this->template . '.print_barcode');
                $pdf->setPaper('C7', 'landscape');
                return $pdf->stream($code . '.pdf');
            } else {

                return view('page.' . $this->template . '.'.__function__)->with([
                    'product'  => $product->baca()->get(),
                    'template' => $this->template,
                ]);
            }
        }
    }

    public function split()
    {
        $product = $product = new \App\Product();

        if (request()->isMethod('POST')) {
            $request = request()->all();
            $pecah = explode('#', request()->get('product'));

            $barcode = $pecah[0];
            $product = $pecah[1];

            $cek = DB::table('barcode')->where('unic','=',$barcode);
            if($cek->get()->count() > 0){

                DB::table('barcode')->where('unic','=',$barcode)->update(['qty' => $request['qty']]);
            }
            else{
                
                $detail = [
                    'unic'       => $barcode,
                    'product'    => $product,
                    'qty'        => $request['qty'],
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => Auth::user()->username,
                ];

                DB::table('barcode')->insert($detail);
            }

            return redirect()->route($this->getModule() . '_split', ['code' => $barcode]);
        
        } else {

            if (!empty(request()->get('code'))) {
                $code    = request()->get('code');
                $getData = $this->model->getBarcode($code);

                return view('page.' . $this->template . '.split')->with([
                   'product'  => $this->model->baca()->get(),
                    'template' => $this->template,
                    'data'     => $getData->get()->first(),
                ]);
            } else if (!empty(request()->get('print'))) {
                $code    = request()->get('print');
                $getData = $this->model->getBarcode($code);
                view()->share([
                    'code'    => $code,
                    'data'    => $getData->get()->first(),
                    'product' => $product->baca()->get(),
                ]);

                $pdf = PDF::loadView('page.' . $this->template . '.print_barcode');
                $pdf->setPaper('C7', 'potrait');
                return $pdf->stream($code . '.pdf');
            } else {

                return view('page.' . $this->template . '.'.__function__)->with([
                    'product'  => $this->model->baca()->where('qty', '>', 0)->get(),
                    'template' => $this->template,
                ]);
            }
        }
    }

    public function inbound()
    {
        $product = $product = new \App\Product();

        if (request()->isMethod('POST')) {
            $request = request()->all();
            return redirect()->route($this->getModule() . '_inbound', ['print' => $request['product']]);
        } else {

            if (!empty(request()->get('code'))) {
                $code    = request()->get('code');
                $getData = $this->model->getBarcode($code);

                return view('page.' . $this->template . '.split')->with([
                   'product'  => $this->model->baca()->get(),
                    'template' => $this->template,
                    'data'     => $getData->get()->first(),
                ]);
            } else if (!empty(request()->get('print'))) {
                $code    = request()->get('print');
                $getData = $product->baca($code)->first();
                view()->share([
                    'code'    => $code,
                    'data'    => $getData,
                    'product' => $product->baca()->get(),
                ]);

                $pdf = PDF::loadView('page.' . $this->template . '.print_inbound');
                $pdf->setPaper('C7', 'landscape');
                return $pdf->stream($code . '.pdf');
            } else {

                return view('page.' . $this->template . '.in')->with([
                    'product'  => $product->baca()->get(),
                    'template' => $this->template,
                ]);
            }
        }
    }


    function print() {

        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.print');
            return $pdf->stream($id . '.pdf');
        }
    }

    public function update()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            return view('page.' . $this->template . '.edit')->with([
                'template' => $this->template,
                'data'     => $this->validasi($getData),
                'detail'   => $this->model->getDetail($id),
                'key'      => $this->key,
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id              = collect(request()->query())->flip()->first();
                $request         = request()->all();
                $request['form'] = 'update';
                $this->model->ubah($id, $request);

                if ($request['purchase_status'] == 'DELIVERED') {

                    return redirect()->route($this->getModule() . '_read', ['code' => $id]);
                }
            }
            return redirect()->back();
        }
    }

    public function admin()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            return view('page.' . $this->template . '.admin')->with([
                'template' => $this->template,
                'data'     => $this->validasi($getData),
                'detail'   => $this->model->getDetail($id),
                'key'      => $this->key,
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id              = collect(request()->query())->flip()->first();
                $request         = request()->all();
                $file            = request()->file('files');
                $request['form'] = 'admin';
                $this->model->ubah($id, $request, $file);
            }
            return redirect()->back();
        }
    }

    public function delete()
    {
        $input = request()->all();
        $this->model->cancel(request()->get('id'));
        return redirect()->back();
    }

}
