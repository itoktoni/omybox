<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Cache;

class PriceGroup extends Model{

    protected $table = 'price_groups';
    protected $primaryKey = 'product_id';
    public $incrementing = false;
    public $timestamps = false;
    protected $fillable = [
            'product_id',
            'segmentasi_id',
            'term_of_payment_id',
            'site_id',
            'price',
    ];
    public $stock;
    public $product;
    
    public function __construct()
    {
        $this->stock = new \App\Stock();
        $this->product = new \App\Product();
    }

    public function simpan($data)
    {
        try
        {
            $this->Create($data);
            session()->put('success', 'Data Has Been Added !');
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function hapus($data)
    {
        if(!empty($data))
        {
            $data = collect($data)->flatten()->all();
            try
            {
                $this->Destroy($data);
                session()->flash('alert-success', 'Data Has Been Deleted !');
            }
            catch(\Exception $e)
            {
                session()->flash('alert-danger', $e->getMessage());
            }
        }
    }

    public function ubah($data)
    {
        try
        {
            $this->update($data);
            session()->flash('alert-success', 'Data Has Been Updated !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function getByTop()
    {
        return $this->select();
    }

    public function getByProduct()
    {
        $fields = [
                'price_groups.site_id',
                'products.product_id',
                'product_name',
                'term_of_payment_id',
                'price',
                'stock',
        ];
        $data = $this->select($fields);
        $data->Join($this->product->getTable(), $this->product->getTable().'.'.$this->getKeyName(), '=', $this->table.'.'.$this->getKeyName());
        $data->Join($this->stock->getTable(), $this->product->getTable().'.'.$this->getKeyName(), '=', $this->stock->getTable().'.'.$this->stock->getKeyName());
        $data->whereRaw('price_groups.site_id = '.$this->stock->getTable().'.site_id AND .'.$this->product->getTable().'.'.$this->product->getKeyName().'='.$this->stock->getTable().'.'.$this->stock->getKeyName());

        return $data;
    }

    public function baca($id = null)
    {
        $full = [
                'price_groups.price',
                'price_groups.product_id',
                'price_groups.segmentasi_id',
                'price_groups.site_id',
                'price_groups.term_of_payment_id',
                'term_of_payments.top_name',
        ];
        return $this->select('*', DB::raw("price as harga"));
    }

}
