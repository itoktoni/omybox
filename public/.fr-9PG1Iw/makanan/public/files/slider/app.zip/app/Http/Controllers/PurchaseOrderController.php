<?php
namespace App\Http\Controllers;

use Auth;
use DB;
use Route;
use PDF;
use Datatables;
use Mail;

class PurchaseOrderController extends Controller
{
    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $prefix;
    public $codelength;
    public $render;

    public function __construct()
    {
        $this->model      = new \App\PurcaseOrder();
        $this->table      = $this->model->getTable();
        $this->key        = $this->model->getKeyName();
        $this->field      = $this->model->getFillable();
        $this->datatable  = $this->model->datatable;
        $this->rules      = $this->model->rules;
        $this->searching  = $this->model->searching;
        $this->template   = 'po';
        $this->prefix     = "PO" . date("y") . date("m");
        $this->codelength = 10;
        $this->render     = 'page.' . $this->template . '.';
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'list');
    }

    public function list()
    {
        $total_button = 0;
        if (request()->isMethod('POST')) {
            $getData   = $this->model->baca()->latest();
            $datatable = Datatables::of($this->filter($getData))
                ->addColumn('checkbox', function ($select) {
                    $id       = $this->key;
                    $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="' . $select->$id . '">';
                    return $checkbox;
                })->addColumn('action', function ($select) use ($total_button) {
                $id     = $this->key;
                $gabung = '<div class="aksi text-center">';

                if (session()->get('akses.delivery')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_delivery', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-primary">Delivery</a> ';
                    $total_button = $total_button + 1;
                }
                if (session()->get('akses.approve')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_approve', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-warning">approve</a> ';
                    $total_button = $total_button + 1;
                }
                if (session()->get('akses.payment')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_payment', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-info">payment</a> ';
                    $total_button = $total_button + 1;
                }
                if (session()->get('akses.receive')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_receive', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-danger">receive</a> ';
                    $total_button = $total_button + 1;
                }

                $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                    'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                $total_button = $total_button + 1;
                session()->put('button', $total_button);
                return $gabung;
            });

            $awal  = request()->get('awal');
            $akhir = request()->get('akhir');

            if (!empty($awal) && !empty($awal)) {
                $datatable->where('purchase_date', '>=', $awal);
                $datatable->where('purchase_date', '<=', $akhir);
            }

            if (session()->get('akses.delivery')) {

                $datatable->Where('purchase_status', '=', 'APPROVED');
                $datatable->orWhere('purchase_status', '=', 'PREPARED');
                $datatable->orWhere('purchase_status', '=', 'DELIVERED');
                $datatable->orWhere('purchase_status', '=', 'RECEIVED');
                $datatable->orWhere('purchase_status', '=', 'COMPLETE');
            }

            if (session()->get('akses.receive')) {

                $datatable->Where('purchase_status', '=', 'DELIVERED');
                $datatable->orWhere('purchase_status', '=', 'RECEIVED');
                $datatable->orWhere('purchase_status', '=', 'COMPLETE');
            }

            if (session()->get('akses.payment')) {

                $datatable->Where('purchase_status', '=', 'RECEIVED');
                $datatable->orWhere('purchase_status', '=', 'COMPLETE');
            }

            if (request()->has('search')) {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }

        if (request()->has('code')) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);
            $payment = new \App\Payment();
            $pembayaran = $payment->getByReference($id);

            return view('page.' . $this->template . '.show')->with([
                    'fields'        => $this->datatable,
                    'data'           => $this->validasi($getData),
                    'detail'         => $this->model->getDetail($id),
                    'key'            => $this->key,
                    'payment'        => $pembayaran->get(),
                    'template'       => $this->template
                ]);
        }

        return view($this->render.__function__)->with([
            'fields'       => $this->datatable,
            'template'     => $this->template,
        ]);
    }

    public function create()
    {
        if (request()->isMethod('POST')) {
            $this->validate(request(), $this->rules);
            $code    = $this->Code($this->table, $this->key, $this->prefix, $this->codelength);
            $request = request()->all();
            $file    = request()->file('files');
            $this->model->simpan($code, $request, $file);

            $produk  = request()->get('produks');
            $qty     = request()->get('quantity');
            $price   = request()->get('price');
            $s_price = request()->get('s_price');

            for ($i = 0; $i < count(request()->get('produks')); $i++) {

                $detail = [
                    'detail'     => $code,
                    'product'    => $produk[$i],
                    'qty'        => $qty[$i],
                    'suggestion' => $s_price[$i],
                    'price'      => $price[$i],
                    'total'      => $price[$i] * $qty[$i],
                ];

                $this->model->detail($detail);
            }

            return redirect()->route($this->getModule() . '_list', ['code' => $code]);

        } else {
            $warehouse = new \App\Warehouse();
            $supplier  = new \App\Supplier();
            $product   = new \App\Product();
            return view($this->render.__function__)->with([
                'template'  => $this->template,
                'warehouse' => $warehouse->baca()->get(),
                'supplier'  => $supplier->baca()->get(),
                'product'   => $product->baca()->where('product_category', '=', 'Kain')->get(),
            ]);
        }
    }

    public function print_approval()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView($this->render . __function__);
            return $pdf->stream($id . '.pdf');
        }

        return redirect()->route($this->getModule() . '_list');
    }

    public function approve()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);
            $header    = $this->validasi($getData);
            $detail  = $this->model->getDetail($id);
            return view($this->render.__function__)->with([
                'template' => $this->template,
                'data'     => $header,
                'detail'   => $detail,
                'key'      => $this->key,
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id              = collect(request()->query())->flip()->first();
                $request         = request()->all();
                $file            = request()->file('files');
                $request['form'] = __function__;
                $this->model->ubah($id, $request, $file);

                $getData = $this->model->baca($id);
                $header    = $getData->first();
                $detail  = $this->model->getDetail($id);
                $email = [
                        'code' => $id,
                        'header' => $header,
                        'detail' => $detail,
                ];

                Mail::send('emails.po_approve', $email, function($message) use ($header) {
                        $message->to(config('mail.from.address'), config('mail.from.name'));
                        $message->to($header->email, $header->supplier_name);
                        $message->subject('Notification Purchase Order From '.config('app.name'));
                        $message->from(config('mail.from.address'), config('mail.from.name'));
                });
            }
            return redirect()->back();
        }
    }

    public function delivery()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            return view($this->render.__function__)->with([
                'template' => $this->template,
                'data'     => $this->validasi($getData),
                'detail'   => $this->model->getDetail($id),
                'key'      => $this->key,
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id              = collect(request()->query())->flip()->first();
                $request         = request()->all();
                $request['form'] = __function__;
                $this->model->ubah($id, $request);

                if ($request['purchase_status'] == 'DELIVERED') {

                    $header = $this->model->baca($id)->first();
                    $detail = $this->model->getDetail($id);
                    $email = [
                        'code' => $id,
                        'header' => $header,
                        'detail' => $detail,
                    ];

                    Mail::send('emails.po_delivery', $email, function($message) {
                            $message->to(config('mail.from.address'), config('mail.from.name'));
                            $message->to(config('website.gudang'), 'Warehouse');
                            $message->subject('Notification Delivery From Supplier');
                            $message->from(config('mail.from.address'), config('mail.from.name'));
                    });  
                    return redirect()->route($this->getModule() . '_list', ['code' => $id]);
                }
            }
            return redirect()->back();
        }
    }

    public function payment()
    {
        $payment = new \App\Payment();
        if (!empty(request()->get('code'))) {
            $id         = request()->get('code');
            $getData    = $this->model->baca($id);
            $total      = $this->model->getDetail($id)->sum('total_prepare');
            $pembayaran = $payment->getByReference($id);

            $data = $this->validasi($getData);
            return view($this->render.__function__)->with([
                'template'   => $this->template,
                'data'       => $data,
                'detail'     => $pembayaran->get(),
                'pembayaran' => $pembayaran->sum('approve_amount'),
                'tagihan'    => $total,
                'key'        => $this->key,
                'fields'     => $this->datatable,
                'account'    => DB::table('accounts')->where('account_type', '=', 'REKENING')->get(),
            ]);
        }
        if (!empty(request()->get('delete'))) {
            $id      = request()->get('delete');
            $getData = $payment->remove($id);
            return redirect()->back();

        } else {
            if (request()->isMethod('POST')) {
                $id                         = collect(request()->query())->flip()->first();
                $vprefix                    = "V" . date("y") . date("m");
                $vcodelength                = 15;
                $voucher                    = $this->Code('payments', 'payment_voucher', $vprefix, $vcodelength);
                $amount                     = request()->get('payment_amount');
                $sisa_tagihan               = 0;
                $request                    = request()->all();
                $request['payment_model']   = 'PO';
                $request['payment_type']    = 'OUT';
                $request['payment_status']  = 'APPROVED';
                $request['approve_amount']  = $amount;
                $request['approved_by']     = Auth::user()->name;
                $request['payment_voucher'] = $voucher;

                if (isset($request['sisa_tagihan'])) {
                    $sisa_tagihan = $request['sisa_tagihan'];
                }

                $file = request()->file('files');
                $unic = $this->unic(5);

                $payment->simpan($unic, $request, $file);

                $getEmail = $this->model->baca($request['reference'])->first();
                $email = $getEmail->email;
                $name = $getEmail->supplier_name;

                $data = [

                    'data' => request()->all(),
                    'voucher' => $voucher, 
                    'to' => $name, 
                ];

                Mail::send('emails.payment_to_vendor', $data, function($message) use($email,$name){
                            $message->to(config('mail.from.address'), config('mail.from.name'));
                            $message->to($email, $name);
                            $message->subject('Notification Payment to Supplier');
                            $message->from(config('mail.from.address'), config('mail.from.name'));
                    });   

                if ($amount >= $sisa_tagihan) {
                    DB::table('purchase_orders')->where('purchase_id', $request['reference'])->update(['purchase_status' => 'COMPLETE']);
                }
                return redirect()->back();
            } else {
                return view($this->render.__function__)->with([
                    'template'   => $this->template,
                    'list_order' => DB::table('purchase_orders')->where('purchase_status', '!=', 'COMPLETE')->get(),
                    'account'    => DB::table('accounts')->where('account_type', '=', 'REKENING')->get(),
                ]);

            }
        }
        return redirect()->back();
    }

    public function print_delivery()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView($this->render.__function__);
            return $pdf->stream($id . '.pdf');
        }
    }

     public function print_invoice()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView($this->render.__function__);
            return $pdf->stream($id . '.pdf');
        }
    }

    public function receive()
    {
        $receive = null;
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);
            
            return view($this->render.__function__)->with([
                'template' => $this->template,
                'data'     => $this->validasi($getData),
                'detail'   => $this->model->getDetail($id),
                'key'      => $this->key,
                'fields'   => $this->datatable,
                'receive'   => $receive,
            ]);

        } else {
            if (request()->isMethod('POST')) {
                $id              = collect(request()->query())->flip()->first();
                $request         = request()->all();
                $file            = request()->file('files');
                $request['form'] = 'receive';
                $this->model->ubah($id, $request, $file);
            }
            return redirect()->back();
        }
    }

    public function berita_acara()
    {

        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView($this->render.__function__);
            return $pdf->stream($id . '.pdf');
        }
    }

    

    public function delete()
    {
        $input = request()->all();
        $this->model->cancel(request()->get('id'));
        return redirect()->back();
    }

}
