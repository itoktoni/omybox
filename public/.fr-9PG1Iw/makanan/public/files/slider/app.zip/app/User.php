<?php
namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class User extends Authenticatable{
    use Notifiable;

    protected $table = 'users';
    protected $primaryKey = 'user_id';
    protected $fillable = [
            'user_id',
            'name',
            'email',
            'username',
            'password',
            'photo',
            'active',
            'group_user',
            'warehouse',
            'site_id',
            'nik',
            'target',
            'pencapaian',
            'gender',
            'address',
            'birth',
            'place_birth',
            'biografi',
            'handphone',
            'no_tax',
            'sales_responsible',
            'supplier_id',
            'production_id',
            'created_by',
    ];
    protected $hidden = [
            'password',
            'remember_token',
    ];
    public $searching = 'name';
    public $incrementing = false;
    public $rules = [
            'username' => 'required|unique:users|min:3',
            'email' => 'required|unique:users|min:3',
            'name' => 'required|min:3',
    ];
    public $datatable = [
            'user_id' => 'NIK',
            'name' => 'Name',
            'email' => 'Email',
            'group_user' => 'Group',
            'site_id' => 'Site',
    ];

    public function simpan($data, $code)
    {
        try
        {
            $data['password'] = bcrypt($data['password']);
            $data['created_by'] = Auth::user()->username;
            $data['user_id'] = $code;
            $data['active'] = 'N';
            $this->Create($data);
            session()->put('success', 'Data Has Been Added !');
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function filter($id, $data)
    {
        try
        {
            $filter = DB::table('filters');
            $filter->where('key', '=', $id.'')->delete();

            foreach($data as $d)
            {

                $filter->insert(['key' => $id.'',
                        'value' => $d.'']);
            }
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function filterSingle($id, $data)
    {
        try
        {
            $filter = DB::table('filters');
            $filter->where('key', '=', $id.'')->delete();
            $filter->insert(['key' => $id.'','value' => $data]);
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function ubah($id, $data, $photo = null)
    {
        try
        {
            $user = User::find($id);
            if(!empty($photo))
            {
                $name = auth()->user()->username.'.'.$photo->extension();
                $simpen = $photo->storeAs('profile', $name);
                $user->photo = $name;
            }
            $user->active = 'Y';
            $user->update($data);
            session()->put('success', 'Data Has Been Updated !');
        }
        catch(\Exception $e)
        {
            session()->put('danger', $e->getMessage());
        }
    }

    public function getDetail($id)
    {
        $select = $this->select();
        $select->leftjoin('filters', 'filters.value', '=', 'users.email');
        $select->where('key', $id);
        return $select;
    }

    public function getUserByGroupUser($id = null)
    {
        $select = $this->select();
        if(!empty($id))
        {
            $select->where('group_user', $id);
        }
        else
        {
            $select->select($this->fillable);
        }

        return $select;
    }

    public function baca($id = null)
    {
        $select = $this->select();
        if(!empty($id))
        {
            $select->where($this->primaryKey, $id);
        }
        else
        {
            $select->select($this->fillable);
        }

        return $select->latest();
    }

    function update_password($key_id, $password)
    {
        $user = User::find($key_id)->update(['password' => bcrypt($password)]) ? true : false;
        return $user;
    }

    public function active($key_id, $value)
    {
        try
        {
            $user = User::find($key_id)->update(['active' => $value]);
            session()->flash('alert-success', 'Data Has Been Deleted !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

}
