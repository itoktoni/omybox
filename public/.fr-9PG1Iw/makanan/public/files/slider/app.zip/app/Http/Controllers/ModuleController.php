<?php
namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Yajra\Datatables\Facades\Datatables;

class ModuleController extends Controller{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;

    public function __construct()
    {
        $this->model = new \App\Module();
        $this->table = $this->model->getTable();
        $this->key = $this->model->getKeyName();
        $this->field = $this->model->getFillable();
        $this->datatable = $this->model->datatable;
        $this->rules = $this->model->rules;
        $this->searching = $this->model->searching;
        $this->template = 'module';
    }

    private function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create()
    {
        if(request()->isMethod('POST'))
        {
            $this->validate(request(), $this->rules);

            $data = request()->all();
            $code = request()->get('module_code');
            $data['module_link'] = $code;
            $this->model->simpan($data);

            return redirect()->route('module_update', ['code' => $code]);
        }

        return view('page.' .$this->template. '.create')->with('template', $this->template);
    }

    public function read()
    {
        if(request()->isMethod('POST'))
        {
            $model = $this->model->baca();
            $datatable = Datatables::of($this->filter($model))
            ->addColumn('checkbox', function ($select)
            {
                $id = $this->key;
                $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="'.$select->$id.'">';
                return $checkbox;
            })
            ->addColumn('order', function ($select)
            {
                $id = $this->key;
                $checkbox = '<input type="hidden" name="kode[]" value="'.$select->module_code.'"><input type="text" name="order[]" class="form-control input-sm text-center" value="'.$select->module_sort.'">';
                return $checkbox;
            })
            ->addColumn('action', function ($select)
            {
                $id     = $this->key;
                $gabung = '<div class="aksi text-center">';
                if(session()->get('akses.update'))
                {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_update', [
                      'code' => $select->$id]) . '" class="btn btn-xs btn-primary">edit</a> ';
                }
                $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                  'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                return $gabung;
            });

            if(request()->has('search'))
            {
                $code = request()->get('code');
                $search = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }

        if(request()->has('code'))
        {
            $id = request()->get('code');
            return view('page.' .$this->template. '.show')->with([
                'fields' => $this->datatable,
                'data' => $this->validasi($this->model->baca($id)),
                'key' => $this->key,
                'template' => $this->template
            ]);
        }

        return view('page.' .$this->template. '.table')->with(['fields' => $this->datatable,
            'template' => $this->template]);
    }

    public function update()
    {
        //dd(request()->all());
        $id = request()->get('code');
        if(!empty($id))
        {
            $model = $this->validasi($this->model->baca($id));
            $controller = $model->module_controller;
            $group = new \App\GroupModule();
            $list_group = $group->getGroupByModule($id)->get();
            $user = new \App\User();
            $filter = $user->getFillable();
            $f = $model->module_filters;

            if(strpos($f, ','))
            {
                $get = explode(',', $model->first()->module_filters);
            }
            else
            {
                $get = $f;
            }

            foreach($this->getMethod($controller) as $c)
            {
                $act = DB::table('module_connection_action');
                $act->where('conn_ma_action', '=', $id.'_'.$c);
                $act->where('conn_ma_module', '=', $id);
                $act->get()->first();
                
                $status = false;
                if($act->count() > 0)
                {
                    $status = true;
                }
                $item[] = [
                    'code' => $c,
                    'status' => $status
                ];
            }

            return view('page.' .$this->template. '.edit')->with([
                'template' => $this->template,
                'data' => $model,
                'controller' => $controller,
                'group' => $list_group,
                'filter' => $filter,
                'detail' => $get,
                'fungsi' => $this->getMethod($controller),
                'act' => $item,
                'list' => $this->model->getModule($id)->get()->toArray(),
                'key' => $this->key
            ]);
        }
        else
        {
            if(request()->isMethod('POST'))
            {
                $id = collect(request()->query())->flip()->first();
                $requestData = request()->all();
                
                $this->model->ubah($id, $requestData);

                if(request()->exists('act'))
                {
                    $this->model->saveConnectionAction($requestData);
                }

                if(request()->exists('group'))
                {
                    $this->model->saveGroupModule($id, request()->get('group'));
                }
            }
             return redirect()->route('module_read');
        }
    }

    public function delete()
    {

        $action = request()->get('action');
        if($action == 'delete'){

            $code = request()->get('id');
            for($i=0;$i < count($code); $i++ ){

                $kode = $code[$i];
                $this->model->hapus($kode);
            }
        }

        if($action == 'sort'){
            $sort = request()->get('order');
            $kode = request()->get('kode');
            for($i=0;$i < count($sort); $i++ ){

                $code = $kode[$i];
                $order = $sort[$i];
                $this->model->saveSort($code,$order);
            }
        }

        return redirect()->back();
    }

}
