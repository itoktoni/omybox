<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model {

    protected $table      = 'customers'; //nama table
    protected $primaryKey = 'customer_id'; //nama primary key
    protected $fillable   = [ //field yang mau di save ke database
    'customer_id',
    'customer_name',
    'customer_phone',
    'customer_address',
    'customer_contact',
    'site_id',
    'city_id',
    'province_id',
    'email',
    'created_at',
    'updated_at',
    'customer_status',
    'customer_email',
];
    public $searching    = 'customer_name'; //default pencarian ketika di cari
    public $timestamps   = true; //kalau mau automatic update tanggal ketika save atau edit ubah jadi true
    public $incrementing = false; //kalau id nya mau dibuatkan otomatis dari laravel 1,2,3
    public $rules        = [ //validasi https://laravel.com/docs/5.5/validation
    'customer_name' => 'required|min:3',
    'email' => 'required',
    'customer_address' => 'required',
];
    public $datatable    = [ //field dan header buat di show ke list table 
    'customer_id'   => 'ID Customer',
    'customer_name'   => 'Name',
    'customer_contact' => 'Contact',
    'customer_phone' => 'Phone',
    'customer_email' => 'Email',
    'customer_status' => 'Status',
];

public function simpan($code, $request)
{
    try
    {
        $request['customer_status'] = 'PROSPECT';
        $this->Create($request);
        session()->put('success', 'Data Has Been Added !');
    }
    catch(Exception $ex)
    {
        session()->put('danger', $ex->getMessage());
    }
}

public function hapus($data)
{
    if(!empty($data))
    {
        $data = collect($data)->flatten()->all();
        try
        {
            $this->Destroy($data);
            session()->flash('alert-success', 'Data Has Been Deleted !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }
}

public function ubah($id, $request, $file=null)
{
    try
    {
            if(!empty($file)) //handle images
            {

                $name   = $id . '.' . $file->extension();
                $simpen = $file->storeAs('customer', $name);

                $request['customer_images'] = $name;
            }
            
            $s = $this->find($id);
            $s->update($request);
            
            session()->put('success', 'Data Has Been Updated !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function baca($id = null)
    {
        if(!empty($id))
        {
            return $this->where($this->primaryKey, $id);
        }
        else
        {
            return $this->select();
        }
    }

}
