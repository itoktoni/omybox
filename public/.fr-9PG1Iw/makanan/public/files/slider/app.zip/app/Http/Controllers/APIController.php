<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class APIController extends Controller{

    public function index()
    {
        return view('home');
    }

    public function master()
    {
        return view('master');
    }

    public function permision()
    {
        return view('errors.permision');
    }

    public function query()
    {

       
    }

}
