<?php

namespace App\Http\Controllers;

use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use PDF;

class ReportSalesController extends Controller
{
    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $read;
    public $payment_model;

    public function __construct()
    {
        $this->model         = new \App\Warehouse();
        $this->table         = $this->model->getTable();
        $this->key           = $this->model->getKeyName();
        $this->field         = $this->model->getFillable();
        $this->datatable     = $this->model->datatable;
        $this->rules         = $this->model->rules;
        $this->searching     = $this->model->searching;
        $this->template      = 'sales';
        $this->payment_model = [
            'ECT' => 'Lain-lain',
            'PO'  => 'Purchase Order (PO)',
            'SO'  => 'Sales Order (SO)',
            'SPK' => 'Produksi Batik (SPK)',
            'FEE' => 'Fee Sales (FEE)',
            'DO'  => 'Delivery Order (DO)',
        ];
    }

    public function index()
    {
        return '';
    }

    public function penjualan_product()
    {

        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $customer   = request()->get('customer');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

       
        if (!empty($start) && !empty($end)) {
            $data = DB::table('orders');
            $data->join('customers', 'customers.customer_id', '=', 'orders.customer_id');
            $data->join('users', 'users.email', '=', 'orders.email');
            $data->join('sites', 'sites.site_id', '=', 'customers.site_id');
            $data->join('order_detail', 'order_detail.detail', '=', 'orders.order_id');
            $data->join('products', 'order_detail.product', '=', 'products.product_id');
            $data->select([

                'order_id',
                'customers.customer_name',
                'sites.site_name',
                'users.name',
                'order_date',
                'order_delivery_date',
                'order_status',
                'products.product_id',
                'products.product_code',
                'products.product_grouping',
                'products.product_name',
                'order_detail.qty_prepare',
                'order_detail.price',
                'order_detail.total',
                'products.product_category',
                'products.product_unit',
                'products.product_size',
                'products.product_weight',
                'products.product_commision',
                'orders.airbill',
                'orders.courier',
                'orders.courier_service',
                'orders.qty_total',
                'orders.estimasi_cost',
                'orders.delivery_cost',
                'products.product_commision',
            ]);

            if (!empty($start)) {
                $data->where('order_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('order_date', '<=', $end);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }
            if (!empty($size)) {
                $data->where('products.product_size', '=', $size);
            }
            if (!empty($customer)) {
                $data->where('orders.customer_id', '=', $customer);
            }
            if (!empty($category)) {
                $data->where('products.product_category', '=', $category);
            }
            if (!empty($user)) {
                $data->where('orders.email', '=', $user);
            }
            if (!empty($site)) {
                $data->where('customers.site_id', '=', $site);
            }
            if (!empty($kurir)) {
                $data->where('orders.courier', '=', $kurir);
            }
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $sales = request()->get('sales');
            $data->where('orders.email','=',$sales);
            $user    = new \App\User();
            $getData = $user->baca(Auth::user()->user_id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => $data->get(),
            ]);

            $pdf = PDF::loadView('report.' . $this->template . '.print_penjualan');
            return $pdf->stream('penjualan' . '.pdf');

        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.penjualan')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

    public function komisi()
    {
        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $customer   = request()->get('customer');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {

             $data = DB::table('orders');
            $data->join('order_detail','order_detail.detail','=','orders.order_id');
            $data->join('users', 'users.email', '=', 'orders.email');
            $data->join('customers', 'customers.customer_id', '=', 'orders.customer_id');
            $data->join('products','order_detail.product','=','products.product_id');
            $data->where('products.product_category','=','Batik');
            $data->groupBy('order_id');

            $data->select([

                'order_id',
                'customers.customer_name',
                'users.name as sales_name',
                'order_date',
                'order_delivery_date',
                'order_status',
                'orders.airbill',
                'orders.courier',
                'orders.courier_service',
                'orders.estimasi_cost',
                'orders.delivery_cost',
            ]);

            if (!empty($start)) {
                $data->where('order_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('order_date', '<=', $end);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }
            if (!empty($size)) {
                $data->where('products.product_size', '=', $size);
            }
            if (!empty($customer)) {
                $data->where('orders.customer_id', '=', $customer);
            }
            if (!empty($category)) {
                $data->where('products.product_category', '=', $category);
            }
            if (!empty($user)) {
                $data->where('orders.email', '=', $user);
            }
            if (!empty($kurir)) {
                $data->where('orders.courier', '=', $kurir);
            }
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $data->where('users.email','=',request()->get('sales'));
            // dd($data->get());

            $items = array();
            $total  = 0;
            foreach ($data->get() as $value) {

                $onvalue = DB::table('order_detail')
                    ->select([DB::raw('(SUM(qty_prepare * price)) as jumlah')])
                    ->where('detail', '=', $value->order_id);

                $jumlah = 0;
                if (!empty($onvalue->first())) {
                    $getValue = $onvalue->first();
                    $jumlah   = $getValue->jumlah;
                }

                $onproduct = DB::table('order_detail')
                    ->join('products','products.product_id','=','order_detail.product')
                    ->select([DB::raw('(SUM(qty_prepare)) as total')])
                    ->where('product_category','=','Batik')
                    ->where('detail', '=', $value->order_id);    

                $product = 0;
                if (!empty($onproduct->first())) {
                    $getProduct = $onproduct->first();
                    $product    = $getProduct->total;
                }

                $onpembayaran = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('payment_type', '=', 'IN')
                    ->where('reference', '=', $value->order_id);

                $pembayaran = 0;
                if (!empty($onpembayaran->first())) {
                    $getPembayaran = $onpembayaran->first();
                    $pembayaran    = $getPembayaran->amount;
                }

                $onpembayaran_finance_fee = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'OUT')
                    ->where('payment_model', '=', 'FEE');

                $pembayaran_finance_fee = 0;
                if (!empty($onpembayaran_finance_fee->first())) {
                    $getPembayaran_finance_fee = $onpembayaran_finance_fee->first();
                    $pembayaran_finance_fee    = $getPembayaran_finance_fee->amount;
                }

                $komisi = empty(request()->get('komisi')) ? 0 : request()->get('komisi');
                $fix = $product * config('website.komisi');
                $total = $total + $fix;

                $items[] = [
                    'sales_name'          => $value->sales_name,
                    'order_id'            => $value->order_id,
                    'customer_name'       => $value->customer_name,
                    'order_delivery_date' => $value->order_delivery_date,
                    'order_status'        => $value->order_status,
                    'pcs'                 => $product,
                    'airbill'             => $value->airbill,
                    'courier'             => $value->courier,
                    // 'order_date'          => $value->order_date,
                    // 'service'             => $value->courier_service,
                    // 'estimasi_cost'       => $value->estimasi_cost,
                    'delivery_cost'       => $value->delivery_cost,
                    'tagihan'              => $jumlah + $value->delivery_cost,
                    'transfer'             => $pembayaran,
                    'finance'           => $pembayaran,
                    'komisi'               => $fix,
                    'net_komisi'           => ($product * config('website.komisi')) - $value->delivery_cost,
                    'finance'               => $pembayaran_finance_fee,
                ];
            }

            $user    = new \App\User();
            $getData = $user->baca(Auth::user()->user_id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => collect($items),
                'total' => $total,
            ]);

            $pdf = PDF::loadView('report.' . $this->template . '.print_komisi');
            $pdf->setPaper('a4', 'landscape');
            return $pdf->stream('komisi' . '.pdf');

        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.komisi')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

}
