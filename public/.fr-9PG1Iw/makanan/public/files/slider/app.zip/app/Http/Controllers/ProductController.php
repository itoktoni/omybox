<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Yajra\Datatables\Facades\Datatables;

class ProductController extends Controller {

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;

    public function __construct()
    {
        $this->model      = new \App\Product();
        $this->table      = $this->model->getTable();
        $this->key        = $this->model->getKeyName();
        $this->field      = $this->model->getFillable();
        $this->datatable  = $this->model->datatable;
        $this->rules      = $this->model->rules;
        $this->searching  = $this->model->searching;
        $this->template   = 'product';
        $this->prefix     = "P" . date("m") . date("y");
        $this->codelength = 8;
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create()
    {
        // dd(request()->all());
        if(request()->isMethod('POST'))
        {
            $this->validate(request(), $this->rules);

            $code                  = $this->Code($this->table, $this->key, $this->prefix, $this->codelength);
            $request               = request()->all();
            $request['product_id'] = $code;
            $request['product_code'] = request()->get('product_segmentasi').request()->get('size_id');
            $file                  = request()->file('files');
            $request['product_description'] = htmlentities(request()->get('product_description'));
            $this->model->simpan($code, $request, $file);
        }

        $unit = new \App\Unit();
        $category = new \App\Category();
        $segmentasi = new \App\Segmentasi();
        $size = new \App\Size();
        $material = new \App\Material();
        return view('page.' .$this->template. '.create')->with([
            'template' => $this->template,
            'unit' => $unit->baca()->get(),
            'size' => $size->baca()->get(),
            'category' => $category->baca()->get(),
            'segmentasi' => $segmentasi->baca()->get(),
            'material' => $material->baca()->get(),
        ]);
    }

    public function read()
    {
        if(request()->isMethod('POST'))
        {
            $getData   = $this->model->getStock();
            $datatable = Datatables::of($this->filter($getData))
            ->addColumn('checkbox', function ($select)
            {
                $id       = $this->key;
                $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="' . $select->$id . '">';
                return $checkbox;
            })
            ->addColumn('product_images', function ($select) {
                    $images       = asset('public/files/product/'.$select->product_images);
                    $data = '<img style="height:100px;" src="'.$images.'" alt="">';
                    return $data;
                })
            ->addColumn('action', function ($select){
                $id     = $this->key;
                $gabung = '<div class="aksi text-center">';
                if(session()->get('akses.update'))
                {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_update', [
                      'code' => $select->$id]) . '" class="btn btn-xs btn-primary">edit</a> ';
                }
                $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                  'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                return $gabung;
            });

            if(request()->has('search'))
            {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }
        if(request()->has('code'))
        {
            $id   = request()->get('code');
            $data = $this->model->baca($id);

            return view('page.' .$this->template. '.show')->with([
              'fields'   => $this->datatable,
              'data'     => $this->validasi($data),
              'key'      => $this->key,
              'template' => $this->template
          ]);
        }

    return view('page.' .$this->template. '.table')->with([
      'fields'   => $this->datatable,
      'template' => $this->template
  ]);
}

public function update()
{

    $id = request()->get('code');
    if(!empty($id))
    {
        $getData = $this->model->baca($id);
        $unit = new \App\Unit();
        $category = new \App\Category();
        $segmentasi = new \App\Segmentasi();
        $size = new \App\Size();
        $material = new \App\Material();
        return view('page.' .$this->template. '.edit')->with([
          'template' => $this->template,
          'unit' => $unit->baca()->get(),
          'size' => $size->baca()->get(),
          'category' => $category->baca()->get(),
          'segmentasi' => $segmentasi->baca()->get(),
          'material' => $material->baca()->get(),
          'data'     => $this->validasi($getData),
          'key'      => $this->key
      ]);
    }
    else
    {
        if(request()->isMethod('POST'))
        {
            $id          = collect(request()->query())->flip()->first();
            $requestData = request()->all();
            $file        = request()->file('files');
            $this->model->ubah($id, $requestData, $file);
        }
        return redirect()->route($this->getModule() . '_read');
    }
}

public function delete()
{
    $input = request()->all();
    $this->model->hapus($input);

    return redirect()->back();
}

}
