<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use PDF;
use Yajra\Datatables\Facades\Datatables;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;

class PaymentController extends Controller
{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $read;
    public $prefix;
    public $codelength;
    public $payment_model;

    public function __construct()
    {
        $this->model         = new \App\Payment();
        $this->table         = $this->model->getTable();
        $this->key           = $this->model->getKeyName();
        $this->field         = $this->model->getFillable();
        $this->datatable     = $this->model->datatable;
        $this->rules         = $this->model->rules;
        $this->searching     = $this->model->searching;
        $this->template      = 'payment';
        $this->prefix        = "PO" . date("y") . date("m");
        $this->codelength    = 10;
        $this->payment_model = ['ECT' => 'Lain-lain', 'PO' => 'Purchase Order (PO)', 'SO' => 'Sales Order (SO)', 'SPK' => 'Produksi Batik (SPK)', 'FEE' => 'Fee Sales (FEE)', 'DO' => 'Delivery Order (DO)', 'ONGKIR' => 'Ongkos Kirim'];
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create()
    {
        if (request()->isMethod('POST')) {
            
            $this->validate(request(), $this->rules);
            $code        = $this->Code($this->table, $this->key, $this->prefix, $this->codelength);
            $vprefix     = "V" . date("y") . date("m");
            $vcodelength = 15;
            $voucher     = $this->Code('payments', 'payment_voucher', $vprefix, $vcodelength);

            $request                    = request()->all();
            $request['payment_voucher'] = $voucher;
            $request['approved_by']     = Auth::user()->name;
            $request['approve_date']     = date('Y-m-d H:i:s');

            $file = request()->file('files');
            $this->model->simpan($code, $request, $file);

            return redirect()->back();
        }

        $account = new \App\Account();
        return view('page.' . $this->template . '.create')->with([
            'template' => $this->template,
            'account'  => $account->baca()->get(),
            'model'    => collect($this->payment_model),
        ]);
    }

    public function read()
    {
        if (request()->isMethod('POST')) {
            $getData   = $this->model->baca()->latest();
            $datatable = Datatables::of($this->filter($getData))
                ->addColumn('account_from', function ($select) {
                    $id      = $select->payment_id;
                    $account = $select->account_from;
                    $data    = DB::table('accounts')->where('account_id', '=', $account)->get()->first();
                    if (isset($data)) {
                        return $data->account_name;
                    } else {
                        return $select->account_from;
                    }
                })->addColumn('checkbox', function ($select) {
                $id       = $this->key;
                $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="' . $select->$id . '">';
                return $checkbox;
            })->addColumn('payment_amount', function ($select) {
                return '<strong class="text-right">' . number_format($select->payment_amount) . '</strong>';
            })->addColumn('action', function ($select) {
                $id     = $this->key;
                $gabung = '<div class="aksi text-center">';
                if (session()->get('akses.update')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_update', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-primary">edit</a> ';
                }
                $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                    'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a>';
                $gabung = $gabung . ' <a target="_target" href="' . asset('public/files/payment/' . $select->payment_attachment) . '" class="btn btn-xs btn-danger">files</a></div>';
                return $gabung;
            });

            if (request()->has('search')) {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }
        if (request()->has('code')) {
            $id   = request()->get('code');
            $data = $this->model->baca($id);

            return view('page.' . $this->template . '.show')->with([
                'fields'   => $this->datatable,
                'data'     => $this->validasi($data),
                'key'      => $this->key,
                'template' => $this->template,
            ]);
        }

        return view('page.' . $this->template . '.table')->with([
            'fields'   => $this->datatable,
            'template' => $this->template,
        ]);
    }

    public function print() {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);
            $account = new \App\Account();
            $from    = $account->baca($getData->first()->account_from)->first();
            if (empty($from)) {
                $from = $getData->first()->account_from;
            } else {
                $from = $getData->first()->account_from;
            }
            view()->share([
                'data'    => $this->validasi($getData),
                'account' => $from,
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.print');
            return $pdf->stream($id . '.pdf');
        }

        return redirect()->route($this->getModule() . '_read');
    }

    public function update()
    {
        $id = request()->get('code');
        if (!empty($id)) {
            $account = new \App\Account();
            $getData = $this->model->baca($id);
            $data    = $this->validasi($getData);
            $delivery = 0;
            $total = 0;

            if($data->payment_model == 'SO'){
                $getModel   = new \App\Order(); 
                $total      = $getModel->getDetail($getData->first()->reference)->sum('total');
                $delivery      = $getModel->baca($getData->first()->reference)->first()->estimasi_cost;
            }
            elseif($data->payment_model == 'ONGKIR'){
                $getModel   = new \App\Order(); 
                $total      = $getModel->getDetail($getData->first()->reference)->sum('total');
                $delivery      = $getModel->baca($getData->first()->reference)->first()->delivery_cost;
            }
            elseif($data->payment_model == 'PO'){
                $getModel   = new \App\PurcaseOrder(); 
                $total      = $getModel->getDetail($getData->first()->reference)
                ->sum('total_prepare');
            }
            elseif($data->payment_model == 'SPK'){
                $getModel   = new \App\SPK(); 
                $total      = $getModel->getDetail($getData->first()->reference)
                ->sum('total_prepare');
            }

            $pembayaran = $this->model->getByReference($getData->first()->reference)
            ->where('payment_status','=','APPROVED')->sum('approve_amount');
            $jumlah = $total - $pembayaran;
            return view('page.' . $this->template . '.edit')->with([
                'template' => $this->template,
                'data'     => $data,
                'key'      => $this->key,
                'tagihan'    => $jumlah,
                'delivery'    => $delivery,
                'account'  => $account->baca()->get(),
                'model'    => collect($this->payment_model)->get($data->payment_model),
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id          = collect(request()->query())->flip()->first();
                $request = request()->all();
                $this->model->ubah($id, $request);

                $kirim = request()->get('email');
                $header = $this->model->baca($id)->first();
                $data = [

                        'data' => request()->all(),
                        'voucher' => $header->payment_voucher, 
                        'to' => request()->get('payment_person'), 
                    ];

                Mail::send('emails.payment_approval', $data, function($message) use($kirim){
                            $message->to(config('mail.from.address'), config('mail.from.name'));
                            if(!empty($kirim)){
                                $message->to($kirim, $kirim);
                            }
                            $message->subject('Notification Payment From Sales');
                            $message->from(config('mail.from.address'), config('mail.from.name'));
                }); 


                if(isset($request['total_tagihan'])){
                    if($request['approve_amount'] >= $request['total_tagihan'] && $request['payment_type'] == 'IN' && $request['payment_status'] == 'APPROVED'){

                        DB::table('orders')
                        ->where('order_id','=',$request['reference'])
                        ->update([
                            'order_status' => 'PAID',
                        ]);

                        $order = new \App\Order();
                        $code = $request['reference'];
                        $get = $order->baca($code)->first();
                        $customer = $get->customer_name;
                        $sales = $get->name;

                        $email = [
                            'code' => $code,
                            'customer' => $customer,
                            'sales' => $sales,
                            'header' => $get,
                            'detail' => $order->getDetail($code),
                        ];

                        Mail::send('emails.warehouse', $email, function($message) use ($kirim) {
                                          if(!empty($kirim)){
                                            $message->to($kirim, $kirim);
                                          }
                                          $message->to(config('website.gudang'), config('mail.from.name'));
                                          $message->to(config('mail.from.address'), config('mail.from.name'));
                                          $message->subject('Notification Order From Sales');
                                          $message->from(config('mail.from.address'), config('mail.from.name'));
                                }); 
                    }
                }
            }
            return redirect()->back();
        }
    }

    public function delete()
    {
        $input = request()->all();
        $this->model->hapus($input);

        return redirect()->back();
    }

}
