<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Mail;
use DB;

class PublicController extends Controller
{
    public function index()
    {
        $slider = new \App\Slider();
        $product = new \App\Product();
        // dd($product->baca()->GroupBy('product_segmentasi')->get());
        return View('frontend.'.config('website.frontend').'.pages.home')
        ->with([
            'slider' => $slider->baca()->get(),
            'product' => $product->baca()->GroupBy('product_segmentasi')->get(),
        ]);
    }  

    public function cara_belanja()
    {
        return View('frontend.'.config('website.frontend').'.pages.cara_belanja');
    } 

    public function marketing()
    {
        $site = new \App\Site();
        $user = DB::table('users')->where('group_user','=','sales')->get(); 
        return View('frontend.'.config('website.frontend').'.pages.marketing')->with([
            'site' => $site->all(),
            'user' => $user,
        ]);;
    }  

    public function about()
    {
        return View('frontend.'.config('website.frontend').'.pages.about');
    }  

    public function contact()
    {
        if(request()->isMethod('POST')){
            
            if (request()->has('g-recaptcha-response')) {
                $captcha = request()->get('g-recaptcha-response');
                $secret   = '6Lca37oUAAAAAGnXo14V8n30RU69QhoJsZu_W1UF';
                $response = file_get_contents(
                    "https://www.google.com/recaptcha/api/siteverify?secret=" . $secret . "&response=" . $captcha . "&remoteip=" . $_SERVER['REMOTE_ADDR']
                );
                // use json_decode to extract json response
                $response = json_decode($response);
            
                if ($response->success === false) {
                
                    return redirect()->back()->withErrors(['captcha' => 'You are Spammer']);
                }
                
                if ($response->score >= 0.8) {
                    
                    $data = [
                        'email' => request()->get('email'),
                        'name' => request()->get('name'),
                        'header' => 'Notification Information From Customer',
                        'phone' => request()->get('mobile'),
                        'description' => request()->get('description'),
                    ];
        
                    $from = request()->get('email');
                    $name = request()->get('name');
        
                    $request = request()->all();
                    $this->validate(request(),[
                        'email' => 'email|required',
                        'name' => 'required',
                        'description' => 'required',
                    ]);
                    
                    try {
                            Mail::send('emails.contact', $data, function($message) use ($from,$name) {
                                    $message->to(config('mail.from.address'), config('mail.from.name'));
                                    $message->subject('Notification Information From Customer');
                                    $message->from(config('mail.from.address'), config('mail.from.name'));
                            });    
                        } catch (Exception $e) {
                           // return redirect()->back();
                        }
        
                    return redirect()->back();    
                }
            }

                

        }

        $site = new \App\Site();
        $user = DB::table('users')->where('group_user','=','sales')->get();

        return View('frontend.'.config('website.frontend').'.pages.contact')->with([
            'site' => $site->all(),
            'user' => $user,
        ]);
    }  

    public function konfirmasi()
    {
        if(request()->isMethod('POST')){

            dd(request()->all());
        }
        return View('frontend.'.config('website.frontend').'.pages.konfirmasi');
    } 

    public function catalog()
    {
        // dd(session()->all());

        if(request()->isMethod('POST')){

            $category = request()->get('category');
            $segmentasi = request()->get('segmentasi');
            $material = request()->get('material');

            if(isset($category)){
                session()->put('category', request()->get('category'));
            }
            else{
                session()->forget('category');
            }
            if(isset($segmentasi)){
                session()->put('segmentasi', request()->get('segmentasi'));
            }
            else{
                session()->forget('segmentasi');
            }
            if(isset($material)){
                session()->put('material', request()->get('material'));
            }
            else{
                session()->forget('material');
            }
        }

        $sort = request()->get('sort');
        $product = new \App\Product();
        $segmentasi = new \App\Segmentasi();
        $category = new \App\Category();
        $material = new \App\Material();
        $data_product = $product->getStock();

        if(session()->has('category')){
            $data_product->whereIn('product_category',session()->get('category'));
        }

        if(session()->has('material')){
            $data_product->whereIn('product_material',session()->get('material'));
        }

        if(session()->has('segmentasi')){
            $data_product->whereIn('product_segmentasi',session()->get('segmentasi'));
        }

        if(!empty($sort)){
            if($sort == 'new'){

                $data_product->latest();
            }
            elseif($sort == 'low'){

                $data_product->orderBy('product_harga_jual', 'asc');
            }
            elseif($sort == 'high'){

                $data_product->orderBy('product_harga_jual', 'desc');
            }
        }

        return View('frontend.'.config('website.frontend').'.pages.catalog')->with([
            'product' => $data_product->paginate(6),
            'segmentasi' => $segmentasi->baca()->get(),
            'material' => $material->baca()->get(),
            'category' => $category->baca()->get(),
        ]);
    } 

    public function single($id)
    {
        if(!empty($id)){
            $product = new \App\Product();
            $data = $product->getStock($id)->first();
            return View('frontend.'.config('website.frontend').'.pages.single')->with('data', $data);
        }

    } 

    public function segment($id)
    {
        $segmentasi = new \App\Segmentasi();
        $category = new \App\Category();
        $material = new \App\Material();
        if(!empty($id)){
            $product = new \App\Product();
            $data = $product->segment($id)->paginate(6);
            return View('frontend.'.config('website.frontend').'.pages.catalog')->with([
                'product' => $data,
                'segmentasi' => $segmentasi->baca()->get(),
                'category' => $category->baca()->get(),
                'material' => $material->baca()->get(),
            ]);
        }

    } 
}
