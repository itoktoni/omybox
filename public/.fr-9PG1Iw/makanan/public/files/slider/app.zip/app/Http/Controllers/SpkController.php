<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;
use PDF;
use Yajra\Datatables\Facades\Datatables;

class SpkController extends Controller
{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $prefix;
    public $codelength;

    public function __construct()
    {
        $this->model      = new \App\SPK();
        $this->table      = $this->model->getTable();
        $this->key        = $this->model->getKeyName();
        $this->field      = $this->model->getFillable();
        $this->datatable  = $this->model->datatable;
        $this->rules      = $this->model->rules;
        $this->searching  = $this->model->searching;
        $this->template   = 'spk';
        $this->prefix     = "SPK" . date("y") . date("m");
        $this->codelength = 10;
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create()
    {
        if (request()->isMethod('POST')) {
            $this->validate(request(), $this->rules);
            $code    = $this->Code($this->table, $this->key, $this->prefix, $this->codelength);
            $request = request()->all();
            $file    = request()->file('files');
            $this->model->simpan($code, $request, $file);

            $produk = request()->get('produks');
            $qty    = request()->get('quantity');
            $yard   = request()->get('yard');
            $price  = request()->get('price');

            for ($i = 0; $i < count(request()->get('produks')); $i++) {

                $detail = [
                    'detail'     => $code,
                    'product'    => $produk[$i],
                    'qty'        => $qty[$i],
                    'price'      => $price[$i],
                    'yard'       => $yard[$i],
                    'total'      => $price[$i] * $qty[$i],
                    'total_yard' => $yard[$i] * $qty[$i],
                ];

                $this->model->detail($detail);
            }

            // dd($outbound);

            $outbound = DB::table('spk_detail')
                ->select(['detail', 'product_from'])
                ->addSelect(DB::raw('sum(qty) as qty_out'))
                ->addSelect(DB::raw('sum(total_yard) as yard_out'))
                ->leftJoin('converters', 'converters.product_to', 'spk_detail.product')
                ->where('detail', $code)
                ->groupBy('product_from')->get();
            // dd($outbound);

            $data_out = [];
            $tambah   = 0;
            foreach ($outbound as $out) {

                $data_out[$tambah]['detail_out']  = $out->detail;
                $data_out[$tambah]['product_out'] = $out->product_from;
                $data_out[$tambah]['qty_out']     = $out->qty_out;
                $data_out[$tambah]['yard_out']    = $out->yard_out;
                DB::table('spk_outbound')->insert($data_out[$tambah]);
                $tambah++;
            }

            // dd($data_out);

            return redirect()->route($this->getModule() . '_read', ['code' => $code]);

        } else {
            $production = new \App\Production();
            $product    = new \App\Product();

            return view('page.' . $this->template . '.create')->with([
                'template'   => $this->template,
                'production' => $production->baca()->get(),
                'product'    => $product->baca()->select(
                    array('product_id', 'product_harga_beli', 'product_name', 'product_value')
                )->join('converters', 'products.product_id', '=', 'converters.product_to')->get(),
            ]);
        }
    }

    public function payment()
    {
        $payment = new \App\Payment();
        if (!empty(request()->get('code'))) {
            $id         = request()->get('code');
            $getData    = $this->model->baca($id);
            $total      = $this->model->getDetail($id)->sum('total_prepare');
            $pembayaran = $payment->getByReference($id);

            $data = $this->validasi($getData);
            return view('page.' . $this->template . '.payment')->with([
                'template'   => $this->template,
                'data'       => $data,
                'detail'     => $pembayaran->get(),
                'pembayaran' => $pembayaran->sum('approve_amount'),
                'tagihan'    => $total,
                'key'        => $this->key,
                'fields'     => $this->datatable,
                'account'    => DB::table('accounts')->where('account_type', '=', 'REKENING')->get(),
            ]);
        }
        if (!empty(request()->get('delete'))) {
            $id  = request()->get('delete');
            $del = $payment->remove($id);
            return redirect()->back();
        } else {
            if (request()->isMethod('POST')) {
                $id                         = collect(request()->query())->flip()->first();
                $vprefix                    = "V" . date("y") . date("m");
                $vcodelength                = 15;
                $voucher                    = $this->Code('payments', 'payment_voucher', $vprefix, $vcodelength);
                $amount                     = request()->get('payment_amount');
                $sisa_tagihan               = 0;
                $request                    = request()->all();
                $request['payment_model']   = 'SPK';
                $request['payment_type']    = 'OUT';
                $request['payment_status']  = 'APPROVED';
                $request['approve_amount']  = $amount;
                $request['approved_by']     = Auth::user()->name;
                $request['payment_voucher'] = $voucher;

                if (isset($request['sisa_tagihan'])) {
                    $sisa_tagihan = $request['sisa_tagihan'];
                }

                $file = request()->file('files');
                $unic = $this->unic(5);

                $payment->simpan($unic, $request, $file);

                $getEmail = $this->model->baca($request['reference'])->first();
                $email    = $getEmail->email;
                $name     = $getEmail->production_name;

                $data = [

                    'data'    => request()->all(),
                    'voucher' => $voucher,
                    'to'      => $name,
                ];

                try {

                    Mail::send('emails.payment_to_vendor', $data, function ($message) use ($email, $name) {
                        $message->to(config('mail.from.address'), config('mail.from.name'));
                        $message->to($email, $name);
                        $message->subject('Notification Payment to Penjahit');
                        $message->from(config('mail.from.address'), config('mail.from.name'));
                    });

                } catch (Exception $e) {

                }

                if ($amount >= $sisa_tagihan) {
                    DB::table('spk')->where('spk_id', $request['reference'])->update(['spk_status' => 'COMPLETE']);
                }

                return redirect()->back();
                // return redirect()->route($this->getModule().'_payment', ['code' => $request['reference']]);
            } else {
                return view('page.' . $this->template . '.payment')->with([
                    'template'   => $this->template,
                    'list_order' => DB::table('spk')->where('spk_status', '!=', 'COMPLETE')->get(),
                    'account'    => DB::table('accounts')->where('account_type', '=', 'REKENING')->get(),
                ]);

            }
        }
        return redirect()->back();
    }

    public function read()
    {
        $total_button = 0;
        if (request()->isMethod('POST')) {
            $getData   = $this->model->baca()->latest();
            $datatable = Datatables::of($this->filter($getData))
                ->addColumn('checkbox', function ($select) {
                    $id       = $this->key;
                    $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="' . $select->$id . '">';
                    return $checkbox;
                })->addColumn('action', function ($select) use ($total_button) {
                $id     = $this->key;
                $gabung = '<div class="aksi text-center">';
                if (session()->get('akses.update') && $select->spk_status != 'COMPLETE') {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_update', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-primary">edit</a> ';
                    $total_button = $total_button + 1;
                }
                
                if (session()->get('akses.manual') && $select->spk_status != 'COMPLETE') {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_manual', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-primary">manual</a> ';
                    $total_button = $total_button + 1;
                }
                
                if (session()->get('akses.print_manual')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_print_manual', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-default">manual</a> ';
                    $total_button = $total_button + 1;
                }

                
                if (session()->get('akses.admin')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_admin', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-warning">admin</a> ';
                    $total_button = $total_button + 1;
                }
                if (session()->get('akses.payment')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_payment', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-info">payment</a> ';
                    $total_button = $total_button + 1;
                }

                if (session()->get('akses.prepare_warehouse')) {
                    $gabung = $gabung . '<a target="_blank" href="' . route($this->getModule() . '_prepare_warehouse', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-primary">Prepare</a> ';
                    $total_button = $total_button + 1;
                }

                if (session()->get('akses.send')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_send', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-success">Send</a> ';
                    $total_button = $total_button + 1;
                }

                if (session()->get('akses.deliver')) {
                    $gabung = $gabung . '<a target="_blank" href="' . route($this->getModule() . '_deliver', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-warning">Delivery</a> ';
                    $total_button = $total_button + 1;
                }
                if (session()->get('akses.receive')) {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_receive', [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-danger">receive</a> ';
                    $total_button = $total_button + 1;
                }

                if (!session()->get('akses.receive')) {
                    $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                    $total_button = $total_button + 1;
                }
                session()->put('button', $total_button);
                return $gabung;
            });

            $awal  = request()->get('awal');
            $akhir = request()->get('akhir');

            if (!empty($awal) && !empty($awal)) {
                $datatable->where('spk_date', '>=', $awal);
                $datatable->where('spk_date', '<=', $akhir);
            }

            if (session()->get('akses.update')) {

                $datatable->orWhere('spk_status', '=', 'PRODUCTION');
                $datatable->orWhere('spk_status', '=', 'RECEIVED');
                $datatable->orWhere('spk_status', '=', 'COMPLETE');
            }

            if (session()->get('akses.receive')) {

                $datatable->orWhere('spk_status', '=', 'APPROVED');
                $datatable->orWhere('spk_status', '=', 'PREPARED');
                $datatable->orWhere('spk_status', '=', 'PRODUCTION');
                $datatable->orWhere('spk_status', '=', 'DELIVERED');
                $datatable->orWhere('spk_status', '=', 'COMPLETE');
                $datatable->orWhere('spk_status', '=', 'RECEIVED');
            }

            if (session()->get('akses.payment')) {

                $datatable->Where('spk_status', '=', 'RECEIVED');
                $datatable->orWhere('spk_status', '=', 'COMPLETE');
            }

            if (request()->has('search')) {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }

        if (request()->has('code')) {
            $id         = request()->get('code');
            $getData    = $this->model->baca($id);
            $payment    = new \App\Payment();
            $pembayaran = $payment->getByReference($id);
            return view('page.' . $this->template . '.show')->with([
                'fields'   => $this->datatable,
                'data'     => $getData->first(),
                'detail'   => $this->model->getDetail($id),
                'key'      => $this->key,
                'payment'  => $pembayaran->get(),
                'template' => $this->template]);
        }

        return view('page.' . $this->template . '.table')->with(['fields' => $this->datatable,
            'template'                                                        => $this->template]);
    }
    
    public function manual()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);
            $product = new \App\Product();
            return view('page.' . $this->template . '.manual')->with([
                'template' => $this->template,
                'data'     => $getData->first(),
                'detail'   => $this->model->getDetail($id),
                'manual'   => $this->model->getManual($id),
                'key'      => $this->key,
                'product'  => $product->baca()->get(),
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id      = collect(request()->query())->flip()->first();
                $request = request()->all();
                $request['form'] = 'manual';
                $this->model->ubah($id, $request);


                $produk_standard = request()->get('product');
                $qty_standard    = request()->get('qty');
                $price_standard  = request()->get('price');
                
                if(!empty($produk_standard)){

                    for ($i = 0; $i < count(request()->get('product')); $i++) {

                        $parse_qty = empty($qty_standard[$i]) ? 0 : $qty_standard[$i];
                        if(!empty($parse_qty)){
                            $detail = [
                                'detail'        => $id,
                                'product'       => $produk_standard[$i],
                                'qty'           => $parse_qty ,
                                'price'         => $price_standard[$i],
                                'total'         => $price_standard[$i] * $parse_qty,
                                'receive_date'       => $request['date'],
                                'receive_by'  => auth()->user()->name,
                            ];

                            $this->model->manual($detail);
                        }
                        
                    }
                }

                $produk = request()->get('produks2');
                $qty    = request()->get('quantity2');
                $price  = request()->get('price2');

                if(!empty($produk)){

                    for ($i = 0; $i < count(request()->get('produks2')); $i++) {

                        $detail = [
                            'detail'        => $id,
                            'product'       => $produk[$i],
                            'qty'           => $qty[$i],
                            'price'         => $price[$i],
                            'total'         => $price[$i] * $qty[$i],
                        ];

                        $this->model->manual($detail);
                    }
                }

                return redirect()->route($this->getModule() . '_manual', ['code' => $id]);
            }
            return redirect()->back();
        }
    }
    
     public function print_manual()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

              $detail = DB::table('spk_outbound')
                ->leftJoin('products', 'products.product_id', 'spk_outbound.product_out')
                ->where('detail_out', $id)->get();

            $estimasi = $this->model->getManual($id);

            view()->share([
                'data'   => $getData->first(),
                'detail' => $this->model->getManual($id),
                'outbound' => $detail,
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.print_manual');
            return $pdf->stream($id . '.pdf');
        }
    }

    public function update()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);
            $product = new \App\Product();

            return view('page.' . $this->template . '.edit')->with([
                'template' => $this->template,
                'data'     => $getData->first(),
                'detail'   => $this->model->getDetail($id),
                'key'      => $this->key,
                'product'  => $product->baca()->get(),
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id      = collect(request()->query())->flip()->first();
                $request = request()->all();
                // dd($request);
                $request['form'] = 'update';
                $this->model->ubah($id, $request);

                $produk = request()->get('produks2');
                $qty    = request()->get('quantity2');
                $price  = request()->get('price2');
                
                if(!empty($produk)){
                    
                    for ($i = 0; $i < count(request()->get('produks2')); $i++) {
    
                        $detail = [
                            'detail'        => $id,
                            'product'       => $produk[$i],
                            'qty'           => 0,
                            'price'         => $price[$i],
                            'yard'          => 0,
                            'total'         => $price[$i] * $qty[$i],
                            'total_yard'    => 0,
                            'qty_prepare'   => $qty[$i],
                            'price_prepare' => $price[$i],
                            'total_prepare' => $qty[$i] * $price[$i],
                        ];
    
                        $this->model->detail($detail);
                    }
                }

                if ($request['spk_status'] == 'DELIVERED') {

                    $header = $this->model->baca($id)->first();
                    $detail = $this->model->getDetail($id);
                    $email  = [
                        'code'   => $id,
                        'header' => $header,
                        'detail' => $detail,
                    ];

                    try {

                        Mail::send('emails.po_spk', $email, function ($message) {
                            $message->to(config('mail.from.address'), config('mail.from.name'));
                            $message->to(config('website.gudang'), 'Warehouse');
                            $message->subject('Notification Delivery From Penjahit');
                            $message->from(config('mail.from.address'), config('mail.from.name'));
                        });

                    } catch (Exception $e) {

                    }

                }

                return redirect()->route($this->getModule() . '_read', ['code' => $id]);
            }
            return redirect()->back();
        }
    }

    public function admin()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            return view('page.' . $this->template . '.admin')->with([
                'template' => $this->template,
                'data'     => $this->validasi($getData),
                'detail'   => $this->model->getDetail($id),
                'key'      => $this->key,
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                // dd(request()->all());
                $id              = collect(request()->query())->flip()->first();
                $request         = request()->all();
                $file            = request()->file('files');
                $request['form'] = 'admin';
                $this->model->ubah($id, $request, $file);

                $getData = $this->model->baca($id);
                $header  = $getData->first();
                $detail  = $this->model->getDetail($id);
                $email   = [
                    'code'   => $id,
                    'header' => $header,
                    'detail' => $detail,
                ];

                Mail::send('emails.spk_approve', $email, function ($message) use ($header) {
                    $message->to(config('mail.from.address'), config('mail.from.name'));
                    $message->to($header->email, $header->production_name);
                    $message->subject('Notification SPK From ' . config('app.name'));
                    $message->from(config('mail.from.address'), config('mail.from.name'));
                });
            }
            return redirect()->back();
        }
    }

    public function approve()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.approve');
            return $pdf->stream($id . '.pdf');
        }

        return redirect()->route($this->getModule() . '_read');
    }

    public function prepare_warehouse()
    {

        // $query = DB::table('spk')->where('spk_status', 'PREPARED')->whereRaw('spk_prepare < NOW() - INTERVAL 6 HOUR');
        // $get = $query->count();
        // dd($query->get());
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id)->first();

            if ($getData->spk_status == 'APPROVED') {
                DB::table('spk')
                ->where('spk_id', $id)->whereNull('spk_prepare')
                ->update([
                    'spk_prepare' => date('Y-m-d H:i:s'),
                    'spk_status' => 'PREPARED'
                ]);
            }

            if (DB::table('spk_outbound')->where('detail_out', $id)->count() <= 0) {

                $outbound = DB::table('spk_detail')
                    ->select(['detail', 'product_from'])
                    ->addSelect(DB::raw('sum(qty) as qty_out'))
                    ->addSelect(DB::raw('sum(total_yard) as yard_out'))
                    ->leftJoin('converters', 'converters.product_to', 'spk_detail.product')
                    ->where('detail', $id)
                    ->groupBy('product_from')->get();
                // dd($outbound);

                $data_out = [];
                $tambah   = 0;
                foreach ($outbound as $out) {

                    $data_out[$tambah]['detail_out']  = $out->detail;
                    $data_out[$tambah]['product_out'] = $out->product_from;
                    $data_out[$tambah]['qty_out']     = $out->qty_out;
                    $data_out[$tambah]['yard_out']    = $out->yard_out;
                    DB::table('spk_outbound')->insert($data_out[$tambah]);
                    $tambah++;
                }
            }

            $detail = DB::table('spk_outbound')
                ->leftJoin('products', 'products.product_id', 'spk_outbound.product_out')
                ->where('detail_out', $id)->get();
            // dd($detail->get());

            // dd($detail->get());
            view()->share([
                'data'   => $getData,
                'detail' => $detail,
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.print_prepare_warehouse');
            return $pdf->stream($id . '.pdf');
        }
    }

    public function print_production()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $getData->first(),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.print_delivery_production');
            return $pdf->stream($id . '.pdf');
        }
    }

    public function deliver()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

              $detail = DB::table('spk_outbound')
                ->leftJoin('products', 'products.product_id', 'spk_outbound.product_out')
                ->where('detail_out', $id)->get();

            view()->share([
                'data'   => $getData->first(),
                'detail' => $this->model->getDetail($id),
                'outbound' => $detail,
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.deliver');
            return $pdf->stream($id . '.pdf');
        }
    }

    public function invoice()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $getData->first(),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.invoice');
            return $pdf->stream($id . '.pdf');
        }
    }

    public function receive()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            return view('page.' . $this->template . '.receive')->with([
                'template' => $this->template,
                'data'     => $this->validasi($getData),
                'detail'   => $this->model->getDetail($id),
                'key'      => $this->key,
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id              = collect(request()->query())->flip()->first();
                $request         = request()->all();
                $file            = request()->file('files');
                $request['form'] = 'receive';
                $this->model->ubah($id, $request, $file);
            }
            return redirect()->back();
        }
    }

    public function send()
    {
        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            return view('page.' . $this->template . '.send')->with([
                'template' => $this->template,
                'data'     => $this->validasi($getData),
                'original' => $this->model->getDetail($id),
                'detail'   => $this->model->getReceive($id),
                'key'      => $this->key,
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id              = collect(request()->query())->flip()->first();
                $request         = request()->all();
                $file            = request()->file('files');
                $request['form'] = 'send';
                $this->model->ubah($id, $request, $file);
            }
            return redirect()->back();
        }
    }

    public function berita_acara()
    {

        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->baca($id);

            view()->share([
                'data'   => $this->validasi($getData),
                'detail' => $this->model->getDetail($id),
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.berita_acara');
            return $pdf->stream($id . '.pdf');
        }
    }

    public function delete()
    {
        $input = request()->all();
        $this->model->cancel(request()->get('id'));
        return redirect()->back();
    }

}
