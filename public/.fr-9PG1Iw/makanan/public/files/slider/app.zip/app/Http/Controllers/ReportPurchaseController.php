<?php

namespace App\Http\Controllers;

use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class ReportPurchaseController extends Controller
{
    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $read;
    public $payment_model;

    public function __construct()
    {
        $this->model         = new \App\Warehouse();
        $this->table         = $this->model->getTable();
        $this->key           = $this->model->getKeyName();
        $this->field         = $this->model->getFillable();
        $this->datatable     = $this->model->datatable;
        $this->rules         = $this->model->rules;
        $this->searching     = $this->model->searching;
        $this->template      = 'purchase';
        $this->payment_model = [
            'ECT' => 'Lain-lain',
            'PO'  => 'Purchase Order (PO)',
            'SO'  => 'Sales Order (SO)',
            'SPK' => 'Produksi Batik (SPK)',
            'FEE' => 'Fee Sales (FEE)',
            'DO'  => 'Delivery Order (DO)',
        ];
    }

    public function index()
    {
        return '';
    }

    public function penjualan_product()
    {
        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $supplier   = request()->get('supplier');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('purchase_orders');
            $data->join('suppliers', 'suppliers.supplier_id', '=', 'purchase_orders.supplier_id');
            $data->join('purchase_order_detail', 'purchase_order_detail.detail', '=', 'purchase_orders.purchase_id');
            $data->join('products', 'purchase_order_detail.product', '=', 'products.product_id');
            $data->select([
                'purchase_id as Code Purchase',
                'suppliers.supplier_name as Nama Supplier',
                'purchase_date as Tanggal Order',
                'purchase_delivery_date as Tanggal Pengiriman',
                'purchase_status as Status',
                'products.product_id as ID Product',
                'products.product_code as Code Product',
                'products.product_grouping as Group Product',
                'products.product_name as Nama Product',
                'purchase_order_detail.qty_prepare as Qty',
                'purchase_order_detail.price as Price',
                'purchase_order_detail.total as Total',
                'products.product_category as Product Category',
                'products.product_unit as Satuan',
                'products.product_size as Size',
            ]);

            if (!empty($start)) {
                $data->where('purchase_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('purchase_date', '<=', $end);
            }
           
            if (!empty($supplier)) {
                $data->where('purchase_orders.supplier_id', '=', $supplier);
            }
            
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Penjualan ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Penjualan', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;
        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            //$supplier   = new \App\Supplier();
            $user       = new \App\User();
            $site       = new \App\Site();

            $supplier = DB::table('suppliers');
            if(Auth::user()->group_user == 'supplier'){
                $supplier->where('supplier_id','=',Auth::user()->supplier_id);
            }

            return view('report.' . $this->template . '.penjualan')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'supplier'   => $supplier->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

    public function kas()
    {
        $start     = request()->get('date_start');
        $end       = request()->get('date_end');
        $pengirim  = request()->get('pengirim');
        $penerima  = request()->get('penerima');
        $model     = request()->get('model');
        $reference = request()->get('reference');
        $type      = request()->get('type');
        $status    = request()->get('status');

        if (!empty($start) || !empty($end)) {
            $data = DB::table('payments');
            $data->select([

                'payments.payment_voucher as Payment Voucher',
                'payments.account_from as Bank Pengirim',
                'payments.account_to as Bank Penerima',
                'reference as Reference',
                'payment_date as Tanggal Pembayaran',
                'payment_person as Nama',
                'payment_amount as Nilai Pembayaran',
                'payment_type as Type',
                'payment_description as Description',
                'approve_amount as Approve Amount',
                'payment_status as Status',
                'created_by as Created By',
                'payment_model as Model',
            ]);

            if (!empty($start)) {
                $data->where('payment_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('payment_date', '<=', $end);
            }
            if (!empty($pengirim) && $pengirim != 'etc') {
                $data->where('account_from', '=', $pengirim);
            }
            if (!empty($penerima)) {
                $data->where('account_to', '=', $penerima);
            }
            if (!empty($model)) {
                $data->where('payment_model', '=', $model);
            }
            if (!empty($reference)) {
                $data->where('reference', '=', $reference);
            }
            if (!empty($type)) {
                $data->where('payment_type', '=', $type);
            }
            if (!empty($status)) {
                $data->where('payment_status', '=', $status);
            }

            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Kas ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Kas', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;

        } else {
            $payment = new \App\Payment();
            return view('report.' . $this->template . '.kas')->with([
                'template' => $this->template,
                'from'     => $payment->baca()->select('account_from')->distinct()->get(),
                'to'       => $payment->baca()->select('account_to')->distinct()->get(),
                'model'    => collect($this->payment_model),
            ]);
        }
    }

    public function stock()
    {
        $product    = request()->get('product');
        $category   = request()->get('category');
        $size       = request()->get('size');
        $segmentasi = request()->get('segmentasi');

        if (!empty($product) || !empty($category) || !empty($size) || !empty($segmentasi)) {
            $data = DB::table('products');
            $data->leftjoin('stocks', 'products.product_id', '=', 'stocks.product_code');
            // $data->select([
            //     'product_id as Product ID',
            //     'products.product_code as Product Code',
            //     'product_grouping as Group',
            //     'product_name as Product Name',
            //     'product_category as Category',
            //     'product_unit as Unit',
            //     'product_size as Size',
            //     'product_stock as Stock Sales',
            // ]);
            $data->select('products.*');
            $data->addSelect(DB::raw('SUM(qty) as qty'));
            $data->groupBy('product_id');

            if (!empty($product) && $product != 'all') {
                $data->where('product_id', '=', $product);
            }

            if (!empty($category)) {
                $data->where('product_category', '=', $category);
            }
            if (!empty($size)) {
                $data->where('product_size', '=', $size);
            }
            if (!empty($segmentasi)) {
                $data->where('product_segmentasi', '=', $segmentasi);
            }

            $items = array();
            $hold  = 0;
            foreach ($data->get() as $value) {
                if ($value->product_category == 'Batik') {

                    $onhold = DB::table('spk')
                        ->select([DB::raw('(SUM(qty_prepare)) as jumlah')])
                        ->leftJoin('spk_detail', 'spk_detail.detail', '=', 'spk.spk_id')
                        ->where('product', '=', $value->product_id)
                        ->where('spk_status', '=', 'PREPARED')
                        ->orwhere('spk_status', '=', 'DELIVERED')
                        ->where('product', '=', $value->product_id);

                    if (!empty($onhold->first())) {

                        $hold    = 0;
                        $getHold = $onhold->first();
                        $hold    = $getHold->jumlah;

                    }
                } else {

                    $onhold = DB::table('purchase_orders')
                        ->select([DB::raw('(SUM(qty_prepare)) as jumlah')])
                        ->leftJoin('purchase_order_detail', 'purchase_order_detail.detail', '=', 'purchase_orders.purchase_id')
                        ->where('product', '=', $value->product_id)
                        ->where('purchase_status', '=', 'PREPARED')
                        ->orwhere('purchase_status', '=', 'DELIVERED')
                        ->where('product', '=', $value->product_id);

                    if (!empty($onhold->first())) {

                        $hold    = 0;
                        $getHold = $onhold->first();
                        $hold    = $getHold->jumlah;
                    }
                }

                $onbooking = DB::table('orders')
                    ->select([DB::raw('(SUM(qty)) as jumlah')])
                    ->leftJoin('order_detail', 'order_detail.detail', '=', 'orders.order_id')
                    ->where('product', '=', $value->product_id)
                    ->where('order_status', '!=', 'COMPLETE')
                    ->where('order_status', '!=', 'PAID');

                $booking = 0;
                if (!empty($onbooking->first())) {
                    $getBook = $onbooking->first();
                    $booking = $getBook->jumlah;
                }

                $items[] = [
                    'Product ID'   => $value->product_id,
                    'Product Code' => $value->product_code,
                    'Group'        => $value->product_grouping,
                    'Product Name' => $value->product_name,
                    'Category'     => $value->product_category,
                    'Size'         => $value->product_size,
                    'Stock'        => $value->product_stock,
                    'Booking'      => $booking,
                    'Real'         => $value->qty,
                    'Hold'         => $hold,
                ];
            }

            $data  = json_decode(json_encode($items), true);
            $excel = Excel::create('Report Stock ', function ($excel) use ($data) {

                $excel->sheet('Stock', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;

        } else {
            $product    = new \App\Product();
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            return view('report.' . $this->template . '.stock')->with([
                'template'   => $this->template,
                'product'    => $product->baca()->get(),
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
            ]);
        }
    }

    public function tagihan()
    {
        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $supplier      = request()->get('supplier');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {
            
            $data = DB::table('purchase_orders');
            $data->join('suppliers', 'supplier.supplier_id', '=', 'purchase_orders.supplier_id');
            $data->select([
                'purchase_id',
                'suppliers.supplier_name',
                'purchase_date',
                'purchase_delivery_date',
                'purchase_status',
            ]);
            if (!empty($start)) {
                $data->where('purchase_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('purchase_date', '<=', $end);
            }
            
            if (!empty($status)) {
                $data->where('purchase.purchase_status', '=', $status);
            }

            $items = array();
            $hold  = 0;
            foreach ($data->get() as $value) {

                $onvalue = DB::table('purchase_order_detail')
                    ->select([DB::raw('(SUM(qty_prepare * price)) as jumlah')])
                    ->where('detail', '=', $value->purchase_id);

                $jumlah = 0;
                if (!empty($onvalue->first())) {
                    $getValue = $onvalue->first();
                    $jumlah    = $getValue->jumlah;
                }

                $onpembayaran = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->purchase_id);

                $pembayaran = 0;
                if (!empty($onpembayaran->first())) {
                    $getPembayaran = $onpembayaran->first();
                    $pembayaran = $getPembayaran->amount;
                }

                $items[] = [
                    'Purchase ID'   => $value->purchase_id,
                    'Supplier Name' => $value->supplier_name,
                    'Purchase Date' => $value->purchase_date,
                    'Delivery Date' => $value->purchase_delivery_date,
                    'Status'        => $value->purchase_status,
                    'Total Value'   => $jumlah,
                    'Pembayaran'    => $pembayaran,
                    'Sisa Pembayaran'    => $jumlah - $pembayaran,
                    
                ];
            }

            $data  = json_decode(json_encode($items), true);
            $excel = Excel::create('tagihan ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Tagihan', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;
        } else {
            
            $supplier = DB::table('suppliers');
            if(Auth::user()->group_user == 'supplier'){
                $supplier->where('supplier_id','=',Auth::user()->supplier_id);
            }

            return view('report.' . $this->template . '.tagihan')->with([
                'template'   => $this->template,
                'supplier'   => $supplier->get(),
                
            ]);
        }
    }

}
