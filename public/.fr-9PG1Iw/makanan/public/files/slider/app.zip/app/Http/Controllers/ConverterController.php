<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Yajra\Datatables\Facades\Datatables;

class ConverterController extends Controller {

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $read;

    public function __construct()
    {
        $this->model     = new \App\Converter();
        $this->table     = $this->model->getTable();
        $this->key       = $this->model->getKeyName();
        $this->field     = $this->model->getFillable();
        $this->datatable = $this->model->datatable;
        $this->rules     = $this->model->rules;
        $this->searching = $this->model->searching;
        $this->template  = 'converter';
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create()
    {
        if(request()->isMethod('POST'))
        {
            $this->validate(request(), $this->rules);
            $request = request()->all();
            $this->model->simpan($request);
            return redirect()->back();
        }

        $product = new \App\Product();
        return view('page.' .$this->template. '.create')->with([
            'template'=> $this->template,
            'kain' => $product->baca()->where('product_category','=','Kain')->get(),
            'batik' => $product->baca()->where('product_category','=','Batik')->get(),
        ]);
    }

    public function read()
    {
        if(request()->isMethod('POST'))
        {
            $getData   = $this->model->baca();
            $datatable = Datatables::of($this->filter($getData))
            ->addColumn('checkbox', function ($select)
            {
                $id       = $this->key;
                $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="' . $select->$id . '">';
                return $checkbox;
            })->addColumn('action', function ($select)
            {

                $id     = $this->key;
                $gabung = '<div class="aksi text-center">';
                if(session()->get('akses.update'))
                {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_update', [
                      'code' => $select->$id]) . '" class="btn btn-xs btn-primary">edit</a> ';
                }
                $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                  'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                return $gabung;
            });

            if(request()->has('search'))
            {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }
        if(request()->has('code'))
        {
            $id   = request()->get('code');
            $data = $this->model->baca($id);

            return view('page.' .$this->template. '.show')->with([
              'fields'   => $this->datatable,
              'data'     => $this->validasi($data),
              'key'      => $this->key,
              'template' => $this->template
          ]);
        }

        return view('page.' .$this->template. '.table')->with([
          'fields'   => $this->datatable,
          'template' => $this->template
      ]);
    }

    public function update()
    {

        $id = request()->get('code');
        if(!empty($id))
        {
            $product = new \App\Product();
            $getData = $this->model->baca($id);
            return view('page.' .$this->template. '.edit')->with([
              'template' => $this->template,
              'data'     => $this->validasi($getData),
              'template'=> $this->template,
              'kain' => $product->baca()->where('product_category','=','Kain')->get(),
              'batik' => $product->baca()->where('product_category','=','Batik')->get(),
              'key'      => $this->key
          ]);
        }
        else
        {
            if(request()->isMethod('POST'))
            {
                $id          = collect(request()->query())->flip()->first();
                $request = request()->all();

                // DB::table('converters')->where($this->key,'=',$id)->update([

                //     'product_from' => request()->get('product_from'),
                //     'product_to' => request()->get('product_to'),
                //     'product_value' => request()->get('product_value'),
                // ]);
                // dd($request);

                // $batik = request()->get('product_code');
                // if (strpos($batik, '#') !== false) {
                //     $pecah_batik = explode('#', $batik);
                //     $request['product_code'] = $pecah_batik[0];
                // }

                $this->model->ubah($id, $request);
            }
            return redirect()->back();
        }
    }

    public function delete()
    {
        $input = request()->all();
        $this->model->hapus($input);

        return redirect()->back();
    }

}
