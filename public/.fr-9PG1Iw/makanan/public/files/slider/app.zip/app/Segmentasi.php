<?php
namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Segmentasi extends Model{

    protected $table = 'segmentasi';
    protected $primaryKey = 'segmentasi_id';
    protected $fillable = [
            'segmentasi_id',
            'segmentasi_name',
            'segmentasi_description',
            'segmentasi_images',
    ];
    
    public $searching = 'segmentasi_name';
    public $timestamps = false;
    public $incrementing = false;
    public $rules = [
            'segmentasi_id' => 'required|unique:segmentasi|min:1',
            'segmentasi_name' => 'required|min:3',
    ];
    public $datatable = [
            'segmentasi_id' => 'Code',
            'segmentasi_name' => 'Name',
            'segmentasi_images' => 'Images',
    ];

    public function simpan($request, $file = null)
    {
        try
        {
            if(!empty($file)) //handle images
            {

                $name   = $request['unic'] . '.' . $file->extension();
                $simpen = $file->storeAs('slider', $name);

                $request['slider_images'] = $name;
            }

            $this->Create($request);
            session()->put('success', 'Data Has Been Added !');
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function hapus($data)
    {
        if(!empty($data))
        {
            $data = collect($data)->flatten()->all();
            try
            {
                $this->Destroy($data);
                session()->flash('alert-success', 'Data Has Been Deleted !');
            }
            catch(\Exception $e)
            {
                session()->flash('alert-danger', $e->getMessage());
            }
        }
    }

    public function ubah($id, $request, $file = null)
    {
        try
        {
            if(!empty($file)) //handle images
            {
                $name   = $request['unic'] . '.' . $file->extension();
                $simpen = $file->storeAs('segmentasi', $name);

                $request['segmentasi_images'] = $name;
            }

            $s = $this->find($id);
            $s->update($request);

            session()->put('success', 'Data Has Been Updated !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function baca($id = null)
    {
        if(!empty($id))
        {
            return DB::table($this->table)->where($this->primaryKey, $id);
        }
        else
        {
            return $this->select();
        }
    }

}
