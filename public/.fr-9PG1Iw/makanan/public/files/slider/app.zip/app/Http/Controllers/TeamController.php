<?php
namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Yajra\Datatables\Facades\Datatables;

class TeamController extends Controller{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;

    public function __construct()
    {
        $this->model = new \App\User();
        $this->table = $this->model->getTable();
        $this->key = $this->model->getKeyName();
        $this->field = $this->model->getFillable();
        $this->datatable = $this->model->datatable;
        $this->rules = $this->model->rules;
        $this->searching = $this->model->searching;
        $this->template = 'user';
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create()
    {
        if(request()->isMethod('POST'))
        {
            $code = $this->Code('users', 'user_id', 'U'.date('Y').date('m'), 10);
            $this->validate(request(), $this->rules);
            $this->model->simpan(request()->all(),$code);
            return redirect()->route('team_update', ['code' => $code]);
        }
        else
        {
            $site = new \App\Site();
            $production = new \App\Production();
            $supplier = new \App\Supplier();
            $group = new \App\GroupUser();
            return view('page.' .$this->template. '.create')->with([
                            'template' => $this->template,
                            'site' => $site->getFilterSite()->get(),
                            'production' => $production->baca()->get(),
                            'supplier' => $supplier->baca()->get(),
                            'group' => $group->baca()->get(),
                            'js' => 'user.js'
            ]);
        }

    }

    public function read()
    {
        
        if(request()->isMethod('POST'))
        {
            $datatable = Datatables::of($this->filter($this->model->baca()))
                            ->addColumn('checkbox', function ($select)
                            {
                                $id = $this->key;
                                $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="'.$select->$id.'">';
                                return $checkbox;
                            })
                            ->addColumn('action', function ($select)
            {
                $id     = $this->key;
                $gabung = '<div class="aksi text-center">';
                if(session()->get('akses.update'))
                {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_update', [
                              'code' => $select->$id]) . '" class="btn btn-xs btn-primary">edit</a> ';
                }
                $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                          'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                return $gabung;
            });

            if(request()->has('search'))
            {
                $code = request()->get('code');
                $search = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }

        if(request()->has('code'))
        {
            $id = request()->get('code');
            return view('page.' .$this->template. '.show')->with([
                            'fields' => $this->datatable,
                            'data' => $this->validasi($this->model->baca($id)),
                            'detail' => $this->model->getDetail($id)->get(),
                            'key' => $this->key,
                            'template' => $this->template
            ]);
        }

        return view('page.' .$this->template. '.table')->with(['fields' => $this->datatable,
                        'template' => $this->template]);
    }

    public function update()
    {
        $id = request()->get('code');
        if(!empty($id))
        {
            $single = $this->model->baca($id)->get()->first();
            if(!empty($single)){
                $detail = $this->model->getDetail($single->email)->get();
            }
            else{
                $detail = null;
            }
            $production = new \App\Production();
            $supplier = new \App\Supplier();
            return view('page.' .$this->template. '.edit')->with([
                            'template' => $this->template,
                            'data' => $single,
                            'production' => $production->baca()->get(),
                            'supplier' => $supplier->baca()->get(),
                            'detail' => $detail,
                            'user' => $this->model->baca()->get(),
                            'key' => $this->key
            ]);
        }
        else
        {
            if(request()->isMethod('POST'))
            {
                $id = collect(request()->query())->flip()->first();
                $update = request()->all();
                $password = request()->get('pwd');
                if(!empty($password))
                {
                    $this->model->update_password($id, $password);
                }
                $this->model->ubah($id, request()->all());

                if(request()->exists('team'))
                {
                    $team = request()->get('team');
                    $this->model->filter(request()->get('email'), $team);
                }

                if(request()->get('supplier_id') != '')
                {
                    $this->model->filterSingle(request()->get('supplier_id'), request()->get('supplier_id'));
                }

                if(request()->get('production_id') != '')
                {
                    $this->model->filterSingle(request()->get('production_id'), request()->get('production_id'));
                }
            }
            return redirect()->back();
        }
    }

    public function delete()
    {
        $data = request()->all();
        foreach($data['id'] as $d)
        {
            $this->model->active($d, 0);
        }

        return redirect()->back();
    }

}
