<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Yajra\Datatables\Facades\Datatables;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Config;
use App\Http\Middleware\AccessMenu;
use RajaOngkir;

class ConfigurationController extends Controller {

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;

    public function __construct() {
        $this->middleware('auth');
    }

    public function website() {

        // $directory = File::directories();
        // dd($directory);

        if (request()->isMethod('POST')) {

            // dd(request()->all());

            foreach (request()->get('app') as $key => $value) {
                Config::write('app.' . $key, $value);
            }

            foreach (request()->get('cache') as $key => $value) {
                Config::write('cache.' . $key, $value);
            }

            foreach (request()->get('local') as $key => $value) {
                Config::write('remote.connections.local.' . $key, $value);
            }

            foreach (request()->get('server') as $key => $value) {
                Config::write('remote.connections.server.' . $key, $value);
            }

            foreach (request()->get('database') as $key => $value) {
                Config::write('database.connections.' . config('database.default') . '.' . $key, $value);
            }

            if (request()->exists('favicon')) {
                $file = request()->file('favicon');
                $name = 'favicon.' . $file->extension();
                $simpen = $file->storeAs('logo', $name);
                Config::write('website.favicon', $name);
            }

            if (request()->exists('logo')) {
                $file = request()->file('logo');
                $name = 'logo.' . $file->extension();
                $simpen = $file->storeAs('logo', $name);
                Config::write('website.logo', $name);
            }

            Config::write('image.driver', request()->get('image'));
            Config::write('debugbar.enabled', request()->get('debugbar'));
            Config::write('website.description', request()->get('description'));
            Config::write('website.backend', request()->get('backend'));
            Config::write('website.frontend', request()->get('frontend'));
            Config::write('website.owner', request()->get('owner'));
            Config::write('website.address', request()->get('address'));
            Config::write('website.phone', request()->get('phone'));
            
            Config::write('website.province', request()->get('province'));
            Config::write('website.city', request()->get('city'));
            Config::write('website.gudang', request()->get('gudang'));
            
            Config::write('website.carabelanja', htmlentities(request()->get('carabelanja')));
            Config::write('website.about', htmlentities(request()->get('about')));
            Config::write('website.marketing', htmlentities(request()->get('marketing')));

            Config::write('mail.from.address', request()->get('mail_address'));
            Config::write('mail.from.name', request()->get('mail_name'));

            session()->put('success', 'Configuration Success !');
            return redirect()->back();
        }
        $akses = New AccessMenu();
        $akses->setData($akses->getData());
        $group = new \App\GroupUser();
        $database = config('database.connections.' . config('database.default'));

        $city = RajaOngkir::Kota()->find(config('website.city'));
        return view('page.configuration.website')->with([
            'group' => $group->baca()->get(),
            'province'   => RajaOngkir::Provinsi()->all(),
            'city' => $city, 
            'db' => $database
        ]);
    }

}
