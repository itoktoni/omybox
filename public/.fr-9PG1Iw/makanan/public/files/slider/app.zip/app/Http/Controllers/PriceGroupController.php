<?php
namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Yajra\Datatables\Facades\Datatables;

class PriceGroupController extends Controller{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $stock;

    public function __construct()
    {
        $this->model = new \App\PriceGroup();
        $this->table = $this->model->getTable();
        $this->key = $this->model->getKeyName();
        $this->field = $this->model->getFillable();
        $this->template = 'price_group';
        $this->stock = $this->model->stock;
    }

    public function top()
    {
        $field = [
                'site_id' => 'Site',
                'term_of_payment_id' => 'TOP',
                'price' => 'Price',
        ];

        if(request()->isMethod('POST'))
        {
            if(empty(request()->get('produk')))
            {
                $datatable = Datatables::of(collect()->push($field));
            }
            else
            {
                $getData = $this->model->getByTop();
            }

            if(request()->has('produk') && request()->has('segmentasi'))
            {
                $datatable = Datatables::of($this->filter($getData));

                $produk = request()->get('produk');
                $segmentasi = request()->get('segmentasi');

                $datatable->addColumn('price', function ($select) use ($produk)
                {
                    $p = number_format($select->price);
                    return $p;
                });

                $datatable->where('product_id', '=', $produk);
                $datatable->where('segmentasi_id', '=', $segmentasi);
            }
            else
            {
                $datatable = Datatables::of(collect()->push($field));
            }

            return $datatable->make(true);
        }
        else
        {
            $produk = new \App\Product();
            $segmen = new \App\Segmentasi();

            return view('page.'.'.top')->with([
                            'fields' => $field,
                            'template' => $this->template,
                            'produk' => $produk->baca()->get(),
                            'segment' => $segmen->baca()->get(),
            ]);
        }
    }

    public function customer()
    {
        $field = [
                'site_id' => 'Site',
                'segmentasi_id' => 'Segmentasi',
                'term_of_payment_id' => 'TOP',
                'price' => 'Price',
        ];

        if(request()->isMethod('POST'))
        {
            if(empty(request()->get('produk')))
            {
                $datatable = Datatables::of(collect()->push($field));
            }
            else
            {
                $getData = $this->model->getByTop();

                if(request()->has('produk') && request()->has('segmentasi') && request()->has('top') && request()->has('site'))
                {
                    $datatable = Datatables::of($getData);
                    $produk = request()->get('produk');
                    $segmentasi = request()->get('segmentasi');
                    $top = request()->get('top');
                    $site = request()->get('site');

                    $datatable->setRowClass(function ($data) use ($top, $site)
                    {
                        return $data->term_of_payment_id == $top && $data->site_id == $site ? 'well primary' : '';
                    });

                    $datatable->where('product_id', '=', $produk);
                    $datatable->where('segmentasi_id', '=', $segmentasi);
                    $datatable->where('site_id', '=', $site);

                    $datatable->addColumn('price', function ($select) use ($produk)
                    {
                        $p = number_format($select->price);
                        return $p;
                    });
                }
                else
                {
                    $datatable = Datatables::of(collect()->push($field));
                }
            }
            return $datatable->make(true);
        }
        else
        {
            return view('page.'.'.customer')->with([
                            'fields' => $field,
                            'template' => $this->template,
            ]);
        }
    }

    public function product()
    {
        $field = [
                'site_id' => 'Site',
                'product_id' => 'Product',
                'product_name' => 'Display Product Name',
                'term_of_payment_id' => 'TOP',
                'stock' => 'Stock',
                'price' => 'Price',
        ];

       
        if(request()->isMethod('POST'))
        {
            if(empty(request()->get('produk')))
            {
                $datatable = Datatables::of(collect()->push($field));
            }
            else
            {
                $getData = $this->model->getByProduct();
                $data = $this->validasi($getData);

                if(request()->has('produk') && request()->has('segmentasi'))
                {
                    $produk = request()->get('produk');
                    $segmentasi = request()->get('segmentasi');

                    $datatable = Datatables::of($getData);
                    $datatable->where('term_of_payment_id', '=', 'D0');
                    $datatable->where('product_name', 'like', "%$produk%");
                    $datatable->where('segmentasi_id', '=', $segmentasi);

                    $datatable->addColumn('price', function ($select) use ($produk)
                    {
                        $p = number_format($select->price);
                        return $p;
                    });
                }
                else
                {
                    $datatable = Datatables::of(collect()->push($field));
                }
            }
            return $datatable->make(true);
        }
        $segmen = new \App\Segmentasi;

        return view('page.'.'.product')->with([
                        'fields' => $field,
                        'template' => $this->template,
                        'segment' => $segmen->baca()->get(),
        ]);
    }

}
