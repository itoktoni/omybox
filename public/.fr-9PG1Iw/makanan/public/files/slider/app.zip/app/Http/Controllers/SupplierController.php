<?php

namespace App\Http\Controllers;

use Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cache;
use Yajra\Datatables\Facades\Datatables;

class SupplierController extends Controller {

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;

    public function __construct()
    {
        $this->model     = new \App\Supplier();
        $this->table     = $this->model->getTable();
        $this->key       = $this->model->getKeyName();
        $this->field     = $this->model->getFillable();
        $this->datatable = $this->model->datatable;
        $this->rules     = $this->model->rules;
        $this->searching = $this->model->searching;
        $this->template  = 'supplier';
    }

    public function index()
    {
        return redirect()->route($this->getModule() . 'read');
    }

    public function create()
    {
        if(request()->isMethod('POST'))
        {
            $this->validate(request(), $this->rules);
            $request         = request()->all();
            $file            = request()->file('files');
            $request['unic'] = $this->unic(5);
            $request[$this->key] = $code = $this->Code($this->table, $this->key, 'S'.date('Y').date('m'), 10);
            $this->model->simpan($request, $file);
        }

        $user = $this->model->getUser();
        return view('page.' .$this->template. '.create')->with([
                  'template' => $this->template,
                  'user'     => $user,
        ]);
    }

    public function read()
    {
        if(request()->isMethod('POST'))
        {
            $getData   = $this->model->baca();
            $datatable = Datatables::of($this->filter($getData))
                            ->addColumn('checkbox', function ($select)
                            {
                                $id       = $this->key;
                                $checkbox = '<input type="checkbox" name="id[]" class="chkSelect" style="margin-left:10px;" id="checkbox1" value="' . $select->$id . '">';
                                return $checkbox;
                            })->addColumn('action', function ($select)
            {
                $id     = $this->key;
                $gabung = '<div class="aksi text-center">';
                if(session()->get('akses.update'))
                {
                    $gabung = $gabung . '<a href="' . route($this->getModule() . '_update', [
                              'code' => $select->$id]) . '" class="btn btn-xs btn-primary">edit</a> ';
                }
                $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                          'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                return $gabung;
            });

            if(request()->has('search'))
            {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }
        if(request()->has('code'))
        {
            $id   = request()->get('code');
            $data = $this->model->baca($id);

            return view('page.' .$this->template. '.show')->with([
                      'fields'   => $this->datatable,
                      'data'     => $this->validasi($data),
                      'key'      => $this->key,
                      'template' => $this->template
            ]);
        }

        return view('page.' .$this->template. '.table')->with([
                  'fields'   => $this->datatable,
                  'template' => $this->template
        ]);
    }

    public function update()
    {
        $id = request()->get('code');
        if(!empty($id))
        {
            $getData = $this->model->baca($id);
            $user    = $this->model->getUser();
            return view('page.' .$this->template. '.edit')->with([
                      'template' => $this->template,
                      'data'     => $this->validasi($getData),
                      'user'     => $user,
                      'key'      => $this->key
            ]);
        }
        else
        {
            if(request()->isMethod('POST'))
            {
                $id                  = collect(request()->query())->flip()->first();
                $requestData         = request()->all();
                $requestData['unic'] = $this->unic(5);
                $file                = request()->file('files');
                $this->model->ubah($id, $requestData, $file);
            }
            return redirect()->route($this->getModule() . '_read');
        }
    }

    public function delete()
    {
        $input = request()->all();
        $this->model->hapus($input);

        return redirect()->back();
    }

}
