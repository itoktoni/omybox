<?php

namespace App\Http\Controllers;

use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $read;
    public $payment_model;

    public function __construct()
    {
        $this->model         = new \App\Warehouse();
        $this->table         = $this->model->getTable();
        $this->key           = $this->model->getKeyName();
        $this->field         = $this->model->getFillable();
        $this->datatable     = $this->model->datatable;
        $this->rules         = $this->model->rules;
        $this->searching     = $this->model->searching;
        $this->template      = 'owner';
        $this->payment_model = [
            'ECT' => 'Lain-lain',
            'PO'  => 'Purchase Order (PO)',
            'SO'  => 'Sales Order (SO)',
            'SPK' => 'Produksi Batik (SPK)',
            'FEE' => 'Fee Sales (FEE)',
            'DO'  => 'Delivery Order (DO)',
        ];
    }

    public function index()
    {
        return '';
    }

    public function penjualan_product()
    {

        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $customer   = request()->get('customer');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('orders');
            $data->join('customers', 'customers.customer_id', '=', 'orders.customer_id');
            $data->join('users', 'users.email', '=', 'orders.email');
            $data->join('sites', 'sites.site_id', '=', 'customers.site_id');
            $data->join('order_detail', 'order_detail.detail', '=', 'orders.order_id');
            $data->join('products', 'order_detail.product', '=', 'products.product_id');
            $data->select([

                'order_id as Code Order',
                'customers.customer_name as Nama Customer',
                'sites.site_name as Pembagian Wilayah',
                'users.name as Nama Sales',
                'order_date as Tanggal Order',
                'order_delivery_date as Tanggal Pengiriman',
                'order_status as Status',
                'products.product_id as ID Product',
                'products.product_code as Code Product',
                'products.product_material as Material',
                'products.product_grouping as Group Product',
                'products.product_name as Nama Product',
                DB::Raw('IFNULL( `order_detail`.qty_prepare , 0 ) as Qty'),
                DB::Raw('IFNULL( `order_detail`.price_prepare , 0 ) as Price'),
                DB::Raw('IFNULL( `order_detail`.total_prepare , 0 ) as Total'),
                'products.product_category as Product Category',
                'products.product_unit as Satuan',
                'products.product_size as Size',
                'products.product_weight as Berat',
                'products.product_commision as Komisi',
                'orders.airbill as No Resi',
                'orders.courier as Kurir',
                'orders.courier_service as Jasa Pengiriman',
                'orders.qty_total as Total gram',
                'orders.estimasi_cost as Estimasi Pengiriman ',
                'orders.delivery_cost as Actual Pengiriman',
                'products.product_commision as Komisi',
            ]);
            

            if (!empty($start)) {
                $data->where('order_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('order_date', '<=', $end);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }
            if (!empty($size)) {
                $data->where('products.product_size', '=', $size);
            }
            if (!empty($customer)) {
                $data->where('orders.customer_id', '=', $customer);
            }
            if (!empty($category)) {
                $data->where('products.product_category', '=', $category);
            }
            if (!empty($user)) {
                $data->where('orders.email', '=', $user);
            }
            if (!empty($site)) {
                $data->where('customers.site_id', '=', $site);
            }
            if (!empty($kurir)) {
                $data->where('orders.courier', '=', $kurir);
            }
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Penjualan ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Penjualan', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;
        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.penjualan')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }
    
    public function report_kain_keluar()
    {

        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $status     = request()->get('status');
        $segmentasi     = request()->get('segmentasi');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('spk');
            $data->join('spk_outbound', 'spk.spk_id', '=', 'spk_outbound.detail_out');
            $data->join('products', 'spk_outbound.product_out', '=', 'products.product_id');
            $data->join('productions', 'spk.production_id', '=', 'productions.production_id');
            $data->select([

                'spk_id as Code Order',
                'productions.production_name as Nama Penjahit',
                'spk_date as Tanggal Spk',
                'spk_delivery_date as Tanggal Pengiriman',
                'spk_status as Status',
                'products.product_id as ID Product',
                'products.product_code as Code Product',
                'products.product_material as Material',
                'products.product_grouping as Group Product',
                'products.product_name as Nama Product',
                'spk_outbound.qty_out as Qty',
                'spk_outbound.yard_out as Yard',
                'spk_outbound.yard_prepare_out as Prepare',
                'products.product_category as Product Category',
                'products.product_unit as Satuan',
                'products.product_size as Size',
                'products.product_weight as Berat',
            ]);

            if (!empty($start)) {
                $data->where('spk_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('spk_date', '<=', $end);
            }
            
            if (!empty($status)) {
                $data->where('spk.spk_status', '=', $status);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }

            dd($data->limit(5)->get());
            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Pengeluaran Barang ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Pengeluaran', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;
        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.kain_keluar')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

    public function report_batik_keluar()
    {

        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $status     = request()->get('status');
        $segmentasi     = request()->get('segmentasi');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('data_spk_manual');
            $data->select([
                'spk_id as Code Order',
                'production_name as Nama Penjahit',
                'spk_date as Tanggal Spk',
                'spk_delivery_date as Tanggal Pengiriman',
                'spk_status as Status',
                'product_id as ID Product',
                'product_code as Code Product',
                'product_material as Material',
                'product_grouping as Group Product',
                'product_name as Nama Product',
                 DB::raw('SUM(qty) as Qty'),
                 DB::raw('SUM(prepare) as Prepare'),
                 DB::raw('SUM(manual) as Manual'),
                'price as Price',
                'product_category as Product Category',
                'product_unit as Satuan',
                'product_size as Size',
                'product_weight as Berat',
            ])->groupBy('spk_id', 'product_id');    

            if (!empty($start)) {
                $data->where('spk_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('spk_date', '<=', $end);
            }
            
            if (!empty($status)) {
                $data->where('spk_status', '=', $status);
            }
            if (!empty($segmentasi)) {
                $data->where('product_segmentasi', '=', $segmentasi);
            }
            

            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Pengeluaran Barang ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Pengeluaran', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;
        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.batik_keluar')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }
    
    public function report_barang_keluar()
    {

        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $status     = request()->get('status');
        $segmentasi     = request()->get('segmentasi');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('spk');
            $data->join('spk_outbound', 'spk.spk_id', '=', 'spk_outbound.detail_out');
            $data->join('products', 'spk_outbound.product_out', '=', 'products.product_id');
            $data->join('productions', 'spk.production_id', '=', 'productions.production_id');
            $data->select([

                'spk_id as Code Order',
                'productions.production_name as Nama Penjahit',
                'spk_date as Tanggal Spk',
                'spk_delivery_date as Tanggal Pengiriman',
                'spk_status as Status',
                'products.product_id as ID Product',
                'products.product_code as Code Product',
                'products.product_material as Material',
                'products.product_grouping as Group Product',
                'products.product_name as Nama Product',
                'spk_outbound.qty_out as Qty',
                'spk_outbound.yard_out as Yard',
                'spk_outbound.yard_prepare_out as Prepare',
                'products.product_category as Product Category',
                'products.product_unit as Satuan',
                'products.product_size as Size',
                'products.product_weight as Berat',
            ]);

            if (!empty($start)) {
                $data->where('spk_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('spk_date', '<=', $end);
            }
            
            if (!empty($status)) {
                $data->where('spk.spk_status', '=', $status);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }
            

            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Pengeluaran Barang ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Pengeluaran', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;
        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.barang_keluar')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

    public function kas()
    {
        $start     = request()->get('date_start');
        $end       = request()->get('date_end');
        $pengirim  = request()->get('pengirim');
        $penerima  = request()->get('penerima');
        $model     = request()->get('model');
        $reference = request()->get('reference');
        $type      = request()->get('type');
        $status    = request()->get('status');

        if (!empty($start) || !empty($end)) {
            $data = DB::table('payments');
            $data->select([

                'payments.payment_voucher as Payment Voucher',
                'payments.account_from as Bank Pengirim',
                'payments.account_to as Bank Penerima',
                'reference as Reference',
                'payment_date as Tanggal Pembayaran',
                'payment_person as Nama',
                'payment_amount as Nilai Pembayaran',
                'payment_type as Type',
                'payment_description as Description',
                'approve_amount as Approve Amount',
                'payment_status as Status',
                'created_by as Created By',
                'payment_model as Model',
            ]);

            if (!empty($start)) {
                $data->where('payment_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('payment_date', '<=', $end);
            }
            if (!empty($pengirim) && $pengirim != 'etc') {
                $data->where('account_from', '=', $pengirim);
            }
            if (!empty($penerima)) {
                $data->where('account_to', '=', $penerima);
            }
            if (!empty($model)) {
                $data->where('payment_model', '=', $model);
            }
            if (!empty($reference)) {
                $data->where('reference', '=', $reference);
            }
            if (!empty($type)) {
                $data->where('payment_type', '=', $type);
            }
            if (!empty($status)) {
                $data->where('payment_status', '=', $status);
            }

            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Kas ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Kas', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;

        } else {
            $payment = new \App\Payment();
            return view('report.' . $this->template . '.kas')->with([
                'template' => $this->template,
                'from'     => $payment->baca()->select('account_from')->distinct()->get(),
                'to'       => $payment->baca()->select('account_to')->distinct()->get(),
                'model'    => collect($this->payment_model),
            ]);
        }
    }

    public function stock()
    {
        $product    = request()->get('product');
        $category   = request()->get('category');
        $size       = request()->get('size');
        $segmentasi = request()->get('segmentasi');

        if (!empty($product) || !empty($category) || !empty($size) || !empty($segmentasi)) {
            $data = DB::table('products');
            $data->leftjoin('stocks', 'products.product_id', '=', 'stocks.product_code');
            // $data->select([
            //     'product_id as Product ID',
            //     'products.product_code as Product Code',
            //     'product_grouping as Group',
            //     'product_name as Product Name',
            //     'product_category as Category',
            //     'product_unit as Unit',
            //     'product_size as Size',
            //     'product_stock as Stock Sales',
            // ]);
            $data->select('products.*');
            $data->addSelect(DB::raw('SUM(qty) as qty'));
            $data->groupBy('product_id');

            if (!empty($product) && $product != 'all') {
                $data->where('product_id', '=', $product);
            }

            if (!empty($category)) {
                $data->where('product_category', '=', $category);
            }
            if (!empty($size)) {
                $data->where('product_size', '=', $size);
            }
            if (!empty($segmentasi)) {
                $data->where('product_segmentasi', '=', $segmentasi);
            }

            $items = array();
            $hold  = 0;
            $tiba;
            foreach ($data->get() as $value) {
                if ($value->product_category == 'Batik') {

                    $onhold = DB::table('spk')
                        ->select([DB::raw('(SUM(qty_prepare)) as jumlah')])
                        ->leftJoin('spk_detail', 'spk_detail.detail', '=', 'spk.spk_id')
                        ->where('product', '=', $value->product_id)
                        ->where('spk_status', '=', 'PREPARED')
                        ->orwhere('spk_status', '=', 'DELIVERED')
                        ->where('product', '=', $value->product_id);

                    if (!empty($onhold->first())) {

                        $hold    = 0;
                        $getHold = $onhold->first();
                        $hold    = $getHold->jumlah;
                    }
                } else {

                    $onhold = DB::table('purchase_orders')
                        ->select([DB::raw('(SUM(qty_prepare)) as jumlah')])
                        ->leftJoin('purchase_order_detail', 'purchase_order_detail.detail', '=', 'purchase_orders.purchase_id')
                        ->where('product', '=', $value->product_id)
                        ->where('purchase_status', '=', 'PREPARED')
                        ->orwhere('purchase_status', '=', 'DELIVERED')
                        ->where('product', '=', $value->product_id);

                    if (!empty($onhold->first())) {

                        $hold    = 0;
                        $getHold = $onhold->first();
                        $hold    = $getHold->jumlah;
                    }
                }

                $onbooking = DB::table('orders')
                    ->select([DB::raw('(SUM(qty)) as jumlah')])
                    ->leftJoin('order_detail', 'order_detail.detail', '=', 'orders.order_id')
                    ->where('product', '=', $value->product_id)
                    ->where('order_status', '!=', 'CONFIRM')
                    ->where('order_status', '!=', 'APPROVED');

                $booking = 0;
                if (!empty($onbooking->first())) {
                    $getBook = $onbooking->first();
                    $booking = $getBook->jumlah;
                }

                $items[] = [
                    'Product ID'   => $value->product_id,
                    'Product Code' => $value->product_code,
                    'Material'     => $value->product_material,
                    'Group'        => $value->product_grouping,
                    'Product Name' => $value->product_name,
                    'Category'     => $value->product_category,
                    'Size'         => $value->product_size,
                    'Stock'        => $value->product_stock,
                    'Booking'      => $booking,
                    'Real'         => $value->qty,
                    'Hold'         => $hold,
                ];
            }

            $data  = json_decode(json_encode($items), true);
            $excel = Excel::create('Report Stock ', function ($excel) use ($data) {

                $excel->sheet('Stock', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);

                });

            })->export('xls');
            return $excel;

        } else {
            $product    = new \App\Product();
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            return view('report.' . $this->template . '.stock')->with([
                'template'   => $this->template,
                'product'    => $product->baca()->get(),
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
            ]);
        }
    }

    public function komisi_batik()
    {
        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $customer   = request()->get('customer');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('orders');
            $data->join('order_detail','order_detail.detail','=','orders.order_id');
            $data->join('users', 'users.email', '=', 'orders.email');
            $data->join('customers', 'customers.customer_id', '=', 'orders.customer_id');
            $data->join('products','order_detail.product','=','products.product_id');
            $data->where('products.product_category','=','Batik');
            $data->groupBy('order_id');
            $data->select([

                'order_id',
                'customers.customer_name',
                'users.name as sales_name',
                'order_date',
                'order_delivery_date',
                'order_status',
                'orders.airbill',
                'orders.courier',
                'orders.courier_service',
                'orders.estimasi_cost',
                'orders.delivery_cost',
            ]);

            if (!empty($start)) {
                $data->where('order_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('order_date', '<=', $end);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }
            if (!empty($size)) {
                $data->where('products.product_size', '=', $size);
            }
            if (!empty($customer)) {
                $data->where('orders.customer_id', '=', $customer);
            }
            if (!empty($category)) {
                $data->where('products.product_category', '=', $category);
            }
            if (!empty($user)) {
                $data->where('orders.email', '=', $user);
            }
            if (!empty($kurir)) {
                $data->where('orders.courier', '=', $kurir);
            }
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $items  = array();
            $hold   = 0;
            $tambah = 1;
            foreach ($data->get() as $value) {
                $tambah  = $tambah + 1;
                $onvalue = DB::table('order_detail')
                ->join('products','order_detail.product','=','products.product_id')
                    ->select([DB::raw('(SUM(qty_prepare * price)) as jumlah')])
                    ->where('products.product_category','=','Batik')
                    ->where('detail', '=', $value->order_id);

                $jumlah = 0;
                if (!empty($onvalue->first())) {
                    $getValue = $onvalue->first();
                    $jumlah   = $getValue->jumlah;
                }

                $onproduct = DB::table('order_detail')
                ->join('products','order_detail.product','=','products.product_id')
                    ->select([DB::raw('(SUM(qty_prepare)) as total')])
                    ->where('products.product_category','=','Batik')
                    ->where('detail', '=', $value->order_id);

                $product = 0;
                if (!empty($onproduct->first())) {
                    $getProduct = $onproduct->first();
                    $product    = $getProduct->total;
                }

                $onpembayaran_sales = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'IN');

                $pembayaran_sales = 0;
                if (!empty($onpembayaran_sales->first())) {
                    $getPembayaran_sales = $onpembayaran_sales->first();
                    $pembayaran_sales    = $getPembayaran_sales->amount;
                }

                $komisi  = empty(request()->get('komisi')) ? 0 : request()->get('komisi');
                $balance_delivery_cost = $value->estimasi_cost - $value->delivery_cost;
                $balance = $pembayaran_sales - ($jumlah + $value->delivery_cost);
                $kom     = $product * $komisi;

                $onpembayaran_finance = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'OUT')
                    ->where('payment_model', '=', 'SO');

                $pembayaran_finance = 0;
                if (!empty($onpembayaran_finance->first())) {
                    $getPembayaran_finance = $onpembayaran_finance->first();
                    $pembayaran_finance    = $getPembayaran_finance->amount;
                }

                $onpembayaran_finance_fee = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'OUT')
                    ->where('payment_model', '=', 'FEE');

                $pembayaran_finance_fee = 0;
                if (!empty($onpembayaran_finance_fee->first())) {
                    $getPembayaran_finance_fee = $onpembayaran_finance_fee->first();
                    $pembayaran_finance_fee    = $getPembayaran_finance_fee->amount;
                }

                $total_pembayaran_fee = $pembayaran_finance + $pembayaran_finance_fee;

                $voucher = DB::table('payments')
                    ->select('payment_voucher')
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'OUT')->get();
    
                $data_voucher = '';    
                foreach($voucher as $v){
                    $data_voucher = $v->payment_voucher.', '.$data_voucher;
                }    

                $items[] = [
                    'Order ID'      => $value->order_id,
                    'Customer Name' => $value->customer_name,
                    'Sales Name'    => $value->sales_name,
                    'Order Date'    => $value->order_date,
                    'Delivery Date' => $value->order_delivery_date,
                    'Status'        => $value->order_status,
                    'airbill'       => $value->airbill,
                    'Courier'       => $value->courier,
                    'Service'       => $value->courier_service,
                    'Estimasi Cost' => $value->estimasi_cost,
                    'Delivery Cost' => $value->delivery_cost,
                    'Product'       => 'BAJU',
                    'Total Product' => $product,
                    'Total Value'   => $jumlah,
                    'Total Tagihan' => $jumlah + $value->delivery_cost,
                    'Pembayaran'    => $pembayaran_sales,
                    'Balance'       => $balance,
                    'Komisi'        => $kom,
                    'Net Komisi'    => $kom + $balance,
                    'Pembayaran Fee'    => $pembayaran_finance_fee,
                    'Pembayaran Finance'    => $pembayaran_finance,
                    'Total Pembayaran Finance'    => $total_pembayaran_fee,
                    'Balance Status Pembayaran'    => $total_pembayaran_fee - ($kom + $balance),
                    'Voucher'    =>  rtrim($data_voucher," ,"),
                ];
            }

            $data    = json_decode(json_encode($items), true);
            $tanggal = ['awal' => $start, 'akhir' => $end];
            $excel   = Excel::create('Komisi ' . $start . ' sampai ' . $end, function ($excel) use ($data, $tanggal) {

                $excel->sheet('Komisi', function ($sheet) use ($data, $tanggal) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                    $sheet->appendRow(array('Tanggal Export', 'Komisi Batik ' . $tanggal['awal'] . ' sampai ' . $tanggal['akhir']));
                });

            })->export('xls');
            return $excel;
        }
        else{

            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.komisi_batik')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);    
        }
        
    }

    public function komisi_kain()
    {
        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $customer   = request()->get('customer');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('orders');
            $data->join('order_detail','order_detail.detail','=','orders.order_id');
            $data->join('users', 'users.email', '=', 'orders.email');
            $data->join('customers', 'customers.customer_id', '=', 'orders.customer_id');
            $data->join('products','order_detail.product','=','products.product_id');
            $data->where('products.product_category','=','Kain');
            $data->groupBy('order_id');
            $data->select([

                'order_id',
                'customers.customer_name',
                'users.name as sales_name',
                'order_date',
                'order_delivery_date',
                'order_status',
                'orders.airbill',
                'orders.courier',
                'orders.courier_service',
                'orders.estimasi_cost',
                'orders.delivery_cost',
            ]);

            if (!empty($start)) {
                $data->where('order_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('order_date', '<=', $end);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }
            if (!empty($size)) {
                $data->where('products.product_size', '=', $size);
            }
            if (!empty($customer)) {
                $data->where('orders.customer_id', '=', $customer);
            }
            if (!empty($category)) {
                $data->where('products.product_category', '=', $category);
            }
            if (!empty($user)) {
                $data->where('orders.email', '=', $user);
            }
            if (!empty($kurir)) {
                $data->where('orders.courier', '=', $kurir);
            }
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $items  = array();
            $hold   = 0;
            $tambah = 1;
            foreach ($data->get() as $value) {
                $tambah  = $tambah + 1;
                $onvalue = DB::table('order_detail')
                ->join('products','order_detail.product','=','products.product_id')
                    ->select([DB::raw('(SUM(qty_prepare * price)) as jumlah')])
                    ->where('products.product_category','=','Kain')
                    ->where('detail', '=', $value->order_id);

                $jumlah = 0;
                if (!empty($onvalue->first())) {
                    $getValue = $onvalue->first();
                    $jumlah   = $getValue->jumlah;
                }

                $onproduct = DB::table('order_detail')
                ->join('products','order_detail.product','=','products.product_id')
                    ->select([DB::raw('(SUM(qty_prepare)) as total')])
                    ->where('products.product_category','=','Kain')
                    ->where('detail', '=', $value->order_id);

                $product = 0;
                if (!empty($onproduct->first())) {
                    $getProduct = $onproduct->first();
                    $product    = $getProduct->total;
                }

                $onpembayaran_sales = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'IN');

                $pembayaran_sales = 0;
                if (!empty($onpembayaran_sales->first())) {
                    $getPembayaran_sales = $onpembayaran_sales->first();
                    $pembayaran_sales    = $getPembayaran_sales->amount;
                }

                $komisi  = empty(request()->get('komisi')) ? 0 : request()->get('komisi');
                $balance_delivery_cost = $value->estimasi_cost - $value->delivery_cost;
                $balance = $pembayaran_sales - ($jumlah + $value->delivery_cost);
                $kom     = $product * $komisi;

                $onpembayaran_finance = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'OUT')
                    ->where('payment_model', '=', 'SO');

                $pembayaran_finance = 0;
                if (!empty($onpembayaran_finance->first())) {
                    $getPembayaran_finance = $onpembayaran_finance->first();
                    $pembayaran_finance    = $getPembayaran_finance->amount;
                }

                $onpembayaran_finance_fee = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'OUT')
                    ->where('payment_model', '=', 'FEE');

                $pembayaran_finance_fee = 0;
                if (!empty($onpembayaran_finance_fee->first())) {
                    $getPembayaran_finance_fee = $onpembayaran_finance_fee->first();
                    $pembayaran_finance_fee    = $getPembayaran_finance_fee->amount;
                }

                $total_pembayaran_fee = $pembayaran_finance + $pembayaran_finance_fee;

                $voucher = DB::table('payments')
                    ->select('payment_voucher')
                    ->where('reference', '=', $value->order_id)
                    ->where('payment_type', '=', 'OUT')->get();
    
                $data_voucher = '';    
                foreach($voucher as $v){
                    $data_voucher = $v->payment_voucher.', '.$data_voucher;
                }    

                $items[] = [
                    'Order ID'      => $value->order_id,
                    'Customer Name' => $value->customer_name,
                    'Sales Name'    => $value->sales_name,
                    'Order Date'    => $value->order_date,
                    'Delivery Date' => $value->order_delivery_date,
                    'Status'        => $value->order_status,
                    'airbill'       => $value->airbill,
                    'Courier'       => $value->courier,
                    'Service'       => $value->courier_service,
                    'Estimasi Cost' => $value->estimasi_cost,
                    'Delivery Cost' => $value->delivery_cost,
                    'Product' => 'KAIN',
                    'Total Product' => $product,
                    'Total Value'   => $jumlah,
                    'Total Tagihan' => $jumlah + $value->delivery_cost,
                    'Pembayaran'    => $pembayaran_sales,
                    'Balance'       => $balance,
                    'Pembayaran Fee'    => $pembayaran_finance_fee,
                    'Pembayaran Finance'    => $pembayaran_finance,
                    'Total Pembayaran Finance'    => $total_pembayaran_fee,
                    'Balance Status Pembayaran'    => $total_pembayaran_fee - $balance,
                    'Voucher'    =>  rtrim($data_voucher," ,"),
                ];
            }

            $data    = json_decode(json_encode($items), true);
            $tanggal = ['awal' => $start, 'akhir' => $end];
            $excel   = Excel::create('Komisi ' . $start . ' sampai ' . $end, function ($excel) use ($data, $tanggal) {

                $excel->sheet('Komisi', function ($sheet) use ($data, $tanggal) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                    $sheet->appendRow(array('Tanggal Export', 'Komisi Kain ' . $tanggal['awal'] . ' sampai ' . $tanggal['akhir']));
                });

            })->export('xls');
            return $excel;

        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.komisi_kain')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

}
