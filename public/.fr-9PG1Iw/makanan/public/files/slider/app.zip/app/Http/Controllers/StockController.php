<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use PDF;
use Yajra\Datatables\Facades\Datatables;

class StockController extends Controller
{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;

    public function __construct()
    {
        $this->model     = new \App\Stock();
        $this->table     = $this->model->getTable();
        $this->key       = $this->model->getKeyName();
        $this->field     = $this->model->getFillable();
        $this->datatable = $this->model->datatable;
        $this->rules     = $this->model->rules;
        $this->searching = $this->model->searching;
        $this->template  = 'stock';
    }

    public function sales()
    {
        if (request()->isMethod('POST')) {
            $getData   = $this->model->getBySales();
            $datatable = Datatables::of($this->filter($getData));
            if (request()->has('search')) {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }

        return view('page.' . $this->template . '.sales')->with([
            'fields' => $this->datatable,
        ]);
    }

    public function print_stock_real()
    {

        if (!empty(request()->get('code'))) {
            $id = request()->get('code');
            $detail = $this->model->getDetailRack($id)->get();
            // dd($detail);
            view()->share([
                'data'   => DB::table('products')->where('product_id', '=', $id)->get()->first(),
                'detail' => $detail,
            ]);

            $pdf = PDF::loadView('page.' . $this->template . '.print_opname');
            return $pdf->stream($id . '.pdf');
        }
    }

    public function real()
    {
        if (request()->isMethod('POST')) {
            $getData   = $this->model->getByReal();
            $datatable = Datatables::of($this->filter($getData))
                ->addColumn('action', function ($select) {
                    $id     = 'product_id';
                    $gabung = '<div class="aksi text-center">';
                    $gabung = $gabung . ' <a href="' . route(Route::currentRouteName(), [
                        'code' => $select->$id]) . '" class="btn btn-xs btn-success">show</a></div>';
                    return $gabung;
                })
                ->addColumn('jumlah', function ($select) {
                    return number_format($select->jumlah, 2);
                });

            if (request()->has('search')) {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }
        if (request()->has('code')) {
            $id   = request()->get('code');
            $data = $this->model->getDetailRack($id);

            return view('page.' . $this->template . '.show')->with([
                'fields'   => $this->datatable,
                'data'     => $this->validasi($data),
                'detail'   => $this->model->getDetailRack($id)->get(),
                'key'      => $this->key,
                'template' => $this->template,
            ]);
        }

        $datatable2 = [
            'product_id'       => 'Product ID',
            'product_category' => 'Category',
            'product_material' => 'Material',
            'product_size'     => 'Size',
            'product_name'     => 'Product Full Name',
            'jumlah'           => 'Stock',
            'product_unit'     => 'Unit',
        ];

        return view('page.' . $this->template . '.real')->with([
            'fields'   => $datatable2,
            'template' => $this->template,
        ]);
    }

    public function revisi()
    {

        if (!empty(request()->get('code'))) {
            $id      = request()->get('code');
            $getData = $this->model->getRevisi($id);

            $rack = new \App\Rack();
            return view('page.' . $this->template . '.revisi')->with([
                'template' => $this->template,
                'data'     => $getData->get()->first(),
                'key'      => $this->key,
                'rack'     => $rack->baca()->get(),
                'fields'   => $this->datatable,
            ]);
        } else {
            if (request()->isMethod('POST')) {
                $id      = collect(request()->query())->flip()->first();
                $request = request()->all();
                $this->model->ubah($id, $request);
            }
            return redirect()->back();
        }
    }

    public function bahan()
    {
        if (request()->isMethod('POST')) {
            $getData   = $this->model->getBySupplier();
            $datatable = Datatables::of($this->filter($getData));
            if (request()->has('search')) {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }

        return view('page.' . $this->template . '.bahan')->with([
            'fields' => [
                'product_id'             => 'Product',
                'supplier_name'          => 'Supplier',
                'purchase_delivery_date' => 'Estimasi',
                'product_size'           => 'Size',
                'product_name'           => 'Product Full Name',
                'qty_prepare'            => 'Stock',
                'product_unit'           => 'Unit',
            ],
        ]);
    }

    public function batik()
    {
        if (request()->isMethod('POST')) {
            $getData   = $this->model->getBySPK();
            $datatable = Datatables::of($this->filter($getData));
            if (request()->has('search')) {
                $code      = request()->get('code');
                $search    = request()->get('search');
                $aggregate = request()->get('aggregate');
                $datatable->where(empty($code) ? $this->searching : $code, empty($aggregate) ? 'like' : $aggregate, "%$search%");
            }

            return $datatable->make(true);
        }

        return view('page.' . $this->template . '.bahan')->with([
            'fields' => [
                'product_id'        => 'Product',
                'spk_delivery_date' => 'Estimasi',
                'production_name'   => 'Penjahit',
                'product_size'      => 'Size',
                'product_name'      => 'Product Full Name',
                'qty_prepare'       => 'Stock',
                'product_unit'      => 'Unit',
            ],
        ]);
    }

    
    public function opname()
    {
        if (request()->isMethod('POST')) {
            $this->validate(request(), ['barcode' => 'required']);
            $request = request()->all();

            $produk  = request()->get('product');
            $qty     = request()->get('qty');
            $barcode = request()->get('barcode');

            $this->model->opname($request);
            return redirect()->back();

        } else {
            return view('page.' . $this->template . '.opname')->with([
                'template' => $this->template,
            ]);
        }
    }
    
    public function rack()
    {
        $parse = [];
        if(request()->isMethod('POST')){
            $this->validate(request(), ['code' => 'required']);
            $request = request()->all();
            $code  = request()->get('code');

            $parse = DB::table('stocks')->select(DB::raw('sum(qty) as total_kg'),'products.*')->join('products','stocks.product_code','=','products.product_id')->where('rack_code',$code)->where('qty','>',0)->groupBy('product_id')->get();

        }

        return view('page.' . $this->template . '.rack')->with([
            'template' => $this->template,
            'parse' => $parse,
        ]);
    }

}
