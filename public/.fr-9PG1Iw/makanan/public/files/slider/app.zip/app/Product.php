<?php

namespace App;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;

class Product extends Model {

    protected $table      = 'products'; //nama table
    protected $primaryKey = 'product_id'; //nama primary key
    protected $fillable   = [ //field yang mau di save ke database
        'product_id',
        'product_code',
        'product_name',
        'created_at',
        'updated_at',
        'product_images',
        'product_harga_jual',
        'product_harga_beli',
        'product_unit',
        'product_size',
        'product_stock',
        'product_category',
        'product_segmentasi',
        'product_grouping',
        'product_material',
        'product_description',
        'product_weight',
        'product_weight',
        'product_commision',
    ];
    public $searching    = 'product_name'; //default pencarian ketika di cari
    public $timestamps   = true; //kalau mau automatic update tanggal ketika save atau edit ubah jadi true
    public $incrementing = false; //kalau id nya mau dibuatkan otomatis dari laravel 1,2,3
    public $rules        = [ //validasi https://laravel.com/docs/5.5/validation
      'product_name' => 'required|min:3',
      'product_category' => 'required',
      'product_unit' => 'required',
    ];
    public $datatable    = [ //field dan header buat di show ke list table 
      'product_id'   => 'ID Product',
      'product_material'   => 'Bahan',
      'product_category' => 'Category',
      'product_name' => 'Product Name',
      'jumlah' => 'Stock',
      'product_unit' => 'Satuan',
      'product_harga_jual' => 'Harga Jual',
      'product_images' => 'Images',
    ];

    public function simpan($code, $request, $file = null)
    {
        try
        {
            if(!empty($file)) //handle images
            {
                $name   = $code . '.' . $file->extension();
                $simpen = $file->storeAs('product', $name);

                $request['product_images'] = $name;
            }
            
            $this->Create($request);
            session()->put('success', 'Data Has Been Added !');
        }
        catch(Exception $ex)
        {
            session()->put('danger', $ex->getMessage());
        }
    }

    public function hapus($data)
    {
        if(!empty($data))
        {
            $data = collect($data)->flatten()->all();
            try
            {
                $this->Destroy($data);
                session()->flash('alert-success', 'Data Has Been Deleted !');
            }
            catch(\Exception $e)
            {
                session()->flash('alert-danger', $e->getMessage());
            }
        }
    }

    public function ubah($id, $request, $file=null)
    {
        try
        {
            if(!empty($file)) //handle images
            {
                
                $name   = $id . '.' . $file->extension();
                $simpen = $file->storeAs('product', $name);

                $request['product_images'] = $name;
            }
            
            $s = $this->find($id);
            $s->update($request);
            
            session()->put('success', 'Data Has Been Updated !');
        }
        catch(\Exception $e)
        {
            session()->flash('alert-danger', $e->getMessage());
        }
    }

    public function baca($id = null)
    {
        if(!empty($id))
        {
            return $this->where($this->primaryKey, $id);
        }
        else
        {
            return $this->select();
        }
    }

    public function getStock($id = null)
    {
       $data = DB::table('products');
        $data->select(['products.*',DB::raw('(SUM(stocks.qty)) as jumlah'),'stocks.reference']);
        $data->leftJoin('stocks','products.product_id','=','stocks.product_code');

         if(!empty($id))
        {
            $data->where($this->primaryKey, $id);
        }
        $data->groupBy('products.product_id');
        return $data;
    }

    public function segment($id = null)
    {
         $data = DB::table('products');
        $data->select(['products.*',DB::raw('(SUM(stocks.qty)) as jumlah'),'stocks.reference']);
        $data->leftJoin('stocks','products.product_id','=','stocks.product_code');
        $data->where('stocks.wh_type','=','IN');
        $data->where('product_segmentasi','=',$id);
        $data->groupBy('products.product_id');
        return $data;
    }

}
