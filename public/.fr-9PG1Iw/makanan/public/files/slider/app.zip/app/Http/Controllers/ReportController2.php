<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Excel;

class ReportController extends Controller
{

    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $read;
    public $payment_model;

    public function __construct()
    {
        $this->model     = new \App\Warehouse();
        $this->table     = $this->model->getTable();
        $this->key       = $this->model->getKeyName();
        $this->field     = $this->model->getFillable();
        $this->datatable = $this->model->datatable;
        $this->rules     = $this->model->rules;
        $this->searching = $this->model->searching;
        $this->template  = 'owner';
        $this->payment_model = [
            'ECT' => 'Lain-lain', 
            'PO' => 'Purchase Order (PO)', 
            'SO' => 'Sales Order (SO)', 
            'SPK' => 'Produksi Batik (SPK)', 
            'FEE' => 'Fee Sales (FEE)', 
            'DO' => 'Delivery Order (DO)'
        ];
    }

    public function index()
    {
        return '';
    }

    public function penjualan_product()
    {
        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $customer   = request()->get('customer');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('orders');
            $data->join('customers', 'customers.customer_id', '=', 'orders.customer_id');
            $data->join('users', 'users.email', '=', 'orders.email');
            $data->join('sites', 'sites.site_id', '=', 'customers.site_id');
            $data->join('order_detail', 'order_detail.detail', '=', 'orders.order_id');
            $data->join('products', 'order_detail.product', '=', 'products.product_id');
            $data->select([
                'order_id',
                'customers.customer_name',
                'sites.site_name',
                'users.name',
                'order_date',
                'order_delivery_date',
                'order_status',
                'products.product_id',
                'products.product_code',
                'products.product_grouping',
                'products.product_name',
                'order_detail.qty',
                'order_detail.price',
                'order_detail.total',
                'products.product_category',
                'products.product_unit',
                'products.product_size',
                'products.product_weight',
                'products.product_commision',
                'orders.airbill',
                'orders.courier',
                'orders.courier_service',
                'orders.qty_total',
                'orders.estimasi_cost',
                'orders.delivery_cost',
            ]);

            if (!empty($start)) {
                $data->where('order_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('order_date', '<=', $end);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }
            if (!empty($size)) {
                $data->where('products.product_size', '=', $size);
            }
            if (!empty($customer)) {
                $data->where('orders.customer_id', '=', $customer);
            }
            if (!empty($category)) {
                $data->where('products.product_category', '=', $category);
            }
            if (!empty($user)) {
                $data->where('orders.email', '=', $user);
            }
            if (!empty($site)) {
                $data->where('customers.site_id', '=', $site);
            }
            if (!empty($kurir)) {
                $data->where('orders.courier', '=', $kurir);
            }
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            
            $column = 'A';
            $sheet->setCellValue($column.'1', 'Order No.');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'B';
            $sheet->setCellValue($column.'1', 'Nama Customer');
            $sheet->getColumnDimension($column)->setAutoSize(true);

            $column = 'C';
            $sheet->setCellValue($column.'1', 'Wilayah');
            $sheet->getColumnDimension($column)->setAutoSize(true);

            $column = 'D';
            $sheet->setCellValue($column.'1', 'Nama Sales');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'E';
            $sheet->setCellValue($column.'1', 'Tanggal Order');
            $sheet->getColumnDimension($column)->setAutoSize(true);
        
            $column = 'F';
            $sheet->setCellValue($column.'1', 'Tanggal Pengiriman');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'G';
            $sheet->setCellValue($column.'1', 'Status');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'H';
            $sheet->setCellValue($column.'1', 'ID Product');
            $sheet->getColumnDimension($column)->setAutoSize(true);

            $column = 'I';
            $sheet->setCellValue($column.'1', 'Code Product');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'J';
            $sheet->setCellValue($column.'1', 'Group Product');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'K';
            $sheet->setCellValue($column.'1', 'Nama Product');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'L';
            $sheet->setCellValue($column.'1', 'Qty');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'M';
            $sheet->setCellValue($column.'1', 'Delivery');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'N';
            $sheet->setCellValue($column.'1', 'Price');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'O';
            $sheet->setCellValue($column.'1', 'Total');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'P';
            $sheet->setCellValue($column.'1', 'Product Category');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'Q';
            $sheet->setCellValue($column.'1', 'Satuan');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'R';
            $sheet->setCellValue($column.'1', 'Size');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'S';
            $sheet->setCellValue($column.'1', 'Berat');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'T';
            $sheet->setCellValue($column.'1', 'Komisi');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'U';
            $sheet->setCellValue($column.'1', 'No Resi');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'V';
            $sheet->setCellValue($column.'1', 'Kurir');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'W';
            $sheet->setCellValue($column.'1', 'Jasa Pengiriman');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'X';
            $sheet->setCellValue($column.'1', 'Total Kg');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'Y';
            $sheet->setCellValue($column.'1', 'Estimasi Cost');
            $sheet->getColumnDimension($column)->setAutoSize(true);

            $column = 'Z';
            $sheet->setCellValue($column.'1', 'Delivery Cost');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $cell = 1;
            $total = 0;
            foreach($data->get() as $value){
                $cell = $cell + 1;
                $sub = $value->qty_release * $value->price;
                
                $column = 'A';
                $sheet->setCellValue($column.$cell, $value->order_id);
                $sheet->getColumnDimension($column)->setAutoSize(true);
 
                $column = 'B';
                $sheet->setCellValue($column.$cell, $value->customer_name);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'C';
                $sheet->setCellValue($column.$cell, $value->site_name);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'D';
                $sheet->setCellValue($column.$cell, $value->name);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'E';
                $sheet->setCellValue($column.$cell, $value->order_date);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'F';
                $sheet->setCellValue($column.$cell, $value->order_delivery_date);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'G';
                $sheet->setCellValue($column.$cell, $value->order_status);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'H';
                $sheet->setCellValue($column.$cell, $value->product_id);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'I';
                $sheet->setCellValue($column.$cell, $value->product_code);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'J';
                $sheet->setCellValue($column.$cell, $value->product_grouping);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'K';
                $sheet->setCellValue($column.$cell, $value->product_name);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'L';
                $sheet->setCellValue($column.$cell, $value->qty);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'M';
                $sheet->setCellValue($column.$cell, $value->qty_release);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'N';
                $sheet->setCellValue($column.$cell, $value->price);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'O';
                $sheet->setCellValue($column.$cell, $sub);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'P';
                $sheet->setCellValue($column.$cell, $value->product_category);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'Q';
                $sheet->setCellValue($column.$cell, $value->product_unit);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'R';
                $sheet->setCellValue($column.$cell, $value->product_size);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'S';
                $sheet->setCellValue($column.$cell, $value->product_weight);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'T';
                $sheet->setCellValue($column.$cell, $value->product_commision);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'U';
                $sheet->setCellValue($column.$cell, $value->airbill);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'V';
                $sheet->setCellValue($column.$cell, $value->courier);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'W';
                $sheet->setCellValue($column.$cell, $value->courier_service);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'X';
                $sheet->setCellValue($column.$cell, $value->qty_total);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'Y';
                $sheet->setCellValue($column.$cell, $value->estimasi_cost);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'Z';
                $sheet->setCellValue($column.$cell, $value->delivery_cost);
                $sheet->getColumnDimension($column)->setAutoSize(true);
            }

            $file = 'penjualan '.$start.' - '.$end.'.xlsx';
            $excel_path = public_path('files/'.$file); 
            $writer = new Xlsx($spreadsheet);
            $writer->save($excel_path);
            return response()->download($excel_path)->deleteFileAfterSend(true);
        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.penjualan')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

    public function kas()
    {
        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $pengirim   = request()->get('pengirim');
        $penerima   = request()->get('penerima');
        $model      = request()->get('model');
        $reference  = request()->get('reference');
        $type       = request()->get('type');
        $status     = request()->get('status');

        if (!empty($start) || !empty($end)) {
            $data = DB::table('payments');
            $data->join('accounts', 'payments.account_to', '=', 'accounts.account_id');
            
            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();
            
            if (!empty($start)) {
                $data->where('payment_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('payment_date', '<=', $end);
            }
            if (!empty($pengirim) && $pengirim != 'etc') {
                $data->where('account_from', '=', $pengirim);
            }
            if (!empty($penerima)) {
                $data->where('account_to', '=', $penerima);
            }
            if (!empty($model)) {
                $data->where('payment_model', '=', $model);
            }
            if (!empty($reference)) {
                $data->where('reference', '=', $reference);
            }
            if (!empty($type)) {
                $data->where('payment_type', '=', $type);
            }
            if (!empty($status)) {
                $data->where('payment_status', '=', $status);
            }

            $column = 'A';
            $sheet->setCellValue($column.'1', 'Payment Voucher');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'B';
            $sheet->setCellValue($column.'1', 'Nama Bank');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'C';
            $sheet->setCellValue($column.'1', 'Reference');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'D';
            $sheet->setCellValue($column.'1', 'Tanggal Pembayaran');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'E';
            $sheet->setCellValue($column.'1', 'Nama');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'F';
            $sheet->setCellValue($column.'1', 'Nilai Pembayaran');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'G';
            $sheet->setCellValue($column.'1', 'Type');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'H';
            $sheet->setCellValue($column.'1', 'Description');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'I';
            $sheet->setCellValue($column.'1', 'Approve Amount');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'J';
            $sheet->setCellValue($column.'1', 'Nama');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'K';
            $sheet->setCellValue($column.'1', 'Status');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'L';
            $sheet->setCellValue($column.'1', 'Created By');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $column = 'M';
            $sheet->setCellValue($column.'1', 'Model');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $cell = 1;
            $total = 0;
            foreach($data->get() as $value){
                $cell = $cell + 1;
                
                $column = 'A';
                $sheet->setCellValue($column.$cell, $value->payment_voucher);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'B';
                $sheet->setCellValue($column.$cell, $value->account_name);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'C';
                $sheet->setCellValue($column.$cell, $value->reference);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'D';
                $sheet->setCellValue($column.$cell, $value->payment_date);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'E';
                $sheet->setCellValue($column.$cell, $value->payment_person);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'F';
                $sheet->setCellValue($column.$cell, $value->payment_amount);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'G';
                $sheet->setCellValue($column.$cell, $value->payment_type);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'H';
                $sheet->setCellValue($column.$cell, $value->payment_description);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'I';//amount
                $sheet->setCellValue($column.$cell, $value->approve_amount);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'J';//nama
                $sheet->setCellValue($column.$cell, $value->approved_by);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'K';//status
                $sheet->setCellValue($column.$cell, $value->payment_status);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                
                $column = 'L';//create
                $sheet->setCellValue($column.$cell, $value->approve_amount);
                $sheet->getColumnDimension($column)->setAutoSize(true);
            
                $column = 'M';//model
                $sheet->setCellValue($column.$cell, $value->payment_model);
                $sheet->getColumnDimension($column)->setAutoSize(true);
            }


            $file = 'kas '.$start.' - '.$end.'.xlsx';
            $excel_path = public_path('files/'.$file); 
            $writer = new Xlsx($spreadsheet);
            $writer->save($excel_path);
            return response()->download($excel_path)->deleteFileAfterSend(true);

        } else {
            $account = new \App\Account();
            return view('report.' . $this->template . '.kas')->with([
                'template'   => $this->template,
                'account' => $account->baca()->get(),
                'model'    => collect($this->payment_model),
            ]);
        }
    }

    public function stock()
    {
        $product      = request()->get('product');
        $category        = request()->get('category');
        $size        = request()->get('size');
        $segmentasi        = request()->get('segmentasi');

        if (!empty($product) || !empty($category) || !empty($size) || !empty($segmentasi)) {
            $data = DB::table('products');
            $data->leftjoin('stocks', 'products.product_id', '=', 'stocks.product_code');
            $data->select([
                'product_id',
                'products.product_code',
                'product_grouping',
                'product_name',
                'product_category',
                'product_unit',
                'product_size',
                'product_stock',
            ]);
            $data->addSelect(DB::raw('SUM(qty) as qty'));
            $data->groupBy('product_id');

            $spreadsheet = new Spreadsheet();
            $sheet = $spreadsheet->getActiveSheet();

            if (!empty($product) && $product != 'all') {
                $data->where('product_id', '=', $product);
            }

            if (!empty($category)) {
                $data->where('product_category', '=', $category);
            }
            if (!empty($size)) {
                $data->where('product_size', '=', $size);
            }
            if (!empty($segmentasi)) {
                $data->where('product_segmentasi', '=', $segmentasi);
            }

            $column = 'A';
            $sheet->setCellValue($column.'1', 'Product ID');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            $column = 'B';
            $sheet->setCellValue($column.'1', 'Code');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            $column = 'C';
            $sheet->setCellValue($column.'1', 'Group');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            $column = 'D';
            $sheet->setCellValue($column.'1', 'Product Name');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            $column = 'E';
            $sheet->setCellValue($column.'1', 'Category');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            $column = 'F';
            $sheet->setCellValue($column.'1', 'Unit');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            $column = 'G';
            $sheet->setCellValue($column.'1', 'Size');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            $column = 'H';
            $sheet->setCellValue($column.'1', 'Stock Sales');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            $column = 'I';
            $sheet->setCellValue($column.'1', 'Stock Real');
            $sheet->getColumnDimension($column)->setAutoSize(true);
            
            $cell = 1;
            $total = 0;
            foreach($data->get() as $value){
                $cell = $cell + 1;

                $column = 'A';
                $sheet->setCellValue($column.$cell, $value->product_id);
                $sheet->getColumnDimension($column)->setAutoSize(true);
  
                $column = 'B';
                $sheet->setCellValue($column.$cell, $value->product_code);
                $sheet->getColumnDimension($column)->setAutoSize(true);
                $sheet->getStyle($column.$cell)->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT);
                // $sheet->getStyle($column.$cell)->getFill()->setFillType(\PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID);
                // $sheet->getStyle($column.$cell)->getFill()->getStartColor()->setARGB('FFFFFF');
  
                $column = 'C';
                $sheet->setCellValue($column.$cell, $value->product_grouping);
                $sheet->getColumnDimension($column)->setAutoSize(true);
  
                $column = 'D';
                $sheet->setCellValue($column.$cell, $value->product_name);
                $sheet->getColumnDimension($column)->setAutoSize(true);
  
                $column = 'E';
                $sheet->setCellValue($column.$cell, $value->product_category);
                $sheet->getColumnDimension($column)->setAutoSize(true);
  
                $column = 'F';
                $sheet->setCellValue($column.$cell, $value->product_unit);
                $sheet->getColumnDimension($column)->setAutoSize(true);
  
                $column = 'G';
                $sheet->setCellValue($column.$cell, $value->product_size);
                $sheet->getColumnDimension($column)->setAutoSize(true);
 
                $column = 'H';
                $sheet->setCellValue($column.$cell, $value->product_stock);
                $sheet->getColumnDimension($column)->setAutoSize(true);
 
                $column = 'I';
                $sheet->setCellValue($column.$cell, $value->qty);
                $sheet->getColumnDimension($column)->setAutoSize(true);
 
            }

            $file = 'stock.xlsx';
            $excel_path = public_path('files/'.$file); 
            $writer = new Xlsx($spreadsheet);
            $writer->save($excel_path);
            return response()->download($excel_path)->deleteFileAfterSend(true);


        } else {
            $product = new \App\Product();
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            return view('report.' . $this->template . '.stock')->with([
                'template'   => $this->template,
                'product' => $product->baca()->get(),
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
            ]);
        }
    }

    public function komisi()
    {
        // $start      = request()->get('date_start');
        // $end        = request()->get('date_end');
        // $segmentasi = request()->get('segmentasi');
        // $size       = request()->get('size');
        // $customer   = request()->get('customer');
        // $category   = request()->get('category');
        // $user       = request()->get('user');
        // $site       = request()->get('site');
        // $kurir      = request()->get('kurir');
        // $status     = request()->get('status');

        // if (!empty($start) && !empty($end)) {
        //     $data = DB::table('orders');
        //     $data->join('customers', 'customers.customer_id', '=', 'orders.customer_id');
        //     $data->join('users', 'users.email', '=', 'orders.email');
        //     $data->join('sites', 'sites.site_id', '=', 'customers.site_id');
        //     $data->join('order_detail', 'order_detail.detail', '=', 'orders.order_id');
        //     $data->join('products', 'order_detail.product', '=', 'products.product_id');
        //     $data->select([
        //         'order_id',
        //         'customers.customer_name',
        //         'sites.site_name',
        //         'users.name',
        //         'order_date',
        //         'order_delivery_date',
        //         'order_status',
        //         'products.product_id',
        //         'products.product_code',
        //         'products.product_grouping',
        //         'products.product_name',
        //         'order_detail.qty',
        //         'order_detail.price',
        //         'order_detail.total',
        //         'products.product_category',
        //         'products.product_unit',
        //         'products.product_size',
        //         'products.product_weight',
        //         'products.product_commision',
        //         'orders.airbill',
        //         'orders.courier',
        //         'orders.courier_service',
        //         'orders.qty_total',
        //         'orders.estimasi_cost',
        //         'orders.delivery_cost',
        //     ]);

        //     if (!empty($start)) {
        //         $data->where('order_date', '>=', $start);
        //     }
        //     if (!empty($end)) {
        //         $data->where('order_date', '<=', $end);
        //     }
            
        //     view()->share([
        //         'data'   => $this->validasi($data),
        //         'detail' => $this->model->getDetail($id),
        //     ]);

        //     $pdf = PDF::loadView('page.' . $this->template . '.approve');
        //     return $pdf->stream($id . '.pdf');

        // } else {
        //     $user       = new \App\User();
        //     return view('report.' . $this->template . '.komisi')->with([
        //         'template'   => $this->template,
        //         'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
        //     ]);
        // }


        $data = array(
            array('data1', 'data2'),
            array('data3', 'data4')
        );

        Excel::create('Filename', function($excel) use($data) {

            $excel->sheet('Sheetname', function($sheet) use($data) {

                $sheet->fromArray($data);

            });

        })->export('xls');
    }

}
