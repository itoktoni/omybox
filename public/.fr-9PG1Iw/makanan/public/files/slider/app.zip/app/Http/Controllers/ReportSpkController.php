<?php

namespace App\Http\Controllers;

use Excel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class ReportSpkController extends Controller
{
    public $table;
    public $key;
    public $field;
    public $model;
    public $template;
    public $rules;
    public $datatable;
    public $searching;
    public $read;
    public $payment_model;

    public function __construct()
    {
        $this->model         = new \App\Warehouse();
        $this->table         = $this->model->getTable();
        $this->key           = $this->model->getKeyName();
        $this->field         = $this->model->getFillable();
        $this->datatable     = $this->model->datatable;
        $this->rules         = $this->model->rules;
        $this->searching     = $this->model->searching;
        $this->template      = 'spk';
        $this->payment_model = [
            'ECT' => 'Lain-lain',
            'PO'  => 'spk Order (PO)',
            'SO'  => 'Sales Order (SO)',
            'SPK' => 'Produksi Batik (SPK)',
            'FEE' => 'Fee Sales (FEE)',
            'DO'  => 'Delivery Order (DO)',
        ];
    }

    public function index()
    {
        return '';
    }

    public function penjualan_product()
    {

        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $production   = request()->get('production');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('spk');
            $data->join('productions', 'productions.production_id', '=', 'spk.production_id');
            $data->join('spk_detail', 'spk_detail.detail', '=', 'spk.spk_id');
            $data->join('products', 'spk_detail.product', '=', 'products.product_id');
            $data->select([
                'spk_id as Code spk',
                'productions.production_name as Nama Penjahit',
                'spk_date as Tanggal Order',
                'spk_delivery_date as Tanggal Pengiriman',
                'spk_status as Status',
                'products.product_id as ID Product',
                'products.product_code as Code Product',
                'products.product_grouping as Group Product',
                'products.product_name as Nama Product',
                'spk_detail.qty_prepare as Qty',
                'spk_detail.price as Price',
                'spk_detail.total as Total',
                'products.product_category as Product Category',
                'products.product_unit as Satuan',
                'products.product_size as Size',
            ]);

            if (!empty($start)) {
                $data->where('spk_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('spk_date', '<=', $end);
            }
           
            if (!empty($supplier)) {
                $data->where('spk.production_id', '=', $supplier);
            }
            
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Penjualan ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Penjualan', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;
        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            //$supplier   = new \App\Supplier();
            $user       = new \App\User();
            $site       = new \App\Site();

            $production = DB::table('productions');
            if(Auth::user()->group_user == 'production'){
                $production->where('production_id','=',Auth::user()->supplier_id);
            }

            return view('report.' . $this->template . '.penjualan')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'production'   => $production->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

    public function kas()
    {
        $start     = request()->get('date_start');
        $end       = request()->get('date_end');
        $pengirim  = request()->get('pengirim');
        $penerima  = request()->get('penerima');
        $model     = request()->get('model');
        $reference = request()->get('reference');
        $type      = request()->get('type');
        $status    = request()->get('status');

        if (!empty($start) || !empty($end)) {
            $data = DB::table('payments');
            $data->select([

                'payments.payment_voucher as Payment Voucher',
                'payments.account_from as Bank Pengirim',
                'payments.account_to as Bank Penerima',
                'reference as Reference',
                'payment_date as Tanggal Pembayaran',
                'payment_person as Nama',
                'payment_amount as Nilai Pembayaran',
                'payment_type as Type',
                'payment_description as Description',
                'approve_amount as Approve Amount',
                'payment_status as Status',
                'created_by as Created By',
                'payment_model as Model',
            ]);

            if (!empty($start)) {
                $data->where('payment_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('payment_date', '<=', $end);
            }
            if (!empty($pengirim) && $pengirim != 'etc') {
                $data->where('account_from', '=', $pengirim);
            }
            if (!empty($penerima)) {
                $data->where('account_to', '=', $penerima);
            }
            if (!empty($model)) {
                $data->where('payment_model', '=', $model);
            }
            if (!empty($reference)) {
                $data->where('reference', '=', $reference);
            }
            if (!empty($type)) {
                $data->where('payment_type', '=', $type);
            }
            if (!empty($status)) {
                $data->where('payment_status', '=', $status);
            }

            $data  = json_decode(json_encode($data->get()->toArray()), true);
            $excel = Excel::create('Report Kas ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Kas', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;

        } else {
            $payment = new \App\Payment();
            return view('report.' . $this->template . '.kas')->with([
                'template' => $this->template,
                'from'     => $payment->baca()->select('account_from')->distinct()->get(),
                'to'       => $payment->baca()->select('account_to')->distinct()->get(),
                'model'    => collect($this->payment_model),
            ]);
        }
    }

    public function stock()
    {
        $product    = request()->get('product');
        $category   = request()->get('category');
        $size       = request()->get('size');
        $segmentasi = request()->get('segmentasi');

        if (!empty($product) || !empty($category) || !empty($size) || !empty($segmentasi)) {
            $data = DB::table('products');
            $data->leftjoin('stocks', 'products.product_id', '=', 'stocks.product_code');
            // $data->select([
            //     'product_id as Product ID',
            //     'products.product_code as Product Code',
            //     'product_grouping as Group',
            //     'product_name as Product Name',
            //     'product_category as Category',
            //     'product_unit as Unit',
            //     'product_size as Size',
            //     'product_stock as Stock Sales',
            // ]);
            $data->select('products.*');
            $data->addSelect(DB::raw('SUM(qty) as qty'));
            $data->groupBy('product_id');

            if (!empty($product) && $product != 'all') {
                $data->where('product_id', '=', $product);
            }

            if (!empty($category)) {
                $data->where('product_category', '=', $category);
            }
            if (!empty($size)) {
                $data->where('product_size', '=', $size);
            }
            if (!empty($segmentasi)) {
                $data->where('product_segmentasi', '=', $segmentasi);
            }

            $items = array();
            $hold  = 0;
            foreach ($data->get() as $value) {
                if ($value->product_category == 'Batik') {

                    $onhold = DB::table('spk')
                        ->select([DB::raw('(SUM(qty_prepare)) as jumlah')])
                        ->leftJoin('spk_detail', 'spk_detail.detail', '=', 'spk.spk_id')
                        ->where('product', '=', $value->product_id)
                        ->where('spk_status', '=', 'PREPARED')
                        ->orwhere('spk_status', '=', 'DELIVERED')
                        ->where('product', '=', $value->product_id);

                    if (!empty($onhold->first())) {

                        $hold    = 0;
                        $getHold = $onhold->first();
                        $hold    = $getHold->jumlah;

                    }
                } else {

                    $onhold = DB::table('spk')
                        ->select([DB::raw('(SUM(qty_prepare)) as jumlah')])
                        ->leftJoin('spk_detail', 'spk_detail.detail', '=', 'spk.spk_id')
                        ->where('product', '=', $value->product_id)
                        ->where('spk_status', '=', 'PREPARED')
                        ->orwhere('spk_status', '=', 'DELIVERED')
                        ->where('product', '=', $value->product_id);

                    if (!empty($onhold->first())) {

                        $hold    = 0;
                        $getHold = $onhold->first();
                        $hold    = $getHold->jumlah;
                    }
                }

                $onbooking = DB::table('orders')
                    ->select([DB::raw('(SUM(qty)) as jumlah')])
                    ->leftJoin('order_detail', 'order_detail.detail', '=', 'orders.order_id')
                    ->where('product', '=', $value->product_id)
                    ->where('order_status', '!=', 'COMPLETE')
                    ->where('order_status', '!=', 'PAID');

                $booking = 0;
                if (!empty($onbooking->first())) {
                    $getBook = $onbooking->first();
                    $booking = $getBook->jumlah;
                }

                $items[] = [
                    'Product ID'   => $value->product_id,
                    'Product Code' => $value->product_code,
                    'Group'        => $value->product_grouping,
                    'Product Name' => $value->product_name,
                    'Category'     => $value->product_category,
                    'Size'         => $value->product_size,
                    'Stock'        => $value->product_stock,
                    'Booking'      => $booking,
                    'Real'         => $value->qty,
                    'Hold'         => $hold,
                ];
            }

            $data  = json_decode(json_encode($items), true);
            $excel = Excel::create('Report Stock ', function ($excel) use ($data) {

                $excel->sheet('Stock', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;

        } else {
            $product    = new \App\Product();
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            return view('report.' . $this->template . '.stock')->with([
                'template'   => $this->template,
                'product'    => $product->baca()->get(),
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
            ]);
        }
    }

    public function tagihan()
    {

        $start      = request()->get('date_start');
        $end        = request()->get('date_end');
        $segmentasi = request()->get('segmentasi');
        $size       = request()->get('size');
        $customer   = request()->get('customer');
        $category   = request()->get('category');
        $user       = request()->get('user');
        $site       = request()->get('site');
        $kurir      = request()->get('kurir');
        $status     = request()->get('status');

        if (!empty($start) && !empty($end)) {
            $data = DB::table('orders');
            $data->join('customers', 'customers.customer_id', '=', 'orders.customer_id');
            $data->join('users', 'users.email', '=', 'orders.email');
            $data->select([

                'order_id',
                'customers.customer_name',
                'users.name as sales_name',
                'order_date',
                'order_delivery_date',
                'order_status',
                'orders.airbill',
                'orders.courier',
                'orders.courier_service',
                'orders.estimasi_cost',
                'orders.delivery_cost',
            ]);

            if (!empty($start)) {
                $data->where('order_date', '>=', $start);
            }
            if (!empty($end)) {
                $data->where('order_date', '<=', $end);
            }
            if (!empty($segmentasi)) {
                $data->where('products.product_segmentasi', '=', $segmentasi);
            }
            if (!empty($size)) {
                $data->where('products.product_size', '=', $size);
            }
            if (!empty($customer)) {
                $data->where('orders.customer_id', '=', $customer);
            }
            if (!empty($category)) {
                $data->where('products.product_category', '=', $category);
            }
            if (!empty($user)) {
                $data->where('orders.email', '=', $user);
            }
            if (!empty($kurir)) {
                $data->where('orders.courier', '=', $kurir);
            }
            if (!empty($status)) {
                $data->where('orders.order_status', '=', $status);
            }

            $items = array();
            $hold  = 0;
            foreach ($data->get() as $value) {

                $onvalue = DB::table('order_detail')
                    ->select([DB::raw('(SUM(qty_prepare * price)) as jumlah')])
                    ->where('detail', '=', $value->order_id);

                $jumlah = 0;
                if (!empty($onvalue->first())) {
                    $getValue = $onvalue->first();
                    $jumlah    = $getValue->jumlah;
                }

                $onproduct = DB::table('order_detail')
                    ->select([DB::raw('(COUNT(product)) as total')])
                    ->where('detail', '=', $value->order_id);

                $product = 0;
                if (!empty($onproduct->first())) {
                    $getProduct = $onproduct->first();
                    $product    = $getProduct->total;
                }

                $onpembayaran = DB::table('payments')
                    ->select([DB::raw('(SUM(approve_amount)) as amount')])
                    ->where('reference', '=', $value->order_id);

                $pembayaran = 0;
                if (!empty($onpembayaran->first())) {
                    $getPembayaran = $onpembayaran->first();
                    $pembayaran = $getPembayaran->amount;
                }

                $komisi = empty(request()->get('komisi')) ? 0 : request()->get('komisi');

                $items[] = [
                    'Order ID'      => $value->order_id,
                    'Customer Name' => $value->customer_name,
                    'Sales Name'    => $value->sales_name,
                    'Order Date'    => $value->order_date,
                    'Delivery Date' => $value->order_delivery_date,
                    'Status'        => $value->order_status,
                    'airbill'       => $value->airbill,
                    'Courier'       => $value->courier,
                    'Service'       => $value->courier_service,
                    'Estimasi Cost' => $value->estimasi_cost,
                    'Delivery Cost' => $value->delivery_cost,
                    'Total Value'   => $jumlah,
                    'Total Product' => $product,
                    'Pembayaran'    => $pembayaran,
                    'Komisi'        => $product * $komisi,
                    'Net Komisi'    => ($product * $komisi) - $value->delivery_cost,
                ];
            }

            $data  = json_decode(json_encode($items), true);
            $excel = Excel::create('Komisi ' . $start . ' sampai ' . $end, function ($excel) use ($data) {

                $excel->sheet('Komisi', function ($sheet) use ($data) {
                    $sheet->fromArray($data, null, 'A1', true, true);
                });

            })->export('xls');
            return $excel;
        } else {
            $segmentasi = new \App\Segmentasi();
            $size       = new \App\Size();
            $category   = new \App\Category();
            $customer   = new \App\Customer();
            $user       = new \App\User();
            $site       = new \App\Site();
            return view('report.' . $this->template . '.komisi')->with([
                'template'   => $this->template,
                'segmentasi' => $segmentasi->baca()->get(),
                'size'       => $size->baca()->get(),
                'category'   => $category->baca()->get(),
                'customer'   => $customer->baca()->get(),
                'site'       => $site->baca()->get(),
                'sales'      => $user->baca()->where('group_user', '=', 'sales')->get(),
            ]);
        }
    }

}
