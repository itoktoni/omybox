<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class SendEmail extends Command
{

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'email:system';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This Commands To Sending Email';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $query = DB::table('spk')->whereNull('spk_prepare');
        $query1 = DB::table('spk')->whereNull('spk_send_date');
        $query2 = DB::table('spk')->whereNull('spk_receive_date');
        
        if ($query->count() > 0) {
            $this->sendMail(['data' => $query->get()]);
        }
        else if($query1->count() > 0){
            
            $this->sendMail(['data' => $query1->get()]);
        }
        else if($query2->count() > 0){
            
            $this->sendMail(['data' => $query2->get()]);
        }

        $this->info('The system has been sent successfully!');
    }
    
    public function sendMail($data){

        if(!empty($data)){
            Mail::send('emails.send', $data, function ($message){
                 $message->to(config('mail.from.address'), config('mail.from.name'));
                //$message->to('itok.toni@gmail.com', config('mail.from.name'));
                $message->subject('List Pending SPK');
                $message->from(config('mail.from.address'), config('mail.from.name'));
            });
        }
    }

}
