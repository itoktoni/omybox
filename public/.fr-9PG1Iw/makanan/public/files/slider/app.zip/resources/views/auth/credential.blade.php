<!doctype html>
<html class="fixed">
<head>

    <meta charset="UTF-8">
    <meta name="keywords" content="{{ config('app.name', 'Laravel') }}" />
    <meta name="description" content="{{ config('app.name', 'Laravel') }}">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>
    <!--<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">-->
    <link rel="stylesheet" href="{{ asset('public/assets/vendor/bootstrap/css/bootstrap.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/assets/vendor/font-awesome/css/font-awesome.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/assets/vendor/magnific-popup/magnific-popup.css') }}" />

    <link rel="stylesheet" href="{{ asset('public/assets/stylesheets/theme.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/assets/stylesheets/skins/default.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/assets/stylesheets/theme-custom.css') }}">
    <script src="{{ asset('public/assets/vendor/modernizr/modernizr.js') }}"></script>

    <script> window.Laravel = <?php echo json_encode(['csrfToken' => csrf_token(),]);?></script>

</head>
<body>
<section class="body-sign">
    <div class="center-sign">
        <a href="{{ url('/') }}" class="logo pull-left">
            <img src="{{ asset('public/files/logo') }}/{{ config('website.logo','default_favicon.png') }}" height="54" alt="{{ config('app.name')}}" />
        </a>
    @yield('content')
    </div>
</section>

<!-- Vendor -->
<script src="{{ asset('public/assets/vendor/jquery/jquery.js') }}"></script>
<script src="{{ asset('public/assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js') }}"></script>
<script src="{{ asset('public/assets/vendor/bootstrap/js/bootstrap.js') }}"></script>
<script src="{{ asset('public/assets/vendor/nanoscroller/nanoscroller.js') }}"></script>
<script src="{{ asset('public/assets/vendor/jquery-placeholder/jquery.placeholder.js') }}"></script>

</body>
</html>