
<div class="form-group">
    <label class="col-md-2 control-label">Warehouse Code</label>
    <div class="col-md-4 {{ $errors->has('warehouse_id') ? 'has-error' : ''}}">
        {!! Form::text('warehouse_id', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Warehouse Name</label>
    <div class="col-md-4 {{ $errors->has('product_name') ? 'has-error' : ''}}">
        {!! Form::text('warehouse_name', null, ['class' => 'form-control']) !!}
    </div>
</div>
