@extends('backend.'.config('website.backend').'.layouts.app')

@section('content')
<div class="row">
    {!! Form::model($data, ['route'=>[$form.'_send', $data->$key],'class'=>'form-horizontal','files'=>true]) !!}
    <div class="panel panel-default">
        <header class="panel-heading">
            <h2 class="panel-title">Nomor PO : {{ $data->$key }}</h2>
        </header>

        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-table table-bordered table-striped table-hover mb-none">
                    <tbody>
                        <tr>
                            <th class="col-lg-2">Tanggal Order</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="spk_date" readonly="" class="form-control input-sm" value="{{ $data->spk_date }}">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th valign="middle" class="col-lg-2">Tanggal Pengiriman</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="spk_send_date" id="datepicker" class="form-control input-sm datepicker" value="{{ $data->spk_send_date }}">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th valign="middle" class="col-lg-2">Status Pengiriman</th>
                            <td>
                                <div class="col-md-3">
                                    {{ Form::select('spk_status', ['PREPARED' => 'PREPARED','PRODUCTION' => 'PRODUCTION'], null, ['class'=> 'form-control']) }}
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th class="col-lg-2">File Attachment</th>
                            <td>
                                <div class="col-md-3">
                                    <a class="btn btn-danger" target="_blank" href="{{ asset('public/files/po/'.$data->spk_attachment) }}">Download File</a> 
                                </div>
                                
                            </td>
                        </tr> 
                    </tbody>
                </table>
                <table class="table table-table table-bordered table-striped table-hover mb-none">
                    <header class="panel-heading">
                        <h2 class="panel-title text-right">Original SPK</h2>
                    </header>
                    <tr>
                        <th class="col-lg-2">ID Product</th>
                        <th>Product Name</th>
                        <th>Qty</th>
                        <th class="text-right">Yard</th>
                        <th class="text-right">Total Yard</th>
                    </tr>
                    @php
                    $tot_ori = 0;
                    @endphp
                    @foreach($original as $o)
                    <tr>
                        @php
                        $tot_ori = $tot_ori + $o->total_yard;
                        @endphp
                        <td class="col-lg-2">{{ $o->product_id }}</td>
                        <td>{{ $o->product_name }}</td>
                        <td>{{ $o->qty }}</td>
                        <input type="hidden" name="product[]" value="{{ $o->product_id }}">
                        <td class="text-right col-md-2">
                            <input type="text" name="delivery[]" readonly="" class="form-control text-right input-sm" value="{{ $o->yard }}">
                        </td>
                        <td class="text-right col-md-2">
                            <input type="text" name="send[]" readonly="" class="form-control text-right input-sm" value="{{ isset($o->total_yard) ? $o->total_yard : 0  }}">
                        </td>
                    </tr>
                    @endforeach
                    <tr class="well default">
                        <th class="text-right" colspan="4">Total</th>
                        <th class="text-right" colspan="5">{{ $tot_ori }}</th>
                    </tr>
                    <tr>
                        <td colspan="6"></td>
                    </tr>
                </table>
                @isset($detail)
                <table class="table table-table table-bordered table-striped table-hover mb-none">
                    <header class="panel-heading">
                        <h2 class="panel-title text-right">Update Delivery</h2>
                    </header>
                    <tr>
                        <th class="col-lg-2">ID Product</th>
                        <th>Product Name</th>
                        <th>Qty</th>
                        <th class="text-right">Yard</th>
                        <th class="text-right">Delivery</th>
                        <th class="text-right">Selisih</th>
                    </tr>
                    @php
                    $tot = 0;
                    @endphp
                    @foreach($detail as $c)
                    <tr>
                        @php
                        $tot = $tot + $c->yard_prepare_out;
                        @endphp
                        <td class="col-lg-2">{{ $c->product_id }}</td>
                        <td>{{ $c->product_name }}</td>
                        <td>{{ $c->qty_out }}</td>
                        <input type="hidden" name="product[]" value="{{ $c->product_id }}">
                        <td class="text-right col-md-2">
                            <input type="text" name="delivery[]" readonly="" class="form-control text-right input-sm" value="{{ $c->yard_out }}">
                        </td>
                        <td class="text-right col-md-2">
                            <input type="text" name="send[]" readonly="" class="form-control text-right input-sm" value="{{ isset($c->yard_prepare_out) ? $c->yard_prepare_out : 0  }}">
                        </td>
                        <td class="text-right">{{ $c->yard_out - $c->yard_prepare_out }}</td>
                    </tr>
                    @endforeach
                    <tr class="well default">
                        <th class="text-right" colspan="4">Total</th>
                        <th class="text-right" colspan="5">{{ $tot }}</th>
                    </tr>
                    <tr>
                        <td colspan="6"></td>
                    </tr>
                </table>
                @endisset
            </div>
        </div>
        <div class="navbar-fixed-bottom" id="menu_action">
            <div class="text-right" style="padding:5px">
                <a href="{!! route("{$form}_read") !!}" class="btn btn-warning">Back</a>
                <button type="reset" class="btn btn-default">Reset</button>
                @isset($receive)
                @if($data->spk_status == 'PREPARED')
                <button type="submit" class="btn btn-primary">Save</button>
                @endif
                @if($data->spk_status == 'PRODUCTION')
                 <a target="_blank" href="{!! route("{$form}_print_production", ["code" => $data->$key]) !!}" class="btn btn-danger">Cetak PDF
                </a>    
                @endif
                @endisset
            </div>
        </div>

    </div>
</div>
{!! Form::close() !!}

@endsection