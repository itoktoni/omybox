
@extends('backend.'.config('website.backend').'.layouts.popup')
@section('css')
<style>
.panel-default>.panel-heading{
    margin-top: -40px;
}
@media screen and (max-width: 400px) and (min-width: 320px) {

    .ui-pnotify .notification-danger{
        margin-top: -60px;
    }
    .ui-pnotify.notification-danger .notification, .ui-pnotify.notification-danger .notification-danger, .ui-pnotify .notification .ui-pnotify-icon{
        margin-top: -60px;
    }
    .panel-default>.panel-heading{
        margin-top: 0px;
    }
}
</style>

@endsection

@section('js')
@endsection

@section('javascript')
<script>
    $(function() {
    $('#code').focus();
    $('#code').keypress(function(y) {
        if(y.which == 13) {
            var barcode = $('#code').val();
            
            // end enter
        }
    });
});
</script>
@endsection

@section('content')

<div class="row">

    {!! Form::open(['route' => $form.'_rack', 'class' => 'form-horizontal', 'files' => true]) !!}  
    <div class="panel panel-default" style="margin-bottom: 300px;">
        <header class="panel-heading">
            <h2 class="panel-title">Stock Per Rack</h2>
        </header>

        <div class="panel-body">
            <div class="col-xs-12 col-lg-12">

                @if(!empty($parse))
                <div class="form-group">
                    <table class="table table-no-more table-bordered table-striped mb-none">
                        <thead>
                            <tr>
                                <th class="text-left col-lg-1">Name</th>
                                <th class="text-left">QTY</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($parse as $p)
                            <tr>
                                <td data-title="Name">{{ $p->product_name }}</td>
                                <td data-title="QTY">{{ number_format($p->total_kg) }}</td>
                            </tr>
                        
                        @endforeach
                        </tbody>
                    </table>
                </div>

                @endif

                <hr>
            </div>
        </div>
        
        <div class="navbar-fixed-bottom" id="menu_action">
            <div class="text-right" style="padding:5px;top:5px;margin-bottom: 5px; margin-top: 5px;">
              <button type="reset" class="btn btn-default col-md-1 col-xs-1">X</button>
              <a href="{!! route("stock_warehouse_real") !!}" class="btn btn-warning col-xs-3 col-md-1" style="margin-right: 10px;margin-left: 10px;margin-bottom: 10px;">Back</a>

                <div style="position: fixed;bottom: 5px;right:10px;background-color: white;" class="form-group">

                    <div class="col-xs-12 {{ $errors->has($template.'_barcode') ? 'has-error' : ''}}">
                        <input type="text" name="code" placeholder="PLEASE SCAN BARCODE HERE !" id="code" class="form-control">
                    </div>

                </div>

          </div>
      </div>

      {!! Form::close() !!}
  </div>

  @endsection
