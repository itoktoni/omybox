@extends('backend.'.config('website.backend').'.layouts.app')

@section('content')
<div class="row">
    {!! Form::model($data, ['route'=>[$form.'_receive', $data->$key],'class'=>'form-horizontal','files'=>true]) !!}
    <div class="panel panel-default">
        <header class="panel-heading">
            <h2 class="panel-title">Nomor PO : {{ $data->$key }}</h2>
        </header>

        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-table table-bordered table-striped table-hover mb-none">
                    <tbody>
                        <tr>
                            <th class="col-lg-2">Tanggal Order</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="spk_date" readonly="" class="form-control input-sm" value="{{ $data->spk_date }}">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th valign="middle" class="col-lg-2">Tanggal Penerimaan</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="spk_receive_date" id="datepicker" class="form-control input-sm datepicker" value="{{ $data->spk_receive_date }}">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th valign="middle" class="col-lg-2">Status Pengiriman</th>
                            <td>
                                <div class="col-md-3">
                                    {{ Form::select('spk_status', ['DELIVERED' => 'DELIVERED','RECEIVED' => 'RECEIVED'], null, ['class'=> 'form-control']) }}
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th class="col-lg-2">File Attachment</th>
                            <td>
                                <div class="col-md-3">
                                    <a class="btn btn-danger" target="_blank" href="{{ asset('public/files/po/'.$data->spk_attachment) }}">Download File</a> 
                                </div>
                                
                            </td>
                        </tr> 
                    </tbody>
                </table>
                <table class="table table-table table-bordered table-striped table-hover mb-none">
                    <header class="panel-heading">
                        <h2 class="panel-title text-right">Update Delivery</h2>
                    </header>
                    <tr>
                        <th class="col-lg-2">ID Product</th>
                        <th>Yard</th>
                        <th>Product Name</th>
                        <th class="text-right">Estimasi</th>
                        <th class="text-right">Receive</th>
                        <th class="text-right">Selisih</th>
                    </tr>
                    @php
                    $tot = 0;
                    @endphp
                    @foreach($detail as $c)
                    <tr>
                        @php
                        $tot = $tot + $c->qty_receive;
                        @endphp
                        <td class="col-lg-2">{{ $c->product_id }}</td>
                        <td>{{ $c->yard }}</td>
                        <td>{{ $c->product_name }}</td>
                        <input type="hidden" name="product[]" value="{{ $c->product_id }}">
                        <td class="text-right col-md-2">
                            <input type="text" name="delivery[]" readonly="" class="form-control text-right input-sm" value="{{ $c->qty }}">
                        </td>
                        <td class="text-right col-md-2">
                            <input type="text" name="receive[]" readonly="" class="form-control text-right input-sm" value="{{ isset($c->qty_receive) ? $c->qty_receive : 0  }}">
                        </td>
                        <td class="text-right">{{ $c->qty_receive - $c->qty }}</td>
                    </tr>
                    @endforeach
                    <tr class="well default">
                        <th class="text-right" colspan="4">Total</th>
                        <th class="text-right" colspan="5">{{ $tot }}</th>
                    </tr>
                </table>
            </div>
        </div>
        <div class="navbar-fixed-bottom" id="menu_action">
            <div class="text-right" style="padding:5px">
                <a href="{!! route("{$form}_read") !!}" class="btn btn-warning">Back</a>
                <button type="reset" class="btn btn-default">Reset</button>
                @if($data->spk_status == 'DELIVERED')
                <button type="submit" class="btn btn-primary">Save</button>
                @endif
                @if($data->spk_status == 'RECEIVED')
                 <a target="_blank" href="{!! route("{$form}_berita_acara", ["code" => $data->$key]) !!}" class="btn btn-danger">Cetak PDF
                </a>    
                @endif
            </div>
        </div>

    </div>
</div>
{!! Form::close() !!}

@endsection