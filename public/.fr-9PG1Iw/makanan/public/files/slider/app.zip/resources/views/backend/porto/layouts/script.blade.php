
<script src="{{ asset('public/assets/vendor/modernizr/modernizr.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/jquery/jquery.js') }}"></script>
<script src="{{ asset('public/assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js') }}"></script>
<script src="{{ asset('public/assets/vendor/bootstrap/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/nanoscroller/nanoscroller.js') }}"></script>
<script src="{{ asset('public/assets/vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/select/select2.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js') }}"></script>
<script src="{{ asset('public/assets/vendor/jquery-typeahead/jquery.typeahead.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/jquery-datatables/media/js/jquery.dataTables.js') }}"></script>

<script src="{{ asset('public/assets/vendor/magnific-popup/magnific-popup.js') }}"></script>
<script src="{{ asset('public/assets/vendor/pnotify/pnotify.custom.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.4/summernote.js"></script>
<script src="{{ asset('public/assets/javascripts/theme.custom.js') }}"></script>
<script src="{{ asset('public/assets/javascripts/ui-elements/examples.modals.js') }}"></script>
@yield('js')