@extends('backend.'.config('website.backend').'.layouts.app')

@section('css')
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-ui/css/jquery-ui.min.css') }}">
@endsection

@section('js')
<script src="{{ asset('public/assets/vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
@endsection

@section('javascript')

<script>

$(function () {
    $("#datepicker").datepicker({
        dateFormat: 'yy-mm-dd'
    });
});
</script>

@endsection

@section('content')

{!! Form::open(['route' => 'website', 'class' => 'form-horizontal', 'files' => true]) !!}  

<div class="row">
    <section class="panel">
        <header class="panel-heading">
            <h2 class="panel-title text-right">Configuration ( {{ config('app.name') }} )</h2>
        </header>
        <div class="panel-body">

            <div class="col-md-4 col-lg-3">
                <section class="panel">
                    <div class="">
                        <div class="text-center">
                            @if(empty(config('website.favicon')))
                            <img src="{{ asset('public/files/logo/default_logo.png') }}" class="img-thumbnail rounded center-block img-responsive">
                            @else
                            <img src="{{ asset('public/files/logo/'.config('website.favicon')) }}" class="img-thumbnail rounded center-block img-responsive">
                            @endif
                        </div>
                    </div>
                </section>

                <h5 class="text-center">Favicon :<code>W: 50px & H: 50px  </code></h5>
                <hr class="dotted short">

                <div class="col-md-12">
                    <input type="file" name="favicon" class="btn btn-default btn-sm btn-block">
                </div>
                <br>
                <br>
                <hr>
                <section class="panel">
                    <div class="">
                        <div class="text-center">
                            @if(empty(config('website.logo')))
                            <img src="{{ asset('public/files/logo/default_logo.png') }}" class="img-thumbnail rounded center-block img-responsive" alt="no profile">
                            @else
                            <img src="{{ asset('public/files/logo/'.config('website.logo')) }}" class="img-thumbnail rounded center-block img-responsive" alt="John Doe">
                            @endif
                        </div>
                    </div>
                </section>

                <h5 class="text-center">Logo <code>W: 50px-100px & H: 230px</code></h5>
                <hr class="dotted short">

                <div class="col-md-12">
                    <input type="file" name="logo" class="btn btn-default btn-sm btn-block">
                </div>

            </div>
            <div class="col-md-8 col-lg-9">

                <div class="panel-group" id="accordion">
                    <div class="panel panel-accordion">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse1One">
                                    Application
                                </a>
                            </h4>
                        </div>
                        <div id="collapse1One" class="accordion-body collapse in">
                            <div class="panel-body">
                                <div class="col-md-12"> 
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Website Name</label>
                                        <div class="col-md-4">
                                            <input type="text" name="app[name]" value="{{ config('app.name') }}" required="" class="form-control">
                                        </div>

                                        <label class="col-md-2 control-label">Environment</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="app[env]">
                                                <option {{ config('app.env') == 'local' ? 'selected=selected' : '' }} value="local">Local</option>
                                                <option {{ config('app.env') == 'production' ? 'selected=selected' : '' }} value="production">Production</option>
                                            </select>
                                        </div>

                                        <label class="col-md-2 control-label">Image Process</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="image">
                                                <option {{ config('image.driver') == 'gd' ? 'selected=selected' : '' }} value="gd">GD</option>
                                                <option {{ config('image.driver') == 'imagick' ? 'selected=selected' : '' }} value="imagick">Imagick</option>
                                            </select>
                                        </div>
                                        <label class="col-md-2 control-label">URL</label>
                                        <div class="col-md-4">
                                            <input type="text" value="{{ config('app.url') }}" name="app[url]" class="form-control">
                                        </div>


                                        <label class="col-md-2 control-label">Timezone</label>
                                        <div class="col-md-4">
                                            <input type="text" value="{{ config('app.timezone') }}" name="app[timezone]" class="form-control">
                                        </div>

                                        <label class="col-md-2 control-label">Language</label>
                                        <div class="col-md-4">
                                            <input type="text" value="{{ config('app.locale') }}" name="app[locale]" class="form-control">
                                        </div>
                                        <label class="col-md-2 control-label">Show Setting</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="image">
                                                @foreach($group as $g)
                                                <option value="{{ $g->group_user_code }}">{{ $g->group_user_name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <label class="col-md-2 control-label">Database Driver</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="cache[default]">
                                                <option {{ config('database.default') == 'sqlite' ? 'selected=selected' : '' }} value="sqlite"> Sqlite</option>
                                                <option {{ config('database.default') == 'mysql' ? 'selected=selected' : '' }} value="mysql"> MySql</option>
                                                <option {{ config('database.default') == 'pgsql' ? 'selected=selected' : '' }} value="pgsql"> PostgreSQL</option>
                                                <option {{ config('database.default') == 'sqlsrv' ? 'selected=selected' : '' }} value="sqlsrv"> Sql Server</option>
                                            </select>
                                        </div>
                                        <label class="col-md-2 control-label">Description</label>
                                        <div class="col-md-10">
                                            <textarea class="form-control" rows="3" name="description" cols="50">{{ config('website.description') }}</textarea>
                                        </div>
                                    </div>  

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel panel-accordion">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse1Five">
                                    Management Template
                                </a>
                            </h4>
                        </div>
                        <div id="collapse1Five" class="accordion-body collapse">
                            <div class="panel-body">

                                <div class="col-md-12"> 
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Backend</label>
                                        <div class="col-md-4">
                                            <input type="text" value="{{ config('website.backend') }}" name="backend" class="form-control">
                                        </div>

                                        <label class="col-md-2 control-label">Frontend</label>
                                        <div class="col-md-4">
                                            <input type="text" value="{{ config('website.frontend') }}" name="frontend" class="form-control">
                                        </div>
                                        
                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel panel-accordion">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse1Two">
                                    Debug Error
                                </a>
                            </h4>
                        </div>
                        <div id="collapse1Two" class="accordion-body collapse">
                            <div class="panel-body">

                                <div class="col-md-12"> 
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Debug</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="app[debug]">
                                                <option {{ config('app.debug') == '1' ? 'selected=selected' : '' }} value="1">Show Error</option>
                                                <option {{ config('app.debug') == '0' ? 'selected=selected' : '' }} value="0">Hidden Error</option>
                                            </select>
                                        </div>

                                        <label class="col-md-2 control-label">Debug Bar</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="debugbar">
                                                <option {{ config('debugbar.enabled') == '1' ? 'selected=selected' : '' }} value="1">Show DebugBar</option>
                                                <option {{ config('debugbar.enabled') == '0' ? 'selected=selected' : '' }} value="0">Hidden DebugBar</option>
                                            </select>
                                        </div>

                                        <label class="col-md-2 control-label">Log</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="app[log]">
                                                <option {{ config('app.log') == 'single' ? 'selected=selected' : '' }} value="single">Single</option>
                                                <option {{ config('app.log') == 'daily' ? 'selected=selected' : '' }} value="daily">Daily</option>
                                                <option {{ config('app.log') == 'syslog' ? 'selected=selected' : '' }} value="daily">Syslog</option>
                                                <option {{ config('app.log') == 'errorlog' ? 'selected=selected' : '' }} value="daily">Error Log</option>
                                            </select>
                                        </div>

                                        <label class="col-md-2 control-label">Log Level</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="app[log_level]">
                                                <option {{ config('app.log_level') == 'debug' ? 'selected=selected' : '' }} value="debug"> debug</option>
                                                <option {{ config('app.log_level') == 'info' ? 'selected=selected' : '' }} value="info"> info</option>
                                                <option {{ config('app.log_level') == 'notice' ? 'selected=selected' : '' }} value="notice"> notice</option>
                                                <option {{ config('app.log_level') == 'warning' ? 'selected=selected' : '' }} value="warning"> warning</option>
                                                <option {{ config('app.log_level') == 'error' ? 'selected=selected' : '' }} value="error"> Error </option>
                                                <option {{ config('app.log_level') == 'critical' ? 'selected=selected' : '' }} value="critical"> critical</option>
                                                <option {{ config('app.log_level') == 'alert' ? 'selected=selected' : '' }} value="alert">alert </option>
                                                <option {{ config('app.log_level') == 'emergency' ? 'selected=selected' : '' }} value="emergency"> emergency</option>
                                            </select>
                                        </div>
                                    </div> 

                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="panel panel-accordion">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#address">
                                    Cache Management
                                </a>
                            </h4>
                        </div>
                        <div id="address" class="accordion-body collapse">
                            <div class="panel-body">
                                <div class="col-md-12"> 
                                    <div class="form-group">
                                        <label class="col-md-2 control-label">Default</label>
                                        <div class="col-md-4">
                                            <select class="form-control" name="cache[default]">
                                                <option {{ config('cache.default') == 'apc' ? 'selected=selected' : '' }} value="apc"> apc</option>
                                                <option {{ config('cache.default') == 'array' ? 'selected=selected' : '' }} value="array"> array</option>
                                                <option {{ config('cache.default') == 'database' ? 'selected=selected' : '' }} value="database"> database</option>
                                                <option {{ config('cache.default') == 'file' ? 'selected=selected' : '' }} value="file"> file</option>
                                                <option {{ config('cache.default') == 'memcached' ? 'selected=selected' : '' }} value="memcached"> memcached </option>
                                                <option {{ config('cache.default') == 'redis' ? 'selected=selected' : '' }} value="redis"> redis</option>
                                            </select>
                                        </div>
                                        <label class="col-md-2 control-label">Prefix</label>
                                        <div class="col-md-4">
                                            <input type="text" value="{{ config('cache.prefix') }}" name="cache[prefix]" class="form-control">
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="panel panel-accordion">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse1Three">
                                    Remote SFTP (SSH)
                                </a>
                            </h4>
                        </div>
                        <div id="collapse1Three" class="accordion-body collapse">
                            <div class="panel-body">

                                <div class="col-md-12"> 
                                    <div class="form-group">
                                        <div class="col-md-6">
                                            <label class="col-md-12 control-label"><h5 class="text-center">Local</h5></label>
                                            @foreach(config('remote.connections.local') as $key => $value)
                                            <label class="col-md-4 control-label">{{ $key }}</label>
                                            <div class="col-md-8">
                                                <input type="text" name="local[{{ $key }}]" value="{{ $value }}" class="form-control">
                                            </div>
                                            @endforeach
                                        </div>

                                        <div class="col-md-6">
                                            <label class="col-md-12 control-label"><h5 class="text-center">Server</h5></label>
                                            @foreach(config('remote.connections.server') as $key => $value)
                                            <label class="col-md-4 control-label">{{ $key }}</label>
                                            <div class="col-md-8">
                                                <input type="text" name="server[{{ $key }}]" value="{{ $value }}" class="form-control">
                                            </div>
                                            @endforeach
                                        </div>
                                    </div> 
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="panel panel-accordion">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse1Four">
                                    Database Connections
                                </a>
                            </h4>
                        </div>
                        <div id="collapse1Four" class="accordion-body collapse">
                            <div class="panel-body">

                                <div class="col-md-12"> 
                                    <div class="form-group">
                                        @foreach($db as $key => $value)
                                        <label class="col-md-3 control-label">{{ ucfirst($key) }}</label>
                                        <div class="col-md-3">
                                            <input type="text" name="database[{{ $key }}]" value="{{ $value }}" class="form-control">
                                        </div>
                                        @endforeach
                                    </div>  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>>
        </div>
        <div class="navbar-fixed-bottom" id="menu_action">
            <div class="text-right" style="padding:5px">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </div>
    </section>
</div>

{!! Form::close() !!}
@endsection
