
<div class="form-group">
    <label class="col-md-2 control-label">Code</label>
    <div class="col-md-4 {{ $errors->has('material_id') ? 'has-error' : ''}}">
        {!! Form::text('material_id', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Name</label>
    <div class="col-md-4 {{ $errors->has('product_name') ? 'has-error' : ''}}">
        {!! Form::text('material_name', null, ['class' => 'form-control']) !!}
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label">Description</label>
    <div class="col-md-10 {{ $errors->has('material_description') ? 'has-error' : ''}}">
        {!! Form::textarea('material_description', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>
</div>