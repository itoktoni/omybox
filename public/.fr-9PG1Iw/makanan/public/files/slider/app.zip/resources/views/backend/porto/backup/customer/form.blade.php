
<div class="form-group">
    <label class="col-md-2 control-label">Product Name</label>
    <div class="col-md-4 {{ $errors->has('product_name') ? 'has-error' : ''}}">
        {!! Form::text('product_name', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Product Category</label>
    <div class="col-md-4 {{ $errors->has('product_category') ? 'has-error' : ''}}">
        {{ Form::select('product_category', ['Batik' => 'Batik', 'Kain' => 'Kain', 'Lain-lain' => 'Lain-lain'], null, ['class'=> 'form-control']) }}
    </div>
</div>

<div class="form-group">

    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
    <div class="col-md-4">
        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
    </div>

    <label class="col-md-2 control-label">Product Satuan</label>
    <div class="col-md-4 {{ $errors->has('product_unit') ? 'has-error' : ''}}">
        {{ Form::select('product_unit', ['pcs' => 'pcs', 'meter' => 'meter'], null, ['class'=> 'form-control']) }}
    </div>

</div>

<div class="form-group">
    <label class="col-md-2 control-label">Product Price</label>
    <div class="col-md-4 {{ $errors->has('product_harga_jual') ? 'has-error' : ''}} {{ $errors->has('product_harga_beli') ? 'has-error' : ''}}">
        {!! Form::number('product_harga_jual', null, ['class' => 'form-control', 'placeholder' => 'Harga Jual']) !!}
        {!! Form::number('product_harga_beli', null, ['class' => 'form-control', 'placeholder' => 'Harga Beli']) !!}
    </div>

    {!! Form::label('name', 'Product Description', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('product_description') ? 'has-error' : ''}}">
        {!! Form::textarea('product_description', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>
</div>
