
<div class="form-group">
	<label class="col-md-1 control-label">Code</label>
	<div class="col-md-2 {{ $errors->has('rack_id') ? 'has-error' : ''}}">
		{!! Form::text('rack_id', null, ['class' => 'form-control']) !!}
	</div>

	<label class="col-md-2 control-label">Warehouse</label>
	<div class="col-md-3 {{ $errors->has('warehouse_id') ? 'has-error' : ''}}">
		<select class="form-control col-md-4" id="option" name="warehouse_id">
			<option value="">Select Warehouse</option>
			@foreach($warehouse as $value)
			<option @isset($data) {{ $value->warehouse_id == $data->warehouse_id ? 'selected="selected"' : '' }} @endisset value="{{ $value->warehouse_id }}">{{ $value->warehouse_name }}</option>
			@endforeach
		</select>
	</div>

	<label class="col-md-1 control-label">Name</label>
	<div class="col-md-3 {{ $errors->has('rack_name') ? 'has-error' : ''}}">
		{!! Form::text('rack_name', null, ['class' => 'form-control']) !!}
	</div>
</div>
