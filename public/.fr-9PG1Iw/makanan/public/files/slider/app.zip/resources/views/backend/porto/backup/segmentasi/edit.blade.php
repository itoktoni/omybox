@extends('backend.'.config('website.backend').'.layouts.app')

@section('content')
<div class="row">
    {!! Form::model($segmentasi, [
    'method' => 'PATCH',
    'url' => ['/segmentasi', $segmentasi->segmentasi_id],
    'class' => 'form-horizontal',
    'files' => true
    ]) !!}
    <div class="panel panel-default">
        <header class="panel-heading">
            <div class="btn-group pull-right">
                {!! Form::reset(isset($submitButtonText) ? $submitButtonText : 'Reset', ['class' => 'btn btn-default']) !!}
                {!! Form::submit(isset($submitButtonText) ? $submitButtonText : 'Save', ['class' => 'btn btn-primary pull-right']) !!}
            </div>
            <h2 class="panel-title">Edit Segmentasi {{ $segmentasi->segmentasi_id }}</h2>
        </header>
        <div class="panel-body">

            @if ($errors->any())
            <ul class="alert alert-danger">
                @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
                @endforeach
            </ul>
            @endif

            <div class="col-md-12 col-lg-12">
                @include ('segmentasi.form', ['submitButtonText' => 'Update'])
            </div>

        </div>

    </div>
    {!! Form::close() !!}
</div>
@endsection