<div class="form-group">
    <label class="col-md-2 control-label">Penjahit Name</label>
    <div class="col-md-4 {{ $errors->has('production_name') ? 'has-error' : ''}}">
        {!! Form::text('production_name', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Contact Person</label>
    <div class="col-md-4 {{ $errors->has('production_contact') ? 'has-error' : ''}}">
        <select class="form-control col-md-4 option" name="production_contact">
            <option value="">Select User</option>
            @foreach($user as $value)
            <option @isset($data) {{ $value->email == $data->production_contact ? 'selected="selected"' : '' }} @endisset value="{{ $value->email }}">{{ $value->name }}</option>
            @endforeach
        </select>
    </div>
</div>

<div class="form-group">

    <label class="col-md-2 control-label">Penjahit Telp</label>
    <div class="col-md-4 {{ $errors->has('production_telp') ? 'has-error' : ''}}">
        {!! Form::text('production_telp', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
    <div class="col-md-4">
        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
    </div>
</div>

<div class="form-group">

    {!! Form::label('name', 'Penjahit Alamat', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_alamat') ? 'has-error' : ''}}">
        {!! Form::textarea('production_alamat', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>

    {!! Form::label('name', 'Penjahit Description', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_description') ? 'has-error' : ''}}">
        {!! Form::textarea('production_description', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>
</div>

<div class="form-group">
   
    {!! Form::label('name', 'Production Bank', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_bank_name') ? 'has-error' : ''}}">
        {!! Form::textarea('production_bank_name', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>

    {!! Form::label('name', 'Bank KCP', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_bank_place') ? 'has-error' : ''}}">
        {!! Form::textarea('production_bank_place', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>

</div>

<div class="form-group">
   
    {!! Form::label('name', 'Bank Account', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_bank_account') ? 'has-error' : ''}}">
        {!! Form::textarea('production_bank_account', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>

    {!! Form::label('name', 'Bank Person', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_bank_person') ? 'has-error' : ''}}">
        {!! Form::textarea('production_bank_person', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>
</div>

<div class="form-group">

    {!! Form::label('name', 'Nama Owner', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_owner') ? 'has-error' : ''}}">
        {!! Form::text('production_owner', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>

    {!! Form::label('name', 'Email', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('email') ? 'has-error' : ''}}">
        {!! Form::text('email', null, ['class' => 'form-control']) !!}
    </div>

</div>