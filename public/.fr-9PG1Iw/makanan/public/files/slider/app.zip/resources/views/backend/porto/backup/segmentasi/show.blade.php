@extends('backend.'.config('website.backend').'.layouts.app')

@section('content')
<div class="row">
    <div class="panel panel-default">
         <header class="panel-heading">
            <div class="pull-right">
                <a href="{{ url('segmentasi/' . $segmentasi->segmentasi_id . '/edit') }}" class="btn btn-primary" title="Edit Post">
                    Edit
                </a>
            </div>
            <h2 class="panel-title">Segmentasi {{ $segmentasi->segmentasi_id }}</h2>
        </header>
        
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-table table-bordered table-striped table-hover mb-none">
                    <tbody>
                        <tr>
                            <th class="col-lg-2">ID</th><td>{{ $segmentasi->segmentasi_id }}</td>
                        </tr>
                        <tr><th> Segmentasi Name </th><td> {{ $segmentasi->segmentasi_name }} </td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@endsection