<div class="form-group {{ $errors->has('top_name') ? 'has-error' : ''}}">
    {!! Form::label('top_name', 'Top Name', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-8">
        {!! Form::text('top_name', null, ['class' => 'form-control']) !!}
        {!! $errors->first('top_name', '<p class="help-block">:message</p>') !!}
    </div>
</div>
