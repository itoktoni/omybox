@extends('backend.'.config('website.backend').'.layouts.app')

@section('css')
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-ui/css/jquery-ui.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/select/select2.css') }}">
@endsection

@section('js')
<script src="{{ asset('public/assets/vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/select/select2.min.js') }}"></script>
@endsection

@section('javascript')

<script>

$(function() {
    $("#datepicker").datepicker({
        dateFormat: 'yy-mm-dd'
    });

    $('#production').select2({
        placeholder: 'Select Production',
        ajax: {
            url: '{{ route("production") }}',
            dataType: 'json',
            data: function(params) {
                return {
                    q: params.term, // search term
                };
            },
            processResults: function(data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });
    
    $('#produk').select2({
        placeholder: 'Select an item',
        ajax: {
            url: '{{ route("bahan") }}',
            dataType: 'json',
            data: function(params) {
                return {
                    q: params.term, // search term
                };
            },
            processResults: function(data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });

    $(document).on('click', '#d', function() {
        var id = $("#d").val();
        $('button[value="' + id + '"]').parents("tr").remove();
    });

    $('#produk').change(function() {
        var id = $("#produk option:selected").val();
        var split = id.split("#");
        var product_id = split[0];
        var product_price = split[1];

        if (product_price == '') {

            new PNotify({
                title: 'Information Price !',
                text: 'Please Check Your Price Bahan !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }
        else {

            $('input[name=harga]').val(product_price);
            $('input[name=harga]').attr("placeholder", product_price).blur();
            $('input[name="qty"]').val("");

            document.getElementById("qty").focus();
        }
    });

    $("#tambah").click(function() {

        var input_qty = $('input[name=qty]').val();
        var input_harga = $('input[name="harga"]').val();

        if (input_qty && input_harga) {

            var name = $('select[name="produk"] option:selected').text();
            var hidden_qty = $('input[name=qty]').val();
            var hidden_harga = $('input[name=harga]').val();
            var produk = $('select[name="produk"] option:selected').val();

            var split = produk.split("#");
            var product_id = split[0];
            var product_price = split[1];

            if (name) {

                    var ep = document.getElementsByName('produks[]');
                    for (i = 0; i < ep.length; i++) {
                        if (ep[i].value.trim() == product_id.trim()) {

                            new PNotify({
                                title: 'Product Already Exist',
                                text: 'Product ' + name.trim() + ' , Already in Table ',
                                addclass: 'notification-danger',
                                icon: 'fa fa-bolt'
                            });

                            return;
                        }
                    }

                    var markup = "<tr><td data-title='ID Product'>" + product_id + "</td><td data-title='Product'>" + name + "</td><td data-title='Price' class='text-right col-lg-1'>" + input_harga + "</td><td data-title='Stock' class='text-right col-lg-1'>" + input_qty + "</td><td data-title='Action'><button id='d' value='" + product_id + "' type='button' class='btn btn-danger btn-xs btn-block'>Delete</button></td><input type='hidden' value=" + product_id + " name='produks[]'><input type='hidden' value=" + input_qty + " name='quantity[]'><input type='hidden' value=" + input_harga + " name='price[]'><input type='hidden' value=" + hidden_harga + " name='s_price[]'></tr>";
                    $("table tbody").append(markup);

                    name = null;
                    hidden_qty = null;
                    hidden_harga = null;
                    produk = null;
                    input_harga = null;

                    $('input[name="hidden_harga"]').val("");
                    $('input[name="hidden_product"]').val("");
                    $('input[name="harga"]').val("");
            }
            else {

                new PNotify({
                    title: 'Choose Product',
                    text: 'Please Select Product !',
                    addclass: 'notification-danger',
                    icon: 'fa fa-bolt'
                });
            }


        }
        else {
            new PNotify({
                title: 'Price and Quantity',
                text: 'Please Input Price & Quantity !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }

    });

    // Find and remove selected table rows
    $(".delete-row").click(function() {
        $("table tbody").find('input[name="record"]').each(function() {
            if ($(this).is(":checked")) {
                $(this).parents("tr").remove();
            }
        });
    });
});
</script>

@endsection


@section('content')

<div class="row">
    {!! Form::open(['route' => $form.'_create', 'class' => 'form-horizontal', 'files' => true]) !!}  
    <div class="panel panel-default" style="margin-bottom: 300px;">
        <header class="panel-heading">
            <h2 class="panel-title">SPK Penjahit</h2>
        </header>

        <div class="panel-body">
            <div class="col-md-12 col-lg-12">
                <div class="form-group">
                    <label class="col-md-2 control-label" for="inputDefault">No Reff</label>
                    <div class="col-md-4">
                        {!! Form::text('spk_reff', null, ['class' => 'form-control']) !!}
                    </div>

                    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
                    <div class="col-md-4">
                        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2 control-label" for="inputDefault">Delivery Date</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            {!! Form::text('spk_delivery_date', null, ['class' => 'form-control', 'id' => 'datepicker']) !!}
                            <span class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </span>
                        </div>
                    </div>
                    <label class="col-md-2 control-label" for="inputDefault">Production</label>
                    <div class="col-md-4">
                        <select id="production" name="production_id" class="form-control">
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2 control-label" for="textareaDefault">Notes</label>
                    <div class="col-md-4">
                        {!! Form::textarea('spk_note', null, ['class' => 'form-control', 'rows' => '3']) !!}
                    </div>

                    <label class="col-md-2 control-label" for="inputDefault">Warehouse</label>
                    <div class="col-md-4">
                        <select name="warehouse_id" class="form-control mb-md">
                            @foreach($warehouse as $value)
                            <option value="{{ $value->warehouse_id }}">{{ $value->warehouse_name }}</option>
                            @endforeach
                        </select>
                    </div>    

                </div>

                <br>
                <a id="tambah" style="margin-top: -20px;margin-bottom: 10px; " class="btn btn-success pull-right">Add Order Detail</a>
                <hr>

                <div class="form-group">

                    <label class="col-md-2 control-label" for="inputDefault">Product</label>
                    <div class="col-md-6" style="margin-bottom: 10px;" >

                        <input type="hidden" name="hidden_product">
                        <input type="hidden" name="hidden_harga">
                        
                        <select id="produk" name="produk" class="form-control">
                        </select>
                    </div>

                    <div class="col-md-2">
                        <div class="input-group mb-md">
                            <span class="input-group-addon ">Rp</span>
                            <input class="form-control" name="harga" type="text">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="input-group mb-md">
                            <span class="input-group-addon ">Yard</span>
                            <input class="form-control" id="qty" name="qty" type="text">
                        </div>
                    </div>

                </div>

                <table class="table table-no-more table-bordered table-striped mb-none">
                    <thead>
                        <tr>
                            <th class="text-left col-lg-1">ID Ax</th>
                            <th class="text-left">Product Name</th>
                            <th class="text-right col-lg-1">Price</th>
                            <th class="text-right col-lg-1">QTY</th>
                            <th class="text-center col-lg-1">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>

            </div>
        </div>
        
        <div class="navbar-fixed-bottom" id="menu_action">
            <div class="text-right" style="padding:5px">
                <a href="{!! route("{$form}_read") !!}" class="btn btn-warning">Back</a>
                <button type="reset" class="btn btn-default">Reset</button>
                @isset($create)
                <button type="submit" class="btn btn-primary">Save</button>
                @endisset
            </div>
        </div>

        {!! Form::close() !!}
    </div>

    @endsection


