    <h3>Hi Account Email {{ $email }} </h3> 
    <p>Your Password Has Been Update With <code> {{ $text }} </code></p>