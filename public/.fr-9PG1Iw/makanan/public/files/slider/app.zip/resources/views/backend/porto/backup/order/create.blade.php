@extends('backend.'.config('website.backend').'.layouts.app')

@section('css')
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-ui/css/jquery-ui.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/select/select2.css') }}">
@endsection

@section('js')
<script src="{{ asset('public/assets/vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/select/select2.min.js') }}"></script>
@endsection

@section('javascript')

<script>

$(function() {
    $("#datepicker").datepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function(datetext) {
            var d = new Date(); // for now
            datetext = datetext + " " + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
            $('#datepicker').val(datetext);
        },
    });

    $('#customer').select2({
        placeholder: 'Select an item',
        minimumInputLength: 3,
        ajax: {
            url: '{{ route("customer") }}',
            dataType: 'json',
            data: function(params) {
                return {
                    q: params.term, // search term
                };
            },
            processResults: function(data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });

    $('#produk').select2({
        placeholder: 'Select an item',
        minimumInputLength: 3,
        ajax: {
            url: '{{ route("produk") }}',
            dataType: 'json',
            data: function(params) {
                return {
                    q: params.term, // search term
                    top: $('input[name=term_of_payment_id]').val(), // search term
                    segment: $('input[name=segmentasi_id]').val(), // search term
                    site: $('select[name=site_id').val(), // search term
                };
            },
            processResults: function(data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });

    $('#produk').change(function() {

        var customer = $('input[name=customer_id]').val();
        var top = $('input[name=term_of_payment_id]').val();
        var segment = $('input[name=segmentasi_id]').val();

        if (customer == '') {

            new PNotify({
                title: 'Information Produk !',
                text: 'Please Check Your Product !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }
        else if (top == '') {

            new PNotify({
                title: 'TOP is Empty !',
                text: 'Check TOP in Data Master !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }
        else if (segment == '') {

            new PNotify({
                title: 'Segmentation is Empty !',
                text: 'Check Segment in Data Master !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }
        else {

            var id = $("#produk option:selected").val();
            var split = id.split("#");
            var produk = split[0];
            var harga = split[1];
            var qty = split[2];

            $('input[name=hidden_product]').val(produk);
            $('input[name=hidden_harga]').val(harga);
            $('input[name=hidden_qty]').val(qty);

//            $("input[name=harga]").attr("value", harga).blur();
            $('input[name=harga]').val(harga);
            $("input[name=qty]").attr("placeholder", qty).blur();
            $("input[name=harga]").focus();
        }
    });

    $('#address').change(function() {
        var id = $("#address option:selected").val();
        var split = id.split("#");
        var recid = split[0];
        var alamat = split[1];
        
        $('input[name=address_recid]').val(recid);
        $('input[name=alamat]').val(alamat);
    });

    $('#customer').change(function() {
        var id = $("#customer option:selected").val();
        var split = id.split("#");
        var customer = split[0];
        var segment = split[1];
        var top = split[2];

        if (customer == '') {

            new PNotify({
                title: 'Information Customer !',
                text: 'Please Check Your Customer !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }
        else if (segment == '') {

            new PNotify({
                title: 'Segmentation is Empty !',
                text: 'Check Segment in Data Master !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }
        else if (top == '') {

            new PNotify({
                title: 'TOP is Empty !',
                text: 'Check TOP in Data Master !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }
        else {

            $('input[name=harga]').val('');
            $('input[name=qty]').val('');
            $("input[name=qty]").attr("placeholder", '').blur();
            $("input[name=harga]").attr("placeholder", '').blur();

            $('input[name=term_of_payment_id]').val(top);
            $('input[name=segmentasi_id]').val(segment);
            $('input[name=customer_id]').val(customer);

            $('#address').select2({
                ajax: {
                    url: '{{ route("address") }}',
                    dataType: 'json',
                    data: function(params) {
                        return {
                            id_customer: customer
                        };
                    },
                    processResults: function(data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }
            });
        }

    });

    $(document).on('click', '#d', function() {
        var id = $("#d").val();
        $('button[value="' + id + '"]').parents("tr").remove();
    });

    $("#tambah").click(function() {

        var input_qty = $('input[name=qty]').val();
        var input_harga = $('input[name="harga"]').val();

        if (input_qty && input_harga) {

            var name = $('select[name="produk"] option:selected').text();
            var hidden_qty = $('input[name=hidden_qty]').val();
            var hidden_harga = $('input[name=hidden_harga]').val();
            var produk = $('input[name="hidden_product"]').val();

            if (hidden_qty) {

                if (parseFloat(hidden_qty) < parseFloat(input_qty)) {

                    new PNotify({
                        title: 'Stock not Available',
                        text: 'Stock only ' + hidden_qty + ' , You Input ' + input_qty,
                        addclass: 'notification-danger',
                        icon: 'fa fa-bolt'
                    });
                }
                else {

                    var ep = document.getElementsByName('produks[]');
                    for (i = 0; i < ep.length; i++) {
                        if (ep[i].value.trim() == produk.trim()) {

                            new PNotify({
                                title: 'Product Already Exist',
                                text: 'Product ' + name.trim() + ' , Already in Table ',
                                addclass: 'notification-danger',
                                icon: 'fa fa-bolt'
                            });

                            return;
                        }
                    }

                    var markup = "<tr><td data-title='ID Product'>" + produk + "</td><td data-title='Product'>" + name + "</td><td data-title='Price' class='text-right col-lg-1'>" + input_harga + "</td><td data-title='Stock' class='text-right col-lg-1'>" + input_qty + "</td><td data-title='Action'><button id='d' value='" + produk + "' type='button' class='btn btn-danger btn-xs btn-block'>Delete</button></td><input type='hidden' value=" + produk + " name='produks[]'><input type='hidden' value=" + input_qty + " name='quantity[]'><input type='hidden' value=" + input_harga + " name='price[]'><input type='hidden' value=" + hidden_harga + " name='s_price[]'></tr>";
                    $("table tbody").append(markup);

                    name = null;
                    hidden_qty = null;
                    hidden_harga = null;
                    produk = null;
                    input_qty = null;
                    input_harga = null;

                    $('input[name="hidden_qty"]').val("");
                    $('input[name="hidden_harga"]').val("");
                    $('input[name="hidden_product"]').val("");
                    $('input[name="qty"]').val("");
                    $('input[name="harga"]').val("");
                }
            }
            else {

                new PNotify({
                    title: 'Choose Product',
                    text: 'Please Select Product !',
                    addclass: 'notification-danger',
                    icon: 'fa fa-bolt'
                });
            }


        }
        else {
            new PNotify({
                title: 'Price and Quantity',
                text: 'Please Input Price & Quantity !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });
        }

    });

    // Find and remove selected table rows
    $(".delete-row").click(function() {
        $("table tbody").find('input[name="record"]').each(function() {
            if ($(this).is(":checked")) {
                $(this).parents("tr").remove();
            }
        });
    });
});
</script>

@endsection


@section('content')

<div class="row">
    {!! Form::open(['route' => 'order_create', 'class' => 'form-horizontal', 'files' => true]) !!}  
    <div class="panel panel-default" style="margin-bottom: 300px;">
        <header class="panel-heading">
            <div class="btn-group pull-right">
                <button type="reset" class="btn btn-default">Reset</button>
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
            <h2 class="panel-title">Create Orders</h2>
        </header>

        <div class="panel-body">
            <div class="col-md-12 col-lg-12">
                <div class="form-group">
                    <label class="col-md-2 control-label" for="inputDefault">No Reff</label>
                    <div class="col-md-4">
                        {!! Form::text('order_reff', null, ['class' => 'form-control']) !!}
                    </div>

                    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
                    <div class="col-md-4">
                        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2 control-label" for="inputDefault">Delivery Date</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            {!! Form::text('order_delivery_date', null, ['class' => 'form-control', 'id' => 'datepicker']) !!}
                            <span class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </span>
                        </div>
                    </div>
                    <label class="col-md-2 control-label" for="inputDefault">Customer</label>
                    <div class="col-md-4">
                        <input type="hidden" name="term_of_payment_id">
                        <input type="hidden" name="customer_id">
                        <input type="hidden" name="segmentasi_id">
                        <select id="customer" class="form-control">
                        </select>
                    </div>
                </div>

                <div class="form-group">


                    <label class="col-md-2 control-label">Pengiriman</label>
                    <div class="col-md-4">
                        {{ Form::select('order_type_delivery', ['Dikirim' => 'Dikirim', 'Diambil' => 'Diambil'], null, ['class'=> 'form-control']) }}
                    </div>


                    <label class="col-md-2 control-label" for="inputDefault">Site</label>
                    <div class="col-md-4">
                        <select name="site_id" class="form-control mb-md">
                            @foreach($site as $s)
                            <option value="{{ $s->site_id }}">{{ $s->site_name }}</option>
                            @endforeach
                        </select>
                    </div>       
                </div>


                <div class="form-group">

                    <label class="col-md-2 control-label" for="textareaDefault">Notes</label>
                    <div class="col-md-4">
                        {!! Form::textarea('order_note', null, ['class' => 'form-control', 'rows' => '3']) !!}
                    </div>

                    <label class="col-md-2 control-label" for="inputDefault">Address</label>
                    <div class="col-md-4">
                        <select id="address" name="address" class="form-control mb-md">
                        </select>
                        <input type='hidden' name='address_recid'>
                        <input type='hidden' name='alamat'>
                    </div>

                </div>

                <br>
                <a id="tambah" style="margin-top: -20px;margin-bottom: 10px; " class="btn btn-success pull-right">Add Order Detail</a>
                <hr>

                <div class="form-group">

                    <label class="col-md-2 control-label" for="inputDefault">Product</label>
                    <div class="col-md-6" style="margin-bottom: 10px;" >
                        <input type="hidden" name="hidden_product">
                        <input type="hidden" name="hidden_harga">
                        <input type="hidden" name="hidden_qty">
                        <select id="produk" name="produk" class="form-control">
                        </select>
                    </div>

                    <div class="col-md-2">
                        <div class="input-group mb-md">
                            <span class="input-group-addon ">Rp</span>
                            <input class="form-control" name="harga" type="text">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="input-group mb-md">
                            <span class="input-group-addon ">Kg</span>
                            <input class="form-control" name="qty" type="text">
                        </div>
                    </div>

                </div>

                <table class="table table-no-more table-bordered table-striped mb-none">
                    <thead>
                        <tr>
                            <th class="text-left col-lg-1">ID Ax</th>
                            <th class="text-left">Product Name</th>
                            <th class="text-right col-lg-1">Price</th>
                            <th class="text-right col-lg-1">QTY</th>
                            <th class="text-center col-lg-1">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>

            </div>
        </div>

        {!! Form::close() !!}
    </div>

    @endsection


