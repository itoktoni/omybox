

@section('css')
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-ui/css/jquery-ui.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/select/select2.css') }}">
@endsection

@section('js')
<script src="{{ asset('public/assets/vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/select/select2.min.js') }}"></script>
@endsection

@section('javascript')

<script>

	$(function () {

		$('#product').select2({
			placeholder: 'Select an Unit',
			ajax: {
				url: '{{ route("product_detail") }}',
				dataType: 'json',
				data: function (params) {
					return {
                    q: params.term, // search term
                };
            },
	            processResults: function (data) {
	            	return {
	            		results: data
	            	};
	            },
	            cache: true
	        }
	    });
	});
</script>

@endsection

<div class="form-group">
	<label class="col-md-2 control-label">Product</label>
	<div class="col-md-4 {{ $errors->has('product_code') ? 'has-error' : ''}}">
		<select class="form-control col-md-4" id="product" name="product_code">
			<option value="">Select an Product</option>
			@foreach($product as $s)
			@isset($data)
			@if($s->product_detail_id == $data->product_code)
			<option selected="selected" value="{{$s->product_detail_id}}">{{ $s->product_detail_name }}</option>
			@endif
			@endisset
			@endforeach
		</select>
	</div>

	<label class="col-md-2 control-label">Value From</label>
	<div class="col-md-4 {{ $errors->has('product_value') ? 'has-error' : ''}}">
		{!! Form::text('product_value', null, ['class' => 'form-control']) !!}
	</div>
</div>
