
@section('css')
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-ui/css/jquery-ui.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/select/select2.css') }}">
@endsection

@section('js')
<script src="{{ asset('public/assets/vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/select/select2.min.js') }}"></script>
@endsection

@section('javascript')

<script>

    $(function () {

        $('#unit').select2({
            placeholder: 'Select an Unit',
            ajax: {
                url: '{{ route("unit") }}',
                dataType: 'json',
                data: function (params) {
                    return {
                    q: params.term, // search term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });

        $('#category').select2({
            placeholder: 'Select an Category',
            ajax: {
                url: '{{ route("category") }}',
                dataType: 'json',
                data: function (params) {
                    return {
                    q: params.term, // search term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });


    });
</script>

@endsection

<div class="form-group">
    <label class="col-md-2 control-label">Product Name</label>
    <div class="col-md-4 {{ $errors->has('product_name') ? 'has-error' : ''}}">
        {!! Form::text('product_name', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Product Category</label>
    <div class="col-md-4 {{ $errors->has('product_category') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="category" name="product_category">
            <option value="">Select an Category</option>
            @foreach($category as $s)
            @isset($data)
            <option {{ $s->category_id == $data->product_category ? 'selected="selected"' : '' }} value="{{ $s->category_id }}">{{ $s->category_name }}</option>
            @endisset
            @endforeach
        </select>
    </div>
</div>

<div class="form-group">

    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
    <div class="col-md-4">
        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
    </div>

    <label class="col-md-2 control-label">Product Unit</label>
    <div class="col-md-4 {{ $errors->has('product_unit') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="unit" name="product_unit">
            <option value="">Select an Unit</option>
            @foreach($unit as $s)
            @isset($data)
            @if($s->unit_id == $data->product_unit)
            <option selected="selected" value="{{$s->unit_id}}">{{ $s->unit_name }}</option>
            @endif
            @endisset
            @endforeach
        </select>
    </div>

</div>

<div class="form-group">
    <label class="col-md-2 control-label">Product Price</label>
    <div class="col-md-4 {{ $errors->has('product_harga_jual') ? 'has-error' : ''}} {{ $errors->has('product_harga_beli') ? 'has-error' : ''}}">
        {!! Form::number('product_harga_beli', null, ['class' => 'form-control', 'placeholder' => 'Harga Beli']) !!}
        {!! Form::number('product_harga_jual', null, ['class' => 'form-control', 'placeholder' => 'Harga Jual']) !!}
    </div>

    {!! Form::label('name', 'Product Description', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('product_description') ? 'has-error' : ''}}">
        {!! Form::textarea('product_description', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>
</div>
