
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<meta name="csrf-token" value="{{ csrf_token() }}">
<title>{{ config('app.name') }}</title>
<link href="{{ asset('public/files/logo') }}/favicon.ico" rel="icon">
<meta name="keywords" content="{{ config('app.name') }}" />
<meta name="description" content="{{ config('app.name') }}">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<link rel="stylesheet" href="{{ url('/public/assets/') }}/vendor/bootstrap/css/bootstrap.min.css"/>
<link rel="stylesheet" href="{{ asset('public/assets/vendor/font-awesome/css/font-awesome.min.css') }}"/>
<link rel="stylesheet" href="{{ asset('public/assets/vendor/pnotify/pnotify.custom.css') }}" />
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-ui/css/jquery-ui.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/select/select2.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/magnific-popup/magnific-popup.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-typeahead/jquery.typeahead.min.css') }}" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

<link rel="stylesheet" href="{{ asset('public/assets/stylesheets/theme.min.css') }}"/>
<link rel="stylesheet" href="{{ asset('public/assets/stylesheets/skins/default.min.css') }}"/>
<link rel="stylesheet" href="{{ asset('public/assets/stylesheets/theme-custom.css') }}">
@yield('css')

