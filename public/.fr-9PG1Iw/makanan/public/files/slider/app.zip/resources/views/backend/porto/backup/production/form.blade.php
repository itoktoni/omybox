
@section('css')
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-ui/css/jquery-ui.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/select/select2.css') }}">
@endsection

@section('js')
<script src="{{ asset('public/assets/vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/select/select2.min.js') }}"></script>
@endsection

@section('javascript')

<script>

$(function () {
    $('#email').select2({
        placeholder: 'Select an User',
    });
});
</script>

@endsection

<div class="form-group">
    <label class="col-md-2 control-label">Penjahit Name</label>
    <div class="col-md-4 {{ $errors->has('production_name') ? 'has-error' : ''}}">
        {!! Form::text('production_name', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Contact Person</label>
    <div class="col-md-4 {{ $errors->has('email') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="email" name="email">
            <option value="">Select An User</option>
            @foreach($user as $s)
            @isset($data)
            @if($s->email == $data->email)
            <option selected="selected" value="{{$s->email}}">{{ $s->name }}</option>
            @endif
            @endisset
            <option value="{{ $s->email }}">{{ $s->name }}</option>
            @endforeach
        </select>
    </div>
</div>

<div class="form-group">

    <label class="col-md-2 control-label">Penjahit Telp</label>
    <div class="col-md-4 {{ $errors->has('production_telp') ? 'has-error' : ''}}">
        {!! Form::text('production_telp', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
    <div class="col-md-4">
        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
    </div>
</div>

<div class="form-group">

    {!! Form::label('name', 'Penjahit Alamat', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_alamat') ? 'has-error' : ''}}">
        {!! Form::textarea('production_alamat', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>

    {!! Form::label('name', 'Penjahit Description', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('production_description') ? 'has-error' : ''}}">
        {!! Form::textarea('production_description', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>
</div>
