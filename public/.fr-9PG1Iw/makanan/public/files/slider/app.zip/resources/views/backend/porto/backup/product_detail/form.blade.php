
@section('css')
<link rel="stylesheet" href="{{ asset('public/assets/vendor/jquery-ui/css/jquery-ui.min.css') }}">
<link rel="stylesheet" href="{{ asset('public/assets/vendor/select/select2.css') }}">
@endsection

@section('js')
<script src="{{ asset('public/assets/vendor/jquery-ui/js/jquery-ui.min.js') }}"></script>
<script src="{{ asset('public/assets/vendor/select/select2.min.js') }}"></script>
@endsection

@section('javascript')

<script>

    $(function () {

        $('#batik').select2({
            placeholder: 'Select an batik',
            ajax: {
                url: '{{ route("batik") }}',
                dataType: 'json',
                data: function (params) {
                    return {
                    q: params.term, // search term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });

        $('#size').select2({
            placeholder: 'Select an size',
            ajax: {
                url: '{{ route("size") }}',
                dataType: 'json',
                data: function (params) {
                    return {
                    q: params.term, // search term
                };
            },
            processResults: function (data) {
                return {
                    results: data
                };
            },
            cache: true
        }
    });


    });
</script>

@endsection

<div class="form-group">
    <label class="col-md-2 control-label">Product Code</label>
    <div class="col-md-4 {{ $errors->has('product_detail_id') ? 'has-error' : ''}}">
        {!! Form::text('product_detail_id', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Product Master</label>
    <div class="col-md-4 {{ $errors->has('product_detail_master') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="batik" name="product_detail_master">
            <option value="">Select a Master</option>
            @foreach($product as $p)
            @isset($data)
            <option {{ $p->product_id == $data->product_detail_master ? 'selected="selected"' : '' }} value="{{ $p->product_id }}">{{ $p->product_name }}</option>
            @endisset
            @endforeach
        </select>
    </div>
</div>

<div class="form-group">

    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
    <div class="col-md-4">
        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
    </div>

    <label class="col-md-2 control-label">Product Unit</label>
    <div class="col-md-4 {{ $errors->has('product_detail_unit') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="size" name="product_detail_size">
            <option value="">Select an Size</option>
            @foreach($size as $s)
            @isset($data)
            @if($s->size_id == $data->product_detail_size)
            <option selected="selected" value="{{ $s->size_id }}">{{ $s->size_id }}</option>
            @endif
            @endisset
            @endforeach
        </select>
    </div>

</div>

<div class="form-group">
    <label class="col-md-2 control-label">Product Price</label>
    <div class="col-md-4 {{ $errors->has('product_detail_harga_jual') ? 'has-error' : ''}} {{ $errors->has('product_detail_harga_beli') ? 'has-error' : ''}}">
        {!! Form::number('product_detail_harga_jual', null, ['class' => 'form-control', 'placeholder' => 'Harga Jual']) !!}
        {!! Form::number('product_detail_harga_beli', null, ['class' => 'form-control', 'placeholder' => 'Harga Beli']) !!}
    </div>

    {!! Form::label('name', 'Product Description', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('product_detail_description') ? 'has-error' : ''}}">
        {!! Form::textarea('product_detail_description', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>
</div>
