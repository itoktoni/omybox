<div class="form-group {{ $errors->has('segmentasi_name') ? 'has-error' : ''}}">
    {!! Form::label('segmentasi_name', 'Segmentasi Name', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-8">
        {!! Form::text('segmentasi_name', null, ['class' => 'form-control']) !!}
        {!! $errors->first('segmentasi_name', '<p class="help-block">:message</p>') !!}
    </div>
</div>
