@extends('backend.'.config('website.backend').'.layouts.app')

@section('content')
<div class="row">
    {!! Form::model($data, ['route'=>[$form.'_update', $data->$key],'class'=>'form-horizontal','files'=>true]) !!}
    <div class="panel panel-default">
        <header class="panel-heading">
            <div class="btn-group pull-right">
                <a href="{!! route("{$template}_read") !!}" class="btn btn-warning">Back</a>
                <button type="reset" class="btn btn-default">Reset</button>
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
            <h2 class="panel-title">Edit {{ ucfirst(camel_case($template)) }}</h2>
        </header>
        <div class="panel-body">

            <div class="col-md-12 col-lg-12">
                @include('backend.'.config('website.backend').'/'.$template.'/'.'form')
            </div>

        </div>

    </div>
    {!! Form::close() !!}
</div>
@endsection