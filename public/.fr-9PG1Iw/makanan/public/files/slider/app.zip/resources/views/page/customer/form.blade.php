@section('javascript')
<script>
    $(function () {

        $('#province').change(function() {
            var id = $("#province option:selected").val();

            $('#city').select2({
                placeholder: 'Select an City',
                ajax: {
                    url: '{{ route("city") }}',
                    dataType: 'json',
                    data: function (params) {
                        return {
                        q: params.term, // search term
                        province: id,
                    };
                },
                    processResults: function (data) {
                        return {
                            results: data
                        };
                    },
                    cache: true
                }   
            });
        });
    });
</script>
@endsection

<div class="form-group">
    <label class="col-md-2 control-label">Customer Name</label>
    <div class="col-md-4 {{ $errors->has('customer_name') ? 'has-error' : ''}}">
        {!! Form::text('customer_name', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Contact Person</label>
    <div class="col-md-4 {{ $errors->has('customer_contact') ? 'has-error' : ''}} {{ $errors->has('customer_stock') ? 'has-error' : ''}}">
        {!! Form::text('customer_contact', null, ['class' => 'form-control']) !!}
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label">Customer Phone</label>
    <div class="col-md-4 {{ $errors->has('customer_phone') ? 'has-error' : ''}}">
        {!! Form::text('customer_phone', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Customer Email</label>
    <div class="col-md-4 {{ $errors->has('customer_email') ? 'has-error' : ''}}">
        {!! Form::text('customer_email', null, ['class' => 'form-control']) !!}
    </div>
</div>

<hr>

<div class="form-group">
    <label class="col-md-2 control-label">Site</label>
    <div class="col-md-4 {{ $errors->has('customer_category') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="site" name="site_id">
            <option value="">Select Site</option>
            @foreach($site as $value)
            <option @isset($data) {{ $value->site_id == $data->site_id ? 'selected="selected"' : '' }} @endisset value="{{ $value->site_id }}">{{ $value->site_name }}</option>
            @endforeach
        </select>
    </div>

    <label class="col-md-2 control-label">User</label>
    <div class="col-md-4 {{ $errors->has('email') ? 'has-error' : ''}}">
        <select class="form-control col-md-4 option" id="email" name="email">
            <option value="">Select User</option>
            @foreach($user as $value)
            <option @isset($data) {{ $value->email == $data->email ? 'selected="selected"' : '' }} @endisset value="{{ $value->email }}">{{ $value->name }}</option>
            @endforeach
        </select>
    </div>
</div>

<hr>

<div class="form-group">
    <label class="col-md-2 control-label">Province</label>
    <div class="col-md-4 {{ $errors->has('province_id') ? 'has-error' : ''}}">
        <select class="form-control col-md-4 option5" id="province" name="province_id">
            <option value="">Select Province</option>
            @foreach($province as $value)
            <option @isset($data) {{ $value['province_id'] == $data->province_id ? 'selected="selected"' : '' }} @endisset value="{{ $value['province_id'] }}">{{ $value['province'] }}</option>
            @endforeach
        </select>
    </div>

    <label class="col-md-2 control-label">City</label>
    <div class="col-md-4 {{ $errors->has('city_id') ? 'has-error' : ''}}">
        <select class="form-control col-md-4 option2" id="city" name="city_id">
            <option value="">Select City</option>
            @isset($city)
            @foreach($city as $value)
            <option @isset($data) {{ $value['city_id'] == $data->city_id ? 'selected="selected"' : '' }} @endisset value="{{ $value['city_id'] }}">{{ $value['type'] }} {{ $value['city_name'] }}</option>
            @endforeach
            @endisset
        </select>
    </div>

</div>
<div class="form-group">
    <label class="col-md-2 control-label">Customer Address</label>
    <div class="col-md-10 {{ $errors->has('customer_address') ? 'has-error' : ''}}">
        {!! Form::textarea('customer_address', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div> 
</div>
<hr>


