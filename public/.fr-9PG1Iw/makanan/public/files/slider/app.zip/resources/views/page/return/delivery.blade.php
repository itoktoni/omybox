@extends('backend.'.config('website.backend').'.layouts.app')

@section('content')
<div class="row">
    {!! Form::model($data, ['route'=>[$form.'_'.$action, $data->$key],'class'=>'form-horizontal','files'=>true]) !!}
    <div class="panel panel-default">
        <header class="panel-heading">
            <h2 class="panel-title">Nomor RO : {{ $data->$key }}</h2>
        </header>

        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-table table-bordered table-striped table-hover mb-none">
                    <tbody>
                        <tr>
                            <th class="col-lg-2">Tanggal Order</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="return_date" readonly="" class="form-control input-sm" value="{{ $data->return_date }}">
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th valign="middle" class="col-lg-2">Tanggal Pengiriman</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="return_delivery_date" id="datepicker" class="form-control input-sm datepicker" value="{{ $data->return_delivery_date }}">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th valign="middle" class="col-lg-2">Status Pengiriman</th>
                            <td>
                                <div class="col-md-3">
                                    {{ Form::select('return_status', ['OPEN' => 'OPEN','DELIVERED' => 'DELIVERED'], null, ['class'=> 'form-control']) }}
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th class="col-lg-2">File Attachment</th>
                            <td>
                                <div class="col-md-3">
                                    <a class="btn btn-danger" target="_blank" href="{{ asset('public/files/po/'.$data->return_attachment) }}">Download File</a> 
                                </div>
                                
                            </td>
                        </tr>

                        <tr>
                            <th valign="middle" class="col-lg-2">Airbill</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="airbill" id="datepicker" class="form-control input-sm" value="{{ $data->airbill }}">
                                </div>
                            </td>
                        </tr>


                        <tr>
                            <th valign="middle" class="col-lg-2">Total Pengiriman</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="total_pengiriman" id="datepicker" class="form-control input-sm" value="{{ $data->total_pengiriman }}">
                                </div>
                            </td>
                        </tr>

                        <tr>
                            <th class="col-lg-2">Note</th>
                            <td>
                                <div class="col-md-12">
                                    <div class="form-control" rows="2" name="return_note_supplier" cols="50">{{ $data->return_note }}</div>
                                </div>                               
                            </td>
                        </tr>
                    </tbody>
                </table>

                <table class="table table-table table-bordered table-striped table-hover mb-none">

                    <header class="panel-heading">
                        <h2 class="panel-title text-right">Order From Admin</h2>
                    </header>

                    <tr>
                        <th class="col-lg-2">ID Product</th>
                        <th>Product Name</th>
                        <th class="text-right">Qty</th>
                    </tr>
                    @php
                    $tot = 0;
                    @endphp
                    @foreach($detail as $c)
                    <tr>
                        @php
                        $tot = $tot + $c->qty;
                        @endphp
                        <td class="col-lg-2">{{ $c->product_id }}</td>
                        <td>{{ $c->product_name }}</td>
                        <td class="text-right col-md-2">{{ $c->qty }}</td>
                    </tr>
                    @endforeach
                    <tr class="well default">
                        <th class="text-right" colspan="2">Total</th>
                        <th class="text-right" colspan="1">{{ number_format($tot,0,",",".") }}</th>
                    </tr>
                    <tr>
                        <td colspan="3"></td>
                    </tr>
                </table>

                <table class="table table-table table-bordered table-striped table-hover mb-none">

                    <header class="panel-heading">
                        <h2 class="panel-title text-right">Actual Delivery</h2>
                    </header>

                    <tr>
                        <th class="col-lg-2">ID Product</th>
                        <th>Product Name</th>
                        <th class="text-right">Qty</th>
                    </tr>
                    @php
                    $tot = 0;
                    @endphp
                    @foreach($detail as $c)
                    <tr>
                        @php
                        $tot = $tot + $c->qty_prepare;
                        @endphp
                        <td class="col-lg-2">{{ $c->product_id }}</td>
                        <td>{{ $c->product_name }}</td>
                        <input type="hidden" name="product[]" value="{{ $c->product_id }}">
                        <td class="text-right col-md-2">
                            <input type="text" name="qty[]" readonly class="form-control text-right input-sm" value="{{ empty($c->qty_prepare) ? 0 : $c->qty_prepare }}">
                        </td>
                    </tr>
                    @endforeach
                    <tr class="well default">
                        <th class="text-right" colspan="2">Total</th>
                        <th class="text-right" colspan="1">{{ number_format($tot,0,",",".") }}</th>
                    </tr>
                    <tr>
                        <td colspan="5"></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="navbar-fixed-bottom" id="menu_action">
            <div class="text-right" style="padding:5px">
                <a href="{!! route("{$form}_list") !!}" class="btn btn-warning">Back</a>
                <button type="reset" class="btn btn-default">Reset</button>
                @isset($delivery)
                @if($data->return_status == 'OPEN')
                <button type="submit" class="btn btn-primary">Save</button>
                @endif
                @endisset

                @if($data->return_status == 'DELIVERED')
                <a target="_blank" href="{{ route($form.'_print_delivery', ['code' => $data->$key]) }}" class="btn btn-danger">Print</a>
                <!-- <button type="submit" class="btn btn-primary">Save</button> -->
                @endif

            </div>
        </div>

    </div>
</div>
{!! Form::close() !!}

@endsection