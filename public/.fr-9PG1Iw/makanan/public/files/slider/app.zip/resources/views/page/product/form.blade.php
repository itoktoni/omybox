@section('javascript')

<script>
    $(function() {

        $(document).ready(function() {
              var element = $('#option3 option:selected');
              $('input[name=product_grouping]').val(element.text());
        });

        $('#option3').change(function() {
            var id = $("#option3 option:selected").text();
            $('input[name=product_grouping]').val(id);
        });
    });
</script>

@endsection

<div class="form-group">
    <label class="col-md-2 control-label">Product Name</label>
    <div class="col-md-4 {{ $errors->has('product_name') ? 'has-error' : ''}}">
        {!! Form::text('product_name', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Product Stock</label>
    <div class="col-md-4 {{ $errors->has('product_stock') ? 'has-error' : ''}} {{ $errors->has('product_stock') ? 'has-error' : ''}}">
        {!! Form::number('product_stock', null, ['class' => 'form-control', 'placeholder' => 'Product Stock']) !!}
    </div>
</div>

<div class="form-group">
    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
    <div class="col-md-4">
        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
    </div>

    <label class="col-md-2 control-label">Product Weight</label>
    <div class="col-md-4 {{ $errors->has('product_weight') ? 'has-error' : ''}}">
        {!! Form::number('product_weight', null, ['class' => 'form-control']) !!}
    </div>
</div>
<div class="form-group">
    <label class="col-md-2 control-label">Product Commision</label>
    <div class="col-md-4 {{ $errors->has('product_commision') ? 'has-error' : ''}}">
        {!! Form::number('product_commision', null, ['class' => 'form-control']) !!}
    </div>

     <label class="col-md-2 control-label">Product Material</label>
    <div class="col-md-4 {{ $errors->has('product_category') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="option2" name="product_material">
            <option value="">Select Material</option>
            @foreach($material as $value)
            <option @isset($data) {{ $value->material_id == $data->product_material ? 'selected="selected"' : '' }} @endisset value="{{ $value->material_id }}">{{ $value->material_name }}</option>
            @endforeach
        </select>
    </div>
</div>  

<hr>

<div class="form-group">
    <label class="col-md-2 control-label">Cost Product</label>
    <div class="col-md-4 {{ $errors->has('product_harga_beli') ? 'has-error' : ''}} {{ $errors->has('product_harga_beli') ? 'has-error' : ''}}">
        {!! Form::number('product_harga_beli', null, ['class' => 'form-control', 'placeholder' => 'Harga Beli']) !!}
    </div>

    <label class="col-md-2 control-label">Selling Price</label>
    <div class="col-md-4 {{ $errors->has('product_harga_jual') ? 'has-error' : ''}} {{ $errors->has('product_harga_beli') ? 'has-error' : ''}}">
        {!! Form::number('product_harga_jual', null, ['class' => 'form-control', 'placeholder' => 'Harga Jual']) !!}
    </div>
</div>

<hr>

<div class="form-group">
    <label class="col-md-2 control-label">Product Category</label>
    <div class="col-md-4 {{ $errors->has('product_category') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="option" name="product_category">
            <option value="">Select Category</option>
            @foreach($category as $value)
            <option @isset($data) {{ $value->category_id == $data->product_category ? 'selected="selected"' : '' }} @endisset value="{{ $value->category_id }}">{{ $value->category_name }}</option>
            @endforeach
        </select>
    </div>

    <label class="col-md-2 control-label">Size</label>
    <div class="col-md-4 {{ $errors->has('product_size') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="option4" name="product_size">
            <option value="">Select Size</option>
            @foreach($size as $z)
            <option @isset($data) {{ $z->size_name == $data->product_size ? 'selected=selected' : '' }} @endisset value="{{ $z->size_name }}">{{ $z->size_name }}</option>
            @endforeach
        </select>
    </div>
</div>

<div class="form-group">

    <label class="col-md-2 control-label">Segmentasi</label>
    <div class="col-md-4 {{ $errors->has('segmentasi_id') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="option3" name="product_segmentasi">
            <option value="">Select Segmentasi</option>
            @foreach($segmentasi as $s)
            <option @isset($data) {{ $s->segmentasi_id == $data->product_segmentasi ? 'selected=selected' : '' }} @endisset value="{{ $s->segmentasi_id }}">{{ $s->segmentasi_name }}</option>
            @endforeach
        </select>
    </div>

    <label class="col-md-2 control-label">Product Unit</label>
    <div class="col-md-4 {{ $errors->has('product_unit') ? 'has-error' : ''}}">
        <select class="form-control col-md-4" id="option2" name="product_unit">
            <option value="">Select Unit</option>
            @foreach($unit as $u)
            <option @isset($data) {{ $u->unit_id == $data->product_unit ? 'selected=selected' : '' }} @endisset value="{{ $u->unit_id }}">{{ $u->unit_name }}</option>
            @endforeach
        </select>
    </div>

</div>
<hr>

<div class="form-group">
    {!! Form::label('name', 'Product Description', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-10 {{ $errors->has('product_description') ? 'has-error' : ''}}">
        {!! Form::textarea('product_description', null, ['class' => 'form-control summernote', 'rows' => '3']) !!}
    </div>  
</div>

<input type="hidden" value="" name="product_grouping">