
<div class="form-group">
    <label class="col-md-2 control-label">Code</label>
    <div class="col-md-4 {{ $errors->has('unit_id') ? 'has-error' : ''}}">
        {!! Form::text('unit_id', null, ['class' => 'form-control']) !!}
    </div>

    <label class="col-md-2 control-label">Name</label>
    <div class="col-md-4 {{ $errors->has('product_name') ? 'has-error' : ''}}">
        {!! Form::text('unit_name', null, ['class' => 'form-control']) !!}
    </div>
</div>
