<div class="form-group">
    <label class="col-md-2 control-label">Slider Name</label>
    <div class="col-md-4 {{ $errors->has('slider_name') ? 'has-error' : ''}}">
        {!! Form::text('slider_name', null, ['class' => 'form-control']) !!}
    </div>
    
    <label class="col-md-2 control-label" for="inputDefault">Attachment</label>
    <div class="col-md-4">
        {!! Form::file('files', ['class' => 'btn btn-default btn-sm btn-block']) !!}
    </div>
</div>

<div class="form-group">
    {!! Form::label('name', 'Slider Description', ['class' => 'col-md-2 control-label']) !!}
    <div class="col-md-4 {{ $errors->has('slider_description') ? 'has-error' : ''}}">
        {!! Form::textarea('slider_description', null, ['class' => 'form-control', 'rows' => '3']) !!}
    </div>
</div>