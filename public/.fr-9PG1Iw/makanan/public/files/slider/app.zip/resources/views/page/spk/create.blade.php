@extends('backend.'.config('website.backend').'.layouts.app')

@section('javascript')
<script>

    $(function() {

        $(document).on('click', '#d', function() {
            var id = $("#d").val();
            $('button[value="' + id + '"]').parents("tr").remove();
        });

        function total(){

            var input_pcs = $("#pcs").val();
            var id = $("#option2 option:selected").val();

            if(input_pcs != '' && id != ''){

                var split = id.split("#");
                var product_id = split[0];
                var product_price = split[1];
                var product_value = split[2];

                var data_total = input_pcs * product_value;
                var total = Math.round(data_total * 100) / 100;

                $('input[name=harga]').val(product_price);
                $('input[name=harga]').attr("placeholder", product_price).blur();

                $('input[name=yard]').val(product_value);
                $('input[name=yard]').attr("placeholder", product_value).blur();

                $('input[name=sum]').val(total);
                $('input[name=sum]').attr("placeholder", total).blur();
            }
        }

        $('#pcs').change(function() {

            total();
        });

        $('#option2').change(function() {

            total();
        });

        $("#tambah").click(function() {

            var input_pcs = $('input[name="pcs"]').val();
            var input_yard = $('input[name=yard]').val();
            var input_sum = $('input[name=sum]').val();
            var input_harga = $('input[name="harga"]').val();

            if (input_pcs && input_yard && input_harga) {

                var name = $('select[name="produk"] option:selected').text();
                var produk = $('select[name="produk"] option:selected').val();

                var split = produk.split("#");
                var product_id = split[0];
                var product_price = split[1];
                var product_value = split[2];

                if (name) {

                    var ep = document.getElementsByName('produks[]');
                    for (i = 0; i < ep.length; i++) {
                        if (ep[i].value.trim() == product_id.trim()) {

                            new PNotify({
                                title: 'Product Already Exist',
                                text: 'Product ' + name.trim() + ' , Already in Table ',
                                addclass: 'notification-danger',
                                icon: 'fa fa-bolt'
                            });

                            return;
                        }
                    }

                    var markup = "<tr><td data-title='ID Product'>" + product_id + "</td><td data-title='Product'>" + name + "</td><td data-title='Pcs' class='text-right col-lg-1'>" + input_pcs + "</td><td data-title='Yard' class='text-right col-lg-1'>" + input_yard + "</td><td data-title='Total' class='text-right col-lg-1'>" + input_sum + "</td><td data-title='Price' class='text-right col-lg-1'>" + input_harga + "</td><td data-title='Action'><button id='d' value='" + product_id + "' type='button' class='btn btn-danger btn-xs btn-block'>Delete</button></td><input type='hidden' value=" + product_id + " name='produks[]'><input type='hidden' value=" + input_pcs + " name='quantity[]'><input type='hidden' value=" + input_yard + " name='yard[]'><input type='hidden' value=" + input_harga + " name='price[]'></tr>";
                    $("table tbody").append(markup);

                    input_pcs = null;
                    name = null;
                    produk = null;
                    input_yard = null;
                    input_sum = null;
                    input_harga = null;

                    $('input[name=pcs]').attr("placeholder", "").blur();
                    $('input[name=yard]').attr("placeholder", "").blur();
                    $('input[name=sum]').attr("placeholder", "").blur();
                    $('input[name=harga]').attr("placeholder", "").blur();

                    $('input[name="pcs"]').val("");
                    $('input[name="yard"]').val("");
                    $('input[name="sum"]').val("");
                    $('input[name="harga"]').val("");
                }
                else {

                    new PNotify({
                        title: 'Choose Product',
                        text: 'Please Select Product !',
                        addclass: 'notification-danger',
                        icon: 'fa fa-bolt'
                    });
                }


            }
            else {
                new PNotify({
                    title: 'Price and Quantity',
                    text: 'Please Input Price & Quantity !',
                    addclass: 'notification-danger',
                    icon: 'fa fa-bolt'
                });
            }

        });
    });
</script>

@endsection


@section('content')

<div class="row">
    {!! Form::open(['route' => $form.'_create', 'class' => 'form-horizontal', 'files' => true]) !!}  
    <div class="panel panel-default" style="margin-bottom: 300px;">
        <header class="panel-heading">
            <h2 class="panel-title">SPK Penjahit</h2>
        </header>

        <div class="panel-body">
            <div class="col-md-12 col-lg-12">
                
                <div class="form-group">
                    <label class="col-md-2 control-label" for="inputDefault">Delivery Date</label>
                    <div class="col-md-4">
                        <div class="input-group">
                            {!! Form::text('spk_delivery_date', null, ['class' => 'form-control datepicker', 'id' => 'datepicker']) !!}
                            <span class="input-group-addon">
                                <i class="fa fa-calendar"></i>
                            </span>
                        </div>
                    </div>
                    <label class="col-md-2 control-label" for="inputDefault">Production</label>
                    <div class="col-md-4 {{ $errors->has('production_id') ? 'has-error' : ''}}">
                        <select class="form-control col-md-4" id="option" name="production_id">
                            <option value="">Select Production</option>
                            @foreach($production as $value)
                            <option @isset($data) {{ $value->production_id == $data->production_id ? 'selected="selected"' : '' }} @endisset value="{{ $value->production_id }}">{{ $value->production_name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-2 control-label" for="textareaDefault">Notes</label>
                    <div class="col-md-4">
                        {!! Form::textarea('spk_note', null, ['class' => 'form-control', 'rows' => '3']) !!}
                    </div>
                </div>

                <br>
                <a id="tambah" style="margin-top: -20px;margin-bottom: 10px; " class="btn btn-success pull-right">Add Order Detail</a>
                <hr>

                <div class="form-group">

                    <div class="col-md-2">
                        <div class="input-group mb-md">
                            <span class="input-group-addon ">Pcs</span>
                            <input class="form-control" id="pcs" name="pcs" type="text">
                        </div>
                    </div>

                    <label class="col-md-1 control-label" for="inputDefault">Product</label>
                    <div class="col-md-3" style="margin-bottom: 10px;" >

                        <input type="hidden" name="hidden_product">
                        <input type="hidden" name="hidden_harga">
                        
                        <select class="form-control col-md-4" id="option2" name="produk">
                            <option value="">Select Product</option>
                            @foreach($product as $value)
                            <option value="{{ $value->product_id.'#'.$value->product_harga_beli.'#'.$value->product_value }}">
                                {{ $value->product_name }}
                            </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-md-2">
                        <div class="input-group mb-md">
                            <span class="input-group-addon ">Yard</span>
                            <input class="form-control" name="yard" type="text">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="input-group mb-md">
                            <span class="input-group-addon ">Sum</span>
                            <input class="form-control" id="sum" name="sum" type="text">
                        </div>
                    </div>

                    <div class="col-md-2">
                        <div class="input-group mb-md">
                            <span class="input-group-addon ">Rp</span>
                            <input class="form-control" name="harga" type="text">
                        </div>
                    </div>

                </div>

                <table class="table table-no-more table-bordered table-striped mb-none">
                    <thead>
                        <tr>
                            <th class="text-left col-lg-1">ID Product</th>
                            <th class="text-left">Product Name</th>
                            <th class="text-right col-lg-1">Pcs</th>
                            <th class="text-right col-lg-1">Yard</th>
                            <th class="text-right col-lg-1">Total</th>
                            <th class="text-right col-lg-1">Harga</th>
                            <th class="text-center col-lg-1">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>

            </div>
        </div>
        
        <div class="navbar-fixed-bottom" id="menu_action">
            <div class="text-right" style="padding:5px">
                <a href="{!! route("{$form}_read") !!}" class="btn btn-warning">Back</a>
                <button type="reset" class="btn btn-default">Reset</button>
                @isset($create)
                <button type="submit" class="btn btn-primary">Save</button>
                @endisset
            </div>
        </div>

        {!! Form::close() !!}
    </div>

    @endsection


