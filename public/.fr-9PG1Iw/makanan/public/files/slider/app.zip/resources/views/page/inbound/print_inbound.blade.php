<!DOCTYPE html>
<html>
<head>
    <link href="{{ asset('public/assets/css/print.css') }}" media="all" rel="stylesheet" />
</head>
<body>
    <div id='page'>
        <div style="margin-bottom: 0px;margin-top:-10px;clear: both;">
            <h4 style='text-align: center; color:white;line-height: 0;font-size: 1.3em; font-weight: bold;'>
                {{ $data->product_id }}
            </h4>

            <img style="margin-top: 40px;width: 90%; text-align: center;" src="data:image/png;base64,{{BARCODE1D::getBarcodePNG($data->product_id, 'C128')}}" alt="barcode" />

            <h5 style='text-align: center; padding-top:20px;color:white;line-height: 0;font-size: 1em; font-weight: bold;'>
                {{ $data->product_name }}
            </h5>
        </div>

    </div>
</body>
</html>