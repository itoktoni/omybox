@extends('backend.'.config('website.backend').'.layouts.app')

@section('javascript')
<script>

    $(document).on('click', '#d', function() {
        var id = $("#d").val();
        $('button[value="' + id + '"]').parents("tr").remove();
    });

    $('input[name="qty2"]').change(function(){
        
        var qty = $('input[name="qty2"]').val();
        if(qty){
            var data = $('select[name="add"]').val();
        }
        else{
             new PNotify({
                title: 'Qty Required !',
                text: 'Isi Qty sebelum memilih add !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });

            $('select[name="add"]').val(''); 
        }
    });

    $('input[name="harga2"]').change(function(){
        
        var qty = $('input[name="qty2"]').val();
        if(qty){
            var harga = $('input[name="harga2"]').val();
            var total = $('input[name="jumlah2"]').val(harga * qty);
        }
        else{
             new PNotify({
                title: 'Qty Required !',
                text: 'Isi Qty sebelum memilih add !',
                addclass: 'notification-danger',
                icon: 'fa fa-bolt'
            });

            $('select[name="add"]').val(''); 
        }
    });

        $("#tambah").click(function(e) {

            var qty = $('input[name=qty2]').val();
            var harga = $('input[name="harga2"]').val();
        
            if (qty && harga) {

                var product_id = $('select[name="add"]').val();
                var name = $('select[name="add"] option:selected').text();
                var qty = $('input[name="qty2"]').val();
                var harga = $('input[name="harga2"]').val();
                
                if (name) {
                    var ep = document.getElementsByName('produks[]');
                    for (i = 0; i < ep.length; i++) {
                        if (ep[i].value.trim() == product_id.trim()) {

                            new PNotify({
                                title: 'Product Already Exist',
                                text: 'Product ' + name.trim() + ' , Already in Table ',
                                addclass: 'notification-danger',
                                icon: 'fa fa-bolt'
                            });

                            return;
                        }
                    }

                    var markup = "<tr><td style='vertival-align:middle' data-title='ID Product'>" + product_id + "</td><td data-title='Product' style='vertival-align:middle'>" + name + "</td><td data-title='Stock' style='vertival-align:middle' class='text-right col-lg-1'>" + qty + "</td><td style='vertival-align:middle' data-title='Price' class='text-right col-lg-1'>" + harga + "</td><td style='vertival-align:middle' data-title='Total' class='text-right col-lg-1'>" + harga * qty + "</td><td data-title='Action' style='width:100px;'><button id='d' value='" + product_id + "' type='button' class='btn btn-danger pull-right'>Delete</button></td><input type='hidden' value=" + product_id + " name='produks2[]'><input type='hidden' value=" + qty + " name='quantity2[]'><input type='hidden' value=" + harga + " name='price2[]'></tr>";
                    $("#additional tbody").append(markup);

                    // $('input[name="product_name"]').val("");
                    // $('input[name="product_id"]').val("");
                    $('input[name="harga2"]').val("");
                    $('input[name="qty2"]').val("");

                    // $('input[name=harga]').attr("placeholder", "").blur();
                    // $('input[name=qty]').attr("placeholder", "").blur();
                }
                else {

                    new PNotify({
                        title: 'Choose Product',
                        text: 'Please Select Product !',
                        addclass: 'notification-danger',
                        icon: 'fa fa-bolt'
                    });
                }
            }
            else {
                new PNotify({
                    title: 'Price and Quantity',
                    text: 'Please Input Price & Quantity !',
                    addclass: 'notification-danger',
                    icon: 'fa fa-bolt'
                });

            }

            return false;
        });

</script>
@endsection

@section('content')
<div class="row">
    {!! Form::model($data, ['route'=>[$form.'_update', $data->$key],'class'=>'form-horizontal','files'=>true]) !!}
    <div class="panel panel-default">
        <header class="panel-heading">
            <h2 class="panel-title">Nomor SPK : {{ $data->$key }}</h2>
        </header>

        <div class="panel-body">
            <div class="table-responsive">
                <table class="table table-table table-bordered table-striped table-hover mb-none">
                    <tbody>
                        <tr>
                            <th class="col-lg-2">Tanggal Order</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="purchase_date" readonly="" class="form-control input-sm" value="{{ $data->spk_date }}">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th valign="middle" class="col-lg-2">Tanggal Pengiriman</th>
                            <td>
                                <div class="col-md-3">
                                    <input type="text" name="purchase_delivery_date" id="datepicker" class="form-control input-sm" value="{{ $data->spk_delivery_date }}">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th valign="middle" class="col-lg-2">Status Pengiriman</th>
                            <td>
                               <div class="col-md-3">
                                {{ Form::select('spk_status', ['PRODUCTION' => 'PRODUCTION','DELIVERED' => 'DELIVERED'], null, ['class'=> 'form-control']) }}
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th class="col-lg-2">File Attachment</th>
                        <td>
                            <div class="col-md-3">
                                <a class="btn btn-danger" target="_blank" href="{{ asset('public/files/spk/'.$data->spk_attachment) }}">Download File</a> 
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th class="col-lg-2">Note Penjahit</th>
                        <td>
                            <div class="col-md-12">
                                <textarea class="form-control" rows="2" name="spk_note_production" cols="50">{{ $data->spk_note_production }}</textarea>
                            </div>                               
                        </td>
                    </tr>
                </tbody>
            </table>

            <table class="table table-table table-bordered table-striped table-hover mb-none">
                <header class="panel-heading">
                    <h2 class="panel-title text-right">Order From Admin</h2>
                </header>

                <tr>
                    <th class="col-lg-2">ID Product</th>
                    <th>Product Name</th>
                    <th class="text-right">Qty</th>
                    <th class="text-right">Price</th>
                    <th class="text-right">Value</th>
                </tr>
                @php
                $tot = 0;
                @endphp
                @foreach($detail as $c)
                <tr>
                    @php
                    $tot = $tot + $c->total;
                    @endphp
                    <td class="col-lg-2">{{ $c->product_id }}</td>
                    <td>{{ $c->product_name }}</td>
                    <td class="text-right">{{ $c->qty }}</td>
                    <td class="text-right">{{ number_format($c->price,0,",",".") }}</td>
                    <td class="text-right">{{ number_format($c->total,0,",",".") }}</td>
                </tr>
                @endforeach
                <tr class="well default">
                    <th class="text-right" colspan="4">Total</th>
                    <th class="text-right" colspan="5">{{ number_format($tot,0,",",".") }}</th>
                </tr>
                <tr>
                    <td colspan="5"></td>
                </tr>
            </table>

            <table class="table table-table table-bordered table-striped table-hover mb-none">
                <header class="panel-heading">
                    <h2 class="panel-title text-right">Actual Delivery</h2>
                </header>

                <tr>
                    <th class="col-lg-2">ID Product</th>
                    <th>Product Name</th>
                    <th class="text-right">Qty</th>
                    <th class="text-right">Price</th>
                    <th class="text-right">Value</th>
                </tr>
                @php
                $tot = 0;
                @endphp
                @foreach($detail as $c)
                <tr>
                    @php
                    $tot = $tot + $c->total_prepare;
                    @endphp
                    <td class="col-lg-2">{{ $c->product_id }}</td>
                    <td>{{ $c->product_name }}</td>
                    <input type="hidden" name="product[]" value="{{ $c->product_id }}">
                    <td class="text-right col-md-2">
                        <input type="text" name="qty[]" class="form-control text-right input-sm" value="{{ $c->qty_prepare }}">
                    </td>
                    <td class="text-right col-md-2">
                        <input type="text" name="price[]" readonly="" class="form-control text-right input-sm" value="{{ $c->price }}">
                    </td>
                    <td class="text-right">{{ number_format($c->total_prepare,0,",",".") }}</td>
                </tr>
                @endforeach
                <tr class="well default">
                    <th class="text-right" colspan="4">Total</th>
                    <th class="text-right" colspan="5">{{ number_format($tot,0,",",".") }}</th>
                </tr>
                <tr>
                    <td colspan="5"></td>
                </tr>
            </table>

            <table id="additional" class="table table-table table-bordered table-striped table-hover mb-none">
                <header class="panel-heading">
                    <h2 class="panel-title text-right">Tambahan Baju</h2>
                </header>

                <tr>
                    <th style="vertical-align: middle;" class="col-lg-1">ID Product</th>
                    <th>  
                        <select class="form-control col-md-4 option2" name="add">
                            <option value="">Select Product</option>
                            @foreach($product as $value)
                            <option value="{{ $value->product_id }}">{{ $value->product_name }}</option>
                            @endforeach
                        </select>
                    </th>
                    <th class="text-right" width="120">
                        <input type="text" style="width: 100px;text-align: center;" placeholder="Add QTY" class="form-control" name="qty2"> 
                    </th>
                    <th class="text-right">
                        <input type="text" class="form-control" placeholder="Harga" name="harga2" id="">
                    </th>
                    <th class="text-right">
                        <input type="text" class="form-control" placeholder="Total Harga" name="jumlah2" readonly="" id="">
                    </th>
                    <th class="text-right">
                        <a href="" id="tambah" class="btn btn-success">Tambah</a>
                    </th>
                </tr>
            </table>

        </div>
    </div>

    <div class="navbar-fixed-bottom" id="menu_action">
        <div class="text-right" style="padding:5px">
            <a href="{!! route("{$form}_read") !!}" class="btn btn-warning">Back</a>
            <button type="reset" class="btn btn-default">Reset</button>
            @isset($update)
            <button type="submit" class="btn btn-primary">Save</button>
            @endisset
        </div>
    </div>

</div>
</div>
{!! Form::close() !!}

@endsection