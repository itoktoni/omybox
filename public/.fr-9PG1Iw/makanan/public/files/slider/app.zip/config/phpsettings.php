<?php
ini_set('max_execution_time', 30000);
ini_set('memory_limit', '128M');
// ini_set('open_basedir','1');