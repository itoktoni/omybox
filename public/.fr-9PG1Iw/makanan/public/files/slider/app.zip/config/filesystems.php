<?php
return [

        /*
          |--------------------------------------------------------------------------
          | Default Filesystem Disk
          |--------------------------------------------------------------------------
          |
          | Here you may specify the default filesystem disk that should be used
          | by the framework. A "local" driver, as well as a variety of cloud
          | based drivers are available for your choosing. Just store away!
          |
          | Supported: "local", "ftp", "s3", "rackspace"
          |
         */

        'default' => 'public',
        /*
          |--------------------------------------------------------------------------
          | Default Cloud Filesystem Disk
          |--------------------------------------------------------------------------
          |
          | Many applications store files both locally and in the cloud. For this
          | reason, you may specify a default "cloud" driver here. This driver
          | will be bound as the Cloud disk implementation in the container.
          |
         */
        'cloud' => 's3',
        /*
          |--------------------------------------------------------------------------
          | Filesystem Disks
          |--------------------------------------------------------------------------
          |
          | Here you may configure as many filesystem "disks" as you wish, and you
          | may even configure multiple disks of the same driver. Defaults have
          | been setup for each driver as an example of the required options.
          |
         */
        'disks' => [

                'local' => [
                        'driver' => 'local',
                        'root' => storage_path('app'),
                ],
                'system' => [
                        'driver' => 'local',
                        'root' => base_path(),
                ],
                'model' => [
                        'driver' => 'local',
                        'root' => app_path(''),
                ],
                'view' => [
                        'driver' => 'local',
                        'root' => resource_path(),
                ],
                'controller' => [
                        'driver' => 'local',
                        'root' => app_path('Http/Controllers/'),
                ],
                'middleware' => [
                        'driver' => 'local',
                        'root' => app_path('Http/Middleware/'),
                ],
                'config' => [
                        'driver' => 'local',
                        'root' => config_path(),
                ],
                'database' => [
                        'driver' => 'local',
                        'root' => database_path(),
                ],
                'public' => [
                        'driver' => 'local',
                        'root' => public_path('files'),
                        'visibility' => 'public',
                ],
                's3' => [
                        'driver' => 's3',
                        'key' => 'your-key',
                        'secret' => 'your-secret',
                        'region' => 'your-region',
                        'bucket' => 'your-bucket',
                ],
                'ftp' => [
                        'driver' => 'ftp',
                        'host' => '103.53.0.154',
                        'username' => 'administrator',
                        'password' => '4RADrDtd',
                        'port' => 2121,
                        // 'root'     => '',
                        'passive' => true,
                // 'ssl'      => true,
                // 'timeout'  => 30,
                ],
        ],
];
