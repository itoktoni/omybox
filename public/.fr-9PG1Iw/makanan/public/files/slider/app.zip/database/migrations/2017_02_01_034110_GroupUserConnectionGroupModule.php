<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class GroupUserConnectionGroupModule extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public $tableName;

    public function __construct() {

        $this->tableName = 'group_user_connection_group_module';
    }

    public function up() {
        
        
        Schema::create($this->tableName, function(Blueprint $table) {
            $table->string('code_group_user');
            $table->string('code_group_module');
            $table->foreign('code_group_user')->references('group_user_code')->on('group_users')->onUpdate('cascade');;
            $table->foreign('code_group_module')->references('group_module_code')->on('group_modules')->onUpdate('cascade');;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        
        
        Schema::drop($this->tableName);
        $table->dropForeign(['code_group_user','code_group_user']);
    }

}
