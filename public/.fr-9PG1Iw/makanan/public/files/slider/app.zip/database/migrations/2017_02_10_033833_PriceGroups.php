<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class PriceGroups extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public $tableName;

    function __construct() {
        $this->tableName = 'price_groups';
    }

    public function up() {
//        Schema::create($this->tableName, function(Blueprint $table) {
//
//            $table->string('product_id');
//            $table->string('segmentasi_id');
//            $table->string('term_of_payment_id');
//            $table->string('site_id');
//            $table->integer('price');
//            $table->timestamps();
//        });
    }

    public function down() {
        //Schema::drop($this->tableName);
    }

}
