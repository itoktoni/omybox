<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateGroupUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('group_users', function(Blueprint $table)
		{
			$table->string('group_user_code')->primary();
			$table->string('group_user_name');
			$table->text('group_user_description', 65535)->nullable();
			$table->enum('group_user_visible', array('Y','T'))->nullable()->default('Y');
			$table->integer('group_user_level')->nullable();
			$table->string('group_user_dashboard')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('group_users');
	}

}
