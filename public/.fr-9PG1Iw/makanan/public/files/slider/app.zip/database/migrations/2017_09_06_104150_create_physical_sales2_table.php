<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePhysicalSales2Table extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('physical_sales2', function(Blueprint $table)
		{
			$table->string('product', 50)->nullable()->index('product');
			$table->string('site_id', 20)->nullable()->index('site_id');
			$table->decimal('stock', 20, 3)->nullable()->index('stock');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('physical_sales2');
	}

}
