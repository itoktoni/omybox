<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSegmentasiTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('segmentasi', function(Blueprint $table)
		{
			$table->string('segmentasi_id')->index('segmentasi_id');
			$table->string('segmentasi_name');
			$table->timestamps();
			$table->text('segmentasi_description', 65535)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('segmentasi');
	}

}
