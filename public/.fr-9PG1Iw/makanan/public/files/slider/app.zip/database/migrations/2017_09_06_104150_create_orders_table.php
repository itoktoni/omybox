<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOrdersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('orders', function(Blueprint $table)
		{
			$table->string('order_id', 50)->primary();
			$table->string('order_reff')->nullable();
			$table->string('order_delivery')->nullable();
			$table->string('order_invoice')->nullable();
			$table->date('order_date')->nullable();
			$table->dateTime('order_delivery_date')->nullable();
			$table->dateTime('order_invoice_date')->nullable();
			$table->string('term_of_payment_id')->nullable();
			$table->string('user_id')->nullable();
			$table->string('order_type_delivery')->nullable();
			$table->string('order_attachment')->nullable()->default('');
			$table->text('order_note', 65535)->nullable();
			$table->timestamps();
			$table->string('created_by')->nullable();
			$table->string('customer_id')->nullable();
			$table->text('order_address', 65535)->nullable();
			$table->string('site_id')->nullable();
			$table->string('order_status')->nullable();
			$table->string('sales_responsible')->nullable();
			$table->string('address_recid')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('orders');
	}

}
