<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder {

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run() {
        DB::table('users')->insert([
            'name' => 'itok toni laksono',
            'email' => 'itok.toni@gmail.com',
            'password' => bcrypt('itok'),
            'username' => 'itoktoni',
            'code_group_user' => 'developer',
            'active' => '1',
        ]);

        DB::table('group_users')->insert([
            'group_user_code' => 'developer',
            'group_user_name' => 'Developer',
            'group_user_description' => 'for developer only',
        ]);
        
        

        $faker = Faker\Factory::create();

        for ($i = 0; $i < 100; $i++) {
            App\User::create([
                'name' => $faker->name,
                'email' => $faker->email,
                'password' => bcrypt('123'),
                'active' => '1',
            ]);
        }
    }

}
