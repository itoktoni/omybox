<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePriceGroupsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('price_groups', function(Blueprint $table)
		{
			$table->string('product_id')->nullable()->index('product_id');
			$table->string('segmentasi_id')->nullable()->index('segmentasi_id');
			$table->string('term_of_payment_id')->nullable()->index('term_of_payment_id');
			$table->string('site_id')->nullable()->index('site_id');
			$table->decimal('price', 11, 0)->nullable()->index('price');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('price_groups');
	}

}
