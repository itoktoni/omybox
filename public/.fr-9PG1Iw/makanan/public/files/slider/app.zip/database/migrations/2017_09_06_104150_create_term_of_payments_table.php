<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTermOfPaymentsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('term_of_payments', function(Blueprint $table)
		{
			$table->string('top_id')->index('top_id');
			$table->string('top_name');
			$table->integer('top_day');
			$table->integer('top_price');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('term_of_payments');
	}

}
