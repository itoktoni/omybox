<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateActionsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('actions', function(Blueprint $table)
		{
			$table->string('action_code')->primary();
			$table->string('action_name');
			$table->text('action_description', 65535)->nullable();
			$table->string('action_link')->nullable();
			$table->string('action_controller')->nullable();
			$table->string('action_function')->nullable();
			$table->integer('action_sort')->nullable()->default(0);
			$table->enum('action_visible', array('N','Y'))->nullable()->default('Y');
			$table->enum('action_enable', array('N','Y'))->nullable()->default('Y');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('actions');
	}

}
