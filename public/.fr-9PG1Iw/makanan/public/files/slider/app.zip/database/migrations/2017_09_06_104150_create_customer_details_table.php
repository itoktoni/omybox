<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCustomerDetailsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('customer_details', function(Blueprint $table)
		{
			$table->string('customer')->nullable();
			$table->text('address', 65535)->nullable();
			$table->string('category')->nullable();
			$table->bigInteger('recid')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('customer_details');
	}

}
