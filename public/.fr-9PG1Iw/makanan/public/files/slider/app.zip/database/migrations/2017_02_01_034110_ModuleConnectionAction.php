<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ModuleConnectionAction extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public $tableName;

    public function __construct() {

        $this->tableName = 'module_connection_action';
    }

    public function up() {


        Schema::create($this->tableName, function(Blueprint $table) {
            $table->string('code_module');
            $table->string('code_action');
            $table->foreign('code_module')->references('module_code')->on('modules')->onUpdate('cascade');
            $table->foreign('code_action')->references('action_code')->on('actions')->onUpdate('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {


        Schema::drop($this->tableName);
        $table->dropForeign(['code_group_user', 'code_group_user']);
    }

}
