<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCustomersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('customers', function(Blueprint $table)
		{
			$table->string('customer_id', 20)->index('customer_id');
			$table->string('customer_name', 400)->nullable()->index('customer_name');
			$table->text('customer_address', 65535)->nullable();
			$table->text('customer_delivery', 65535)->nullable();
			$table->text('customer_invoice', 65535)->nullable();
			$table->string('customer_postal_code', 6)->nullable();
			$table->string('customer_delivery_code', 20)->nullable();
			$table->string('segmentasi_id', 50)->nullable();
			$table->string('user_id', 50)->nullable();
			$table->integer('customer_limit')->nullable();
			$table->string('term_of_payment_id')->nullable();
			$table->string('site_id')->nullable();
			$table->string('warehouse_id')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('customers');
	}

}
