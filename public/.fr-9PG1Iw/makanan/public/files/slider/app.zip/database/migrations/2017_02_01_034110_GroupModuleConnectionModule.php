<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class GroupModuleConnectionModule extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public $tableName;

    public function __construct() {

        $this->tableName = 'group_module_connection_module';
    }

    public function up() {
        
        
        Schema::create($this->tableName, function(Blueprint $table) {
            $table->string('code_group_module');
            $table->string('code_module');
            $table->foreign('code_group_module')->references('group_module_code')->on('group_modules')->onUpdate('cascade');;
            $table->foreign('code_module')->references('module_code')->on('modules')->onUpdate('cascade');;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down() {
        
        
        Schema::drop($this->tableName);
        $table->dropForeign(['code_group_user','code_group_user']);
    }

}
