<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Customers extends Migration {

    /**
     * Run the migrations.
     *
     * @return void
     */
    public $tableName;

    function __construct() {
        $this->tableName = 'customers';
    }

    public function up() {
//        Schema::create($this->tableName, function(Blueprint $table) {
//
//            $table->string('customer_id')->primary();
//            $table->string('customer_name');
//            $table->text('customer_address');
//            $table->text('customer_delivery')->nullable();
//            $table->text('customer_invoice')->nullable();
//            $table->string('customer_postal_code')->nullable();
//            $table->string('customer_delivery_code')->nullable();
//            $table->string('segmentasi_id')->nullable();
//            $table->string('sales_id')->nullable();
//            $table->string('customer_limit')->nullable();
//            $table->string('term_of_payment_id')->nullable();
//            $table->string('site_id')->nullable();
//            $table->string('warehouse_id')->nullable();
//            $table->string('username')->nullable();
//            $table->timestamps();
//        });
    }

    public function down() {
        //Schema::drop($this->tableName);
    }

}
