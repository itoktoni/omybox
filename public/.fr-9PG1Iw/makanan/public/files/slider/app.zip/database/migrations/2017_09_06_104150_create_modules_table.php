<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateModulesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('modules', function(Blueprint $table)
		{
			$table->string('module_code')->primary();
			$table->string('module_name');
			$table->text('module_description', 65535)->nullable();
			$table->string('module_link');
			$table->integer('module_sort')->nullable()->default(0);
			$table->integer('module_single')->nullable()->default(0);
			$table->enum('module_visible', array('Y','N'))->nullable()->default('Y');
			$table->enum('module_enable', array('Y','N'))->nullable()->default('Y');
			$table->string('module_controller')->nullable();
			$table->string('module_filters')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('modules');
	}

}
